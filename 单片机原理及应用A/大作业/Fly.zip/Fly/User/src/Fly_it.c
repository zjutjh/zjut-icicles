/*
 * Fly_it.c
 *
 *  Created on: 2021��12��23��
 *      Author: Fly
 */

#include "Fly_it.h"


void TimerIntInitial(void)//��ʱ���жϺ���
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerClockSourceSet(TIMER0_BASE, TIMER_CLOCK_PIOSC);

    TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR  | TIMER_CFG_B_PERIODIC);//

    TimerLoadSet(TIMER0_BASE, TIMER_B, ui32SysClock/TICKS_PER_SECOND ); // set period 1/SysClock * SysClock/1000 = 1/1000s=1ms

    TimerIntEnable(TIMER0_BASE, TIMER_TIMB_TIMEOUT);



    IntPrioritySet(INT_TIMER0B, 0x80);
    IntEnable(INT_TIMER0B);
    IntMasterEnable();
    SysTickIntEnable();
    TimerEnable(TIMER0_BASE, TIMER_B);
}

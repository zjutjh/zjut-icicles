/*
 * gpio.c
 *
 *  Created on: 2021��11��10��
 *      Author: Fly
 */
#include "Fly_gpio.h"
//*****************************************************************************
//
//! Init a gpio     F1-3            L0-4
//! \return None.
//
//*****************************************************************************
void beep_gpio_init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);        //ʹ��gpioʱ��      ���
    GPIODirModeSet(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_DIR_MODE_OUT);       //��1
    GPIOPadConfigSet(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0x00);
}
void matKey_gpio_init(void)             //���󰴼���ʼ��
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);        //ʹ��gpioʱ��      ���
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);

    GPIODirModeSet(GPIO_PORTD_BASE,GPIO_PIN_1,GPIO_DIR_MODE_OUT);       //��1
    GPIODirModeSet(GPIO_PORTH_BASE,GPIO_PIN_3,GPIO_DIR_MODE_OUT);       //��2
    GPIODirModeSet(GPIO_PORTH_BASE,GPIO_PIN_2,GPIO_DIR_MODE_OUT);       //��3
    GPIODirModeSet(GPIO_PORTM_BASE,GPIO_PIN_3,GPIO_DIR_MODE_OUT);       //��4

    GPIOPadConfigSet(GPIO_PORTD_BASE,GPIO_PIN_1,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(GPIO_PORTH_BASE,GPIO_PIN_3,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(GPIO_PORTH_BASE,GPIO_PIN_2,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(GPIO_PORTM_BASE,GPIO_PIN_3,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);

    GPIOPinWrite(GPIO_PORTD_BASE,GPIO_PIN_1,0xff);
    GPIOPinWrite(GPIO_PORTH_BASE,GPIO_PIN_3,0xff);
    GPIOPinWrite(GPIO_PORTH_BASE,GPIO_PIN_2,0xff);
    GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_3,0xff);
    ////////////////////////////////////////////////////////////////////////////////////////
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOP);        //ʹ��gpioʱ��      ����
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);

    GPIODirModeSet(GPIO_PORTP_BASE,GPIO_PIN_2,GPIO_DIR_MODE_IN);       //��1
    GPIODirModeSet(GPIO_PORTN_BASE,GPIO_PIN_3,GPIO_DIR_MODE_IN);       //��2
    GPIODirModeSet(GPIO_PORTN_BASE,GPIO_PIN_2,GPIO_DIR_MODE_IN);       //��3
    GPIODirModeSet(GPIO_PORTD_BASE,GPIO_PIN_0,GPIO_DIR_MODE_IN);       //��4

    GPIOPadConfigSet(GPIO_PORTP_BASE,GPIO_PIN_2,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
    GPIOPadConfigSet(GPIO_PORTN_BASE,GPIO_PIN_3,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
    GPIOPadConfigSet(GPIO_PORTN_BASE,GPIO_PIN_2,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
    GPIOPadConfigSet(GPIO_PORTD_BASE,GPIO_PIN_0,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);

    //    GPIOPinWrite(GPIO_PORTD_BASE,GPIO_PIN_1,0xff);
    //    GPIOPinWrite(GPIO_PORTH_BASE,GPIO_PIN_3,0xff);
    //    GPIOPinWrite(GPIO_PORTH_BASE,GPIO_PIN_2,0xff);
    //    GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_3,0xff);

}
void led_gpio_init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);        //ʹ��gpioʱ��      LED��ʼ��
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);

    GPIODirModeSet(LED1,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED2,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED3,GPIO_DIR_MODE_OUT);

    GPIODirModeSet(LED4,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED5,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED6,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED7,GPIO_DIR_MODE_OUT);
    GPIODirModeSet(LED8,GPIO_DIR_MODE_OUT);

    GPIOPadConfigSet(LED1,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED2,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED3,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);

    GPIOPadConfigSet(LED4,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED5,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED6,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED7,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);
    GPIOPadConfigSet(LED8,GPIO_STRENGTH_8MA_SC,GPIO_PIN_TYPE_STD);

    GPIOPinWrite(LED1,0xff);
    GPIOPinWrite(LED2,0xff);
    GPIOPinWrite(LED3,0xff);

    GPIOPinWrite(LED4,0xff);
    GPIOPinWrite(LED5,0xff);
    GPIOPinWrite(LED6,0xff);
    GPIOPinWrite(LED7,0xff);
    GPIOPinWrite(LED8,0xff);
    all_LED_off
}
void LED_switch_on(uint8_t data)
{
    if(data & 0x01)
    {
        LED1_on;
    }
    else
    {
        LED1_off;
    }
    if(data & 0x02)
    {
        LED2_on;
    }
    else
    {
        LED2_off;
    }
    if(data & 0x04)
    {
        LED3_on;
    }
    else
    {
        LED3_off;
    }
    if(data & 0x08)
    {
        LED4_on;
    }
    else
    {
        LED4_off;
    }
    if(data & 0x10)
    {
        LED5_on;
    }
    else
    {
        LED5_off;
    }
    if(data & 0x20)
    {
        LED6_on;
    }
    else
    {
        LED6_off;
    }
    if(data & 0x40)
    {
        LED7_on;
    }
    else
    {
        LED7_off;
    }
    if(data & 0x80)
    {
        LED8_on;
    }
    else
    {
        LED8_off;
    }
}
void scan_key(uint8_t * data)
{
    if(!GPIO_read(Line1))
    {
        while(!GPIO_read(Line1));
        *data = 1;
    }
    else if(!GPIO_read(Line2))
    {
        while(!GPIO_read(Line2));
        *data = 2;
    }
    else if(!GPIO_read(Line3))
    {
        while(!GPIO_read(Line3));
        *data = 3;
    }
    else if(!GPIO_read(Line4))
    {
        while(!GPIO_read(Line4));
        *data = 4;
    }
    else
    {
        *data = 0;
    }
}
uint8_t get_key(void)
{
    uint8_t tempdata = 0;
    GPIO_L(List1);
    scan_key(&tempdata);
    if(tempdata)
    {
        return 1+4*(tempdata - 1);
    }
    GPIO_H(List1);

    GPIO_L(List2);
    scan_key(&tempdata);
    if(tempdata)
    {
        return 2+4*(tempdata - 1);
    }
    GPIO_H(List2);

    GPIO_L(List3);
    scan_key(&tempdata);
    if(tempdata)
    {
        return 3+4*(tempdata - 1);
    }
    GPIO_H(List3);

    GPIO_L(List4);
    scan_key(&tempdata);
    if(tempdata)
    {
        return 4+4*(tempdata - 1);
    }
    GPIO_H(List4);

    return 0;
}
/*******
    gpio_init();
    all_LED_off
    uint8_t time = 300;
    uint8_t led_flag = 127;
    while(1)
    {
        LED_switch_on(led_flag);
        Delay(time);
        led_flag = rol(led_flag,1);
    }
 *******/

 /***
    matKey_gpio_init();
    led_gpio_init();
    uint8_t tempdata = 0;
    uint8_t led_flag=0;
    GPIO_L(List1);
    while(1)
    {
        GPIO_L(List1);
        scan_key(&tempdata);
        if(tempdata)
        {
            led_flag = 1+4*(tempdata - 1);
            LED_switch_on(led_flag);
            Delay(200);
        }
        GPIO_H(List1);

        GPIO_L(List2);
        scan_key(&tempdata);
        if(tempdata)
        {
            led_flag = 2+4*(tempdata - 1);
            LED_switch_on(led_flag);
            Delay(200);
        }
        GPIO_H(List2);

        GPIO_L(List3);
        scan_key(&tempdata);
        if(tempdata)
        {
            led_flag = 3+4*(tempdata - 1);
            LED_switch_on(led_flag);
            Delay(200);
        }
        GPIO_H(List3);

        GPIO_L(List4);
        scan_key(&tempdata);
        if(tempdata)
        {
            led_flag = 4+4*(tempdata - 1);
            LED_switch_on(led_flag);
            Delay(200);
        }
        GPIO_H(List4);

    }
  ****/


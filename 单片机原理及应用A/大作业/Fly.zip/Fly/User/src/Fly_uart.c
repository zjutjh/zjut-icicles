/*
 * Fly_uart.c
 *
 *  Created on: 2021��12��22��
 *      Author: Fly
 */


#include "Fly_uart.h"

void UART6IntHandler(void);
//*********************************************************
//             UART��ʼ��  K0 RX       K1 TX
//*********************************************************
void Fly_uart_init_forFP(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART6);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOP);

    GPIOPinConfigure(GPIO_PP0_U6RX);
    GPIOPinConfigure(GPIO_PP1_U6TX);

    GPIOPinTypeUART(GPIO_PORTP_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART6_BASE, ui32SysClock, 19200,
            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    UARTIntRegister(UART6_BASE,UART6IntHandler); //ע���жϷ�����
    IntPrioritySet(INT_UART6,0);//���ȼ�����
    IntMasterEnable();
    IntEnable(INT_UART6);
    UARTIntEnable(UART6_BASE,UART_INT_RX | UART_INT_RT); //ʹ�ܽ�������жϺͽ��ճ�ʱ�ж�

}
void Fly_uart_init_for4G(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART6);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOP);

    GPIOPinConfigure(GPIO_PP0_U6RX);
    GPIOPinConfigure(GPIO_PP1_U6TX);

    GPIOPinTypeUART(GPIO_PORTP_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART6_BASE, ui32SysClock, 115200,
            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    UARTIntRegister(UART6_BASE,UART6IntHandler); //ע���жϷ�����
    IntPrioritySet(INT_UART6,0);//���ȼ�����
    IntMasterEnable();
    IntEnable(INT_UART6);
    UARTIntEnable(UART6_BASE,UART_INT_RX | UART_INT_RT); //ʹ�ܽ�������жϺͽ��ճ�ʱ�ж�

}
//UARTCharPut(UART0_BASE, '!');
extern unsigned char rBuf[8];          //���շ�����Ϣ
extern unsigned char g_ucUartRxEnd ;              //���շ�����Ϣ������־
unsigned char p;
void UART6IntHandler(void)
{
    //��ȡ�жϱ�־λ
        uint32_t flag = UARTIntStatus(UART6_BASE,1);
        //����жϱ�־λ
        UARTIntClear(UART6_BASE,flag);


        while(UARTCharsAvail(UART6_BASE))
        {
            /*��������*/
            rBuf[p++] = UARTCharGet(UART6_BASE);
                          if(p==8) g_ucUartRxEnd = 0xff;
        }
}

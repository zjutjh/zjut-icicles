/*
 * Fly.c
 *
 *  Created on: 2021��12��22��
 *      Author: Fly
 */

#include "Fly.h"

uint32_t ui32SysClock;

void getSysclock(void)
{
    FPUEnable();
    FPULazyStackingEnable();
    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
            SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
            SYSCTL_CFG_VCO_480), 120000000);
    SysTickPeriodSet(ui32SysClock / TICKS_PER_SECOND);
}

void init_wait(void)
{
    LED_switch_on(1);
    Delay_ms(100);
    LED_switch_on(3);
    Delay_ms(100);
    LED_switch_on(7);
    Delay_ms(100);
    LED_switch_on(15);
    Delay_ms(100);
    LED_switch_on(31);
    Delay_ms(100);
    LED_switch_on(63);
    Delay_ms(100);
    LED_switch_on(127);
    Delay_ms(100);
    LED_switch_on(255);
    Delay_ms(100);
}
uint8_t judge_area(uint32_t datax,uint32_t datay,uint32_t x1,uint32_t y1,uint32_t x2,uint32_t y2)
{
    if(datax > x1 && datax < x2)
    {
        if(datay > y1 && datay < y2)
        {
            return 1;
        }
    }

    return 0;
}

/*
 * Fly_TFT.c
 *
 *  Created on: 2021��12��23��
 *      Author: Fly
 */

#include "Fly_TFT.h"

void TFT_400x240Init(void)
{
    IntMasterEnable();
    SysTickIntEnable();

    SysTickEnable();
    EPIGPIOinit();
    TFT_400x240_OTM4001Ainit(ui32SysClock);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_0);
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0, GPIO_PIN_0);
}





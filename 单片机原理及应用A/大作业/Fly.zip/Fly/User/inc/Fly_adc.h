/*
 * Fly_adc.h
 *
 *  Created on: 2021��12��23��
 *      Author: Fly
 */

#ifndef USER_INC_FLY_ADC_H_
#define USER_INC_FLY_ADC_H_

#include "headfile.h"


void Fly_adcInit();
uint32_t get_adc_once(void);
#endif /* USER_INC_FLY_ADC_H_ */

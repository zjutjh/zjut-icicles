/*
 * gpio.h
 *
 *  Created on: 2021��11��10��
 *      Author: Fly
 */

#ifndef USER_INC_FLY_GPIO_H_
#define USER_INC_FLY_GPIO_H_

#include "headfile.h"

#define LED1    GPIO_PORTF_BASE,GPIO_PIN_1
#define LED2    GPIO_PORTF_BASE,GPIO_PIN_2
#define LED3    GPIO_PORTF_BASE,GPIO_PIN_3

#define LED4    GPIO_PORTL_BASE,GPIO_PIN_0
#define LED5    GPIO_PORTL_BASE,GPIO_PIN_1
#define LED6    GPIO_PORTL_BASE,GPIO_PIN_2
#define LED7    GPIO_PORTL_BASE,GPIO_PIN_3
#define LED8    GPIO_PORTL_BASE,GPIO_PIN_4

#define Line1   GPIO_PORTP_BASE,GPIO_PIN_2
#define Line2   GPIO_PORTN_BASE,GPIO_PIN_3
#define Line3   GPIO_PORTN_BASE,GPIO_PIN_2
#define Line4   GPIO_PORTD_BASE,GPIO_PIN_0

#define List1   GPIO_PORTD_BASE,GPIO_PIN_1
#define List2   GPIO_PORTH_BASE,GPIO_PIN_3
#define List3   GPIO_PORTH_BASE,GPIO_PIN_2
#define List4   GPIO_PORTM_BASE,GPIO_PIN_3

#define GPIO_H(x)        GPIOPinWrite(x,0xff)
#define GPIO_L(x)        GPIOPinWrite(x,0x00)
#define GPIO_read(x)     GPIOPinRead(x)

#define beep            GPIO_PORTM_BASE,GPIO_PIN_5
#define beep_on         GPIO_H(beep)
#define beep_off         GPIO_L(beep)

#define LED1_on         GPIO_H(LED1)
#define LED2_on         GPIO_H(LED2)
#define LED3_on         GPIO_H(LED3)

#define LED4_on         GPIO_H(LED4)
#define LED5_on         GPIO_H(LED5)
#define LED6_on         GPIO_H(LED6)
#define LED7_on         GPIO_H(LED7)
#define LED8_on         GPIO_H(LED8)

#define LED1_off         GPIO_L(LED1)
#define LED2_off         GPIO_L(LED2)
#define LED3_off         GPIO_L(LED3)

#define LED4_off         GPIO_L(LED4)
#define LED5_off         GPIO_L(LED5)
#define LED6_off         GPIO_L(LED6)
#define LED7_off         GPIO_L(LED7)
#define LED8_off         GPIO_L(LED8)

#define all_LED_off         LED1_off;LED2_off;LED3_off;LED4_off;LED5_off;LED6_off;LED7_off;LED8_off;
#define Delay_ms(x)        SysCtlDelay(x*120000)      //

// valueѭ������bitsλ
#define rol(value, bits) ((value << bits) | (value >> (sizeof(value)*8 - bits)))

// valueѭ������bitsλ
#define ror(value, bits) ((value >> bits) | (value << (sizeof(value)*8 - bits)))

void led_gpio_init(void);
void matKey_gpio_init(void);
void LED_switch_on(uint8_t data);
void scan_key(uint8_t * data);
uint8_t get_key(void);
#endif /* USER_INC_FLY_GPIO_H_ */

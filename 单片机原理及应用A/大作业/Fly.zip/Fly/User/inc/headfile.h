/*
 * headfile.h
 *
 *  Created on: 2021��11��10��
 *      Author: Fly
 */

#ifndef USER_INC_HEADFILE_H_
#define USER_INC_HEADFILE_H_

#include <stdint.h>
#include <stdbool.h>
#include "math.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "inc/hw_epi.h"
#include "driverlib/adc.h"
#include "driverlib/debug.h"//����
#include "driverlib/epi.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom_map.h"
#include "driverlib/rom.h"
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/ssi.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"

#include "utils/uartstdio.h"
#include "grlib/grlib.h"
#include "TFT_400x240_OTM4001A_16bit.h"
#include "TOUCHinit/TOUCH_TSC2046.h"
#include "EPIinit.h"

//////////////////////////////////////USER
#include "Fly_gpio.h"
#include "Fly_uart.h"
#include "Fly.h"
#include "Fly_TFT.h"
#include "Fly_it.h"
#include "Fly_adc.h"
#include "Fly_fingerprint.h"
#endif /* USER_INC_HEADFILE_H_ */

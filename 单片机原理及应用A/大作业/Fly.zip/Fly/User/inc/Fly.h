/*
 * Fly.h
 *
 *  Created on: 2021��12��22��
 *      Author: Fly
 */

#ifndef USER_INC_FLY_H_
#define USER_INC_FLY_H_

#include "headfile.h"

#define TICKS_PER_SECOND 1000
#define FSECONDS_PER_TICK (1.0F / (float)TICKS_PER_SECOND)

extern uint32_t ui32SysClock;

void getSysclock(void);
void init_wait(void);
uint8_t judge_area(uint32_t datax,uint32_t datay,uint32_t x1,uint32_t y1,uint32_t x2,uint32_t y2);
#endif /* USER_INC_FLY_H_ */

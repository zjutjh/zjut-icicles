/*
 * Fly_uart.h
 *
 *  Created on: 2021��12��22��
 *      Author: Fly
 */

#ifndef USER_INC_FLY_UART_H_
#define USER_INC_FLY_UART_H_

#include "headfile.h"


#define UART_PIN_RX   GPIO_PA6_U2RX
#define UART_PIN_TX   GPIO_PA7_U2TX
#define UART_PORT     GPIO_PORTA_BASE
#define GPIO_PIN_RX   GPIO_PIN_6
#define GPIO_PIN_TX   GPIO_PIN_7
#define GPIO_SYSCLOCK SYSCTL_PERIPH_GPIOA

#define UART_BAUD     115200



void Fly_uart_init_forFP(void);
void Fly_uart_init_for4G(void);
#endif /* USER_INC_FLY_UART_H_ */

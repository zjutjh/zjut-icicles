/*
 * Fly_TFT.h
 *
 *  Created on: 2021��12��23��
 *      Author: Fly
 */

#ifndef USER_INC_FLY_TFT_H_
#define USER_INC_FLY_TFT_H_

#include "headfile.h"

void TFT_400x240Init(void);

#endif /* USER_INC_FLY_TFT_H_ */

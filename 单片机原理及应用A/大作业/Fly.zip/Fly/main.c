#include "headfile.h"

/**
 * main.c
 */
extern uint8_t key_state;
extern uint32_t ui32Loop0;
extern uint32_t TouchXData[6];       // ��Ŵ���λ�ã�����ֵ�˲�
extern uint32_t TouchYData[6];
volatile uint32_t ui32Loop;
int main(void){
    // FPU����
    FPUEnable();
    FPULazyStackingEnable();
    getSysclock();
    led_gpio_init();
    uint8_t time = 20;
    init_wait();        //��ʼ����ʱ

    matKey_gpio_init();
    Fly_uart_init_forFP();
    TFT_400x240Init();
    showChinese(10,320,0,10,WHITE,BLACK);        //��ӭ��
    Delay_ms(100);

    /***********************ʶ��ָ��START***********************************/
    showChinese(50,290,10,8,WHITE,BLACK);       //��ʾ��
    Delay_ms(time);
    while(1)
    {
        key_state = get_key();
        if(key_state == 13)
        {
            showChinese(90,290,18,9,WHITE,BLACK);   //ʶ����
            if(Finger_Search())            //
            {
                showChinese(90,290,35,9,WHITE,BLACK);   //clearʶ����
                Delay_ms(100);

                showChinese(130,220,27,4,WHITE,BLACK);  //ʶ��ɹ�
                Delay_ms(150);
                showChinese(130,220,35,4,WHITE,BLACK);
                Delay_ms(100);
                break;
            }
            else
            {
                showChinese(90,290,35,9,WHITE,BLACK);
                Delay_ms(100);

                showChinese(130,220,31,4,WHITE,BLACK);  //ʶ��ʧ��
                Delay_ms(150);
                showChinese(130,220,35,4,WHITE,BLACK);
                Delay_ms(100);
            }
        }
        Delay_ms(20);
    }
    TFTLCD_CLEAR(BLACK);
    /***********************ʶ��ָ��END***********************************/

    TimerIntInitial();  //������ʱ��B�ж�1000��ʱ������
    TOUCH_TSC2046init(ui32SysClock);
    SSIDataPut(SSI0_BASE,0xd0);
    /***********************����ԱģʽSTART***********************************/
    showChinese(10,250,47,5,WHITE,BLACK);       //��ʾ��
    showChinese(50,320,52,4,WHITE,BLACK);       //����ָ��  (340��61->232��71)    y,x
    showChinese(50,140,56,4,WHITE,BLACK);       //ɾ��ָ��  (150��61->48��71)
    showChinese(90,230,60,4,WHITE,BLACK);       //����ϵͳ  (255��109->135��120)
    LED_switch_on(85);
    Delay_ms(100);
    while(1)
    {
        // ��ȡ������λ��
        for(ui32Loop=0;ui32Loop<=5;ui32Loop++)
        {
            SSIDataPut(SSI0_BASE,0x90);
            SysCtlDelay(3);
            SSIDataGet(SSI0_BASE,&TouchXData[ui32Loop]);
            SysCtlDelay(3);
            SSIDataPut(SSI0_BASE,0xd0);
            SysCtlDelay(3);
            SSIDataGet(SSI0_BASE,&TouchYData[ui32Loop]);
            SysCtlDelay(3);
        }
        TouchXData[5] = (TouchXData[0]+TouchXData[1]+TouchXData[2]+TouchXData[3]+TouchXData[4])/5;
        TouchYData[5] = (TouchYData[0]+TouchYData[1]+TouchYData[2]+TouchYData[3]+TouchYData[4])/5;

        TOUCH_PointAdjust(&TouchXData[5], &TouchYData[5]);

//        TFTLCD_ShowData(100,150,TouchXData[5],CYAN,LIGHTBLUE);
//        TFTLCD_ShowData(100,200,TouchYData[5],CYAN,LIGHTBLUE);
        Delay_ms(100);

        if(judge_area(TouchXData[5],TouchYData[5],61,232,71,340))//����ָ��
        {
            showChinese(130,320,64,8,WHITE,BLACK);       //����ϵͳ  (255��109->135��120)
            key_state = 0;
            while(!key_state)
            {
                key_state = get_key();
                Delay_ms(100);
            }
            showChinese(130,320,35,8,WHITE,BLACK);
            if (Finger_Enroll(key_state))
            {
                showChinese(130,320,83,4,WHITE,BLACK);
                Delay_ms(200);
                showChinese(130,320,35,4,WHITE,BLACK);
            }
            else
            {
                showChinese(130,320,79,4,WHITE,BLACK);
                Delay_ms(200);
                showChinese(130,320,35,4,WHITE,BLACK);
            }
        }
        else if(judge_area(TouchXData[5],TouchYData[5],61,48,71,150)) //ɾ��ָ��
        {
            showChinese(130,320,64,8,WHITE,BLACK);       //����ϵͳ  (255��109->135��120)
            key_state = 0;
            while(!key_state)
            {
                key_state = get_key();
                Delay_ms(100);
            }
            showChinese(130,320,35,8,WHITE,BLACK);

            if (Finger_Delete(key_state))
            {
                showChinese(130,320,87,4,WHITE,BLACK);
                Delay_ms(200);
                showChinese(130,320,35,4,WHITE,BLACK);
            }
            else
            {
                showChinese(130,320,91,4,WHITE,BLACK);
                Delay_ms(200);
                showChinese(130,320,35,4,WHITE,BLACK);
            }
        }
        else if(judge_area(TouchXData[5],TouchYData[5],109,135,120,255)) //����ϵͳ
        {
            break;
        }


    }
    TFTLCD_CLEAR(BLACK);
    /***********************����ԱEND***********************************/

    /***********************ȷ�ϲ�����START***********************************/
    UARTConfigSetExpClk(UART6_BASE, ui32SysClock, 115200,
            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    LED_switch_on(170);
    showChinese(10,280,95,7,WHITE,BLACK);
    key_state = 0;
    while(!key_state)
    {
        key_state = get_key();
        Delay_ms(100);
    }
    switch(key_state)
    {
    case 13:showChinese(50,200,102,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x01);
    break;
    case 14:showChinese(50,200,103,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x02);
    break;
    case 15:showChinese(50,200,104,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x03);
    break;
    case 9:showChinese(50,200,105,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x04);
    break;
    case 10:showChinese(50,200,106,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x05);
    break;
    case 11:showChinese(50,200,107,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x06);
    break;
    case 5:showChinese(50,200,108,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x07);
    break;
    case 6:showChinese(50,200,109,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x08);
    break;
    }
    Delay_ms(200);
    TFTLCD_CLEAR(BLACK);
    /***********************ȷ�ϲ�����END***********************************/

    /***********************��ʼ����START***********************************/
    uint8_t led_flag = 127;       //������ˮ��
    showChinese(10,320,110,6,WHITE,BLACK);
    while(1)
    {
        key_state = get_key();
        LED_switch_on(led_flag);

        switch(key_state)
        {
        case 13:showChinese(50,200,102,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x01);
        break;
        case 14:showChinese(50,200,103,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x02);
        break;
        case 15:showChinese(50,200,104,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x03);
        break;
        case 9:showChinese(50,200,105,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x04);
        break;
        case 10:showChinese(50,200,106,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x05);
        break;
        case 11:showChinese(50,200,107,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x06);
        break;
        case 5:showChinese(50,200,108,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x07);
        break;
        case 6:showChinese(50,200,109,1,WHITE,BLACK);UARTCharPut(UART6_BASE, 0x08);
        break;
        }
        Delay_ms(time);
        led_flag = rol(led_flag,1);
    }
    /***********************��ʼ����END***********************************/
}

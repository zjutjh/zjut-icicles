#ifndef __BSP_ADC_H
#define	__BSP_ADC_H

#include "stm32f4xx.h"

// ADC GPIO �궨��
#define ADC_GPIO_PORT    GPIOC
#define ADC_GPIO_PIN     GPIO_Pin_2
#define ADC_GPIO_CLK     RCC_AHB1Periph_GPIOC

// ADC ��ź궨��
#define ADC_X              ADC1
#define ADC_CLK          RCC_APB2Periph_ADC1
#define ADC_CHANNEL      ADC_Channel_12


// ADC �жϺ궨��
#define ADC_IRQ            ADC_IRQn
#define ADC_INT_FUNCTION   ADC_IRQHandler


void Adc_Init(void);

#endif /* __BSP_ADC_H */




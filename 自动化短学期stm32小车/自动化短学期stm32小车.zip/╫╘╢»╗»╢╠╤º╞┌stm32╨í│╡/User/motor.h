#ifndef __MOTOR_H
#define __MOTOR_H

#include <stm32f4xx.h>
#include <stdio.h>

extern float grade,Deviation;
extern int  motor_L_speed,motor_R_speed;
extern float SpeedP1,SpeedD1;//1.03 0.14 0.75 0.09
extern float SpeedP2,SpeedD2;//1.03 0.14 0.75 0.09
extern int  Speed ;
extern int Street[4];
void SpeedConturl(int left_speed , int right_speed);
void GOahead(void);//all forward�����ֶ���ǰת
void GOback(void);//all back�������Ӷ����ת
void STOP(void);//all stop�������Ӷ�ֹͣ
void TURNleft(void);
void TURNright(void);
void TURNleft_back(void);
void TURNright_back(void);
int  street_control(int target_center,int time_number);
#endif

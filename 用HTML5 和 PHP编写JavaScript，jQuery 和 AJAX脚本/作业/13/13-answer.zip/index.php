<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery/3.6.0/jquery.min.js"></script>
</head>

<body>
    <h1>用户名验证</h1>
    <label for="username">请输入用户名：</label>
    <input type="text" name="username" id="username">
    <span id="hint"></span>
    <br />
    <button type="submit">确定</button>
    <button type="reset">取消</button>
</body>

</html>
<script>
    const btn = document.querySelector('button[type="submit"]');
    const resetBtn = document.querySelector('button[type="reset"]');
    const input = document.querySelector('input');
    const hint = document.querySelector('#hint');
    btn.addEventListener('click', () => {
        $.post('check.php', {
            username: input.value
        }, function (data) {
            const result = JSON.parse(data);
            if (result.ok) {
                alert('注册成功');
            } else {
                hint.innerText = result.message;
            }
        })
    })
    resetBtn.addEventListener('click', () => {
        hint.innerText = '';
        input.value = '';
    })
</script>
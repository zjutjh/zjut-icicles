<?php

$dbserver = 'localhost';
$dbuser = 'root';
$dbpass = 'zlb20031130';
$dbname = 'user';
$conn = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname);

$username = $_POST['username'];
if (empty($username)) {
    // return a json
    echo json_encode([
        'ok' => false,
        'message' => '用户名不能为空'
    ]);
    exit;
}


if (strlen($username) < 6 || strlen($username) > 12 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    echo json_encode([
        'ok' => false,
        'message' => '*应在6-12个字符（数字字母下划线）'
    ]);
    exit;
}

// if ($username == 'username1') {
//     echo json_encode([
//         'ok' => false,
//         'message' => "该用户名'".$username."'已存在"
//     ]);
//     exit;
// }

// echo json_encode([
//     'ok' => true,
// ]);

$sql = "SELECT * FROM userinfo WHERE username = '$username'";
$result = mysqli_query($conn, $sql);
if ($result->num_rows > 0) {
    echo json_encode([
        'ok' => false,
        'message' => "该用户名'".$username."'已存在"
    ]);
    exit;
} 

$sql = "INSERT INTO userinfo (username) VALUES ('$username')";
$result = mysqli_query($conn, $sql);
if ($result) {
    echo json_encode([
        'ok' => true,
    ]);
} else {
    echo json_encode([
        'ok' => false,
        'message' => '数据库错误'
    ]);
}
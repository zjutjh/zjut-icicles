<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    function isValidPhoneNumber($phoneNumber)
    {
        return (preg_match('/^1\d{10}$/', $phoneNumber) || preg_match('/^\d{3,4}-\d{8}$/', $phoneNumber));
    }

    function isValidEmail($email)
    {
        $posAt = strpos($email, '@');
        return ($posAt > 0 && strpos($email, '.') > $posAt && strrpos($email, '.') != strlen($email) - 1);
    }

    function isValidUsername($username)
    {
        return (strlen($username) >= 4 && strlen($username) <= 12);
    }

    $studentsInfo = "Tom 80 20170101 15023493893;
Jery 85 20170102 15312345678;
Susan 73 20170103 13008678657;
Amie 67 20170104 13387234592;
Lily 83 20170105 15350843792;
Linda 90 20170106 15095811472;
Frank 86 20170107 18162839763;
Lee 78 20170108 15928437983;
Simone 95 20170109 13678236429;
Emma 92 20170110 15026937297";

    $studentsArray = [];
    $studentsInfoLines = explode(";", $studentsInfo);
    foreach ($studentsInfoLines as $infoLine) {
        $info = explode(" ", trim($infoLine));
        $studentsArray[] = [
            'name' => $info[0],
            'score' => $info[1],
            'id' => $info[2],
            'phone' => $info[3],
        ];
    }

    usort($studentsArray, function ($a, $b) {
        return $a['score'] - $b['score'];
    });

    echo "<table border='1'>
        <tr>
            <th>姓名</th>
            <th>成绩</th>
            <th>学号</th>
            <th>电话</th>
        </tr>";

    foreach ($studentsArray as $student) {
        echo "<tr>
            <td>{$student['name']}</td>
            <td>{$student['score']}</td>
            <td>{$student['id']}</td>
            <td>" . substr($student['phone'], 0, 3) . "****" . substr($student['phone'], -4) . "</td>
          </tr>";
    }

    echo "</table>";

    $phoneNumber1 = "15023493893";
    $phoneNumber2 = "021-12345678";
    $phoneNumber3 = "1234567";
    $email1 = "admin@example.com";
    $email2 = "john.doe@example.com";
    $email3 = "invalid-email";
    $username1 = "user123";
    $username2 = "verylongusername";
    $username3 = "a";

    echo "手机号码1：$phoneNumber1 ，验证结果：" . (isValidPhoneNumber($phoneNumber1) ? "有效" : "无效") . "<br>";
    echo "手机号码2：$phoneNumber2 ，验证结果：" . (isValidPhoneNumber($phoneNumber2) ? "有效" : "无效") . "<br>";
    echo "手机号码3：$phoneNumber3 ，验证结果：" . (isValidPhoneNumber($phoneNumber3) ? "有效" : "无效") . "<br>";

    echo "邮箱1：$email1 ，验证结果：" . (isValidEmail($email1) ? "有效" : "无效") . "<br>";
    echo "邮箱2：$email2 ，验证结果：" . (isValidEmail($email2) ? "有效" : "无效") . "<br>";
    echo "邮箱3：$email3 ，验证结果：" . (isValidEmail($email3) ? "有效" : "无效") . "<br>";

    echo "用户名1：$username1 ，验证结果：" . (isValidUsername($username1) ? "有效" : "无效") . "<br>";
    echo "用户名2：$username2 ，验证结果：" . (isValidUsername($username2) ? "有效" : "无效") . "<br>";
    echo "用户名3：$username3 ，验证结果：" . (isValidUsername($username3) ? "有效" : "无效") . "<br>";
    ?>

</body>

</html>
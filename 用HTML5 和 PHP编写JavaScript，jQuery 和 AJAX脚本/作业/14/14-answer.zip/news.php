<?php
header("Content-Type: text/html; charset=UTF-8");
$mysqli = new mysqli();
$mysqli->connect("localhost", "root", "123456", "myusers");
$mysqli->set_charset("utf8");
	$sql="select * from news where id=".$_GET['id'];
	$result=$mysqli->query($sql);
	$new=$result->fetch_array();
?>
<html>
<head>
<style>
	a{margin:0 50px;}
	
</style>

<script>
	if(window.XMLHttpRequest){// 
  	xmlhttp=new XMLHttpRequest();
  }else if (window.ActiveXObject){// code for IE6, IE5
 	 xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  if (xmlhttp==null)
    {
    alert ("您的浏览器不支持AJAX！");
    }
    pid=<?php echo $_GET['id'];?>;
	function showpre(){
		pid--;
   var url="info.php";
		url=url+"?q="+pid;
		xmlhttp.onreadystatechange=stateChanged;
		xmlhttp.open("GET",url,true);
		xmlhttp.send(null);
	}
	function shownext(){
		pid++;
   var url="info.php";
		url=url+"?q="+pid;
		xmlhttp.onreadystatechange=stateChanged;
		xmlhttp.open("GET",url,true);
		xmlhttp.send(null);
	}
	function stateChanged(){
		if (xmlhttp.readyState==4&&xmlhttp.status==200)
		{ 
			doc=JSON.parse(xmlhttp.responseText);
				document.getElementById('ptitle').innerHTML=doc["title"];
				document.getElementById('pcon').innerHTML=doc["content"];
				document.getElementById('pprice').innerHTML="价格："+doc["price"];
				document.getElementById("pimg").setAttribute("src",doc["img"])
			
		}
	}
	
</script>
</head>

<body>

<center>
<div id="bodydiv">
	<a href="javascript:showpre()" >上一个商品</a>
	<a href="javascript:shownext()">下一个商品</a>
  <table width="1000" height="100%"  border="0" cellpadding="0" cellspacing="0" class="tdboxline">

  <tr>
    <td height="10">&nbsp;</td>
  </tr>

    <tr>
      <td height="25" colspan="2" valign="top">

              <div id="ptitle" class="newstitle" style="padding-left:10px; font-size:20px;"><?php echo $new['title'];?></div>
           
      </td>
    </tr>
    <tr>
      <td height="35" colspan="2" valign="top">
	  <table width="99%" border="0" style="margin:0 auto;">
        <tr>
          <td height="2" bgcolor="#4F98C9"></td>
        </tr>
      </table>
        <br></td>
    </tr>
    <tr>
      <td colspan="2" valign="top" class="black13px"><table width="100%"  border="0" cellspacing="0" cellpadding="10">
        <tr>
          <td valign="top"><table width="98%" border="0" height="28" style="margin:0 auto;">
            <tbody>
              <tr>
                <td valign="top"><div id="jiacu" style="line-height:27px">
                	<img width="500px" id="pimg" src="<?php echo $new['img'];?>"/>
                	<p id="pprice">价格：<?php echo $new['type'];?></p>
                	
                	<p>商品介绍</p>
                  <p><span style="font-family: 宋体, SimSun;" id="pcon">
                  	<?php echo $new['content'];?>
                  	</span></p>

                </div>
                  <br>
                  <BR>
                  <BR></td>
              </tr>
            </tbody>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</div>
</br></br>
</center>


</div> 
</body>
</html>

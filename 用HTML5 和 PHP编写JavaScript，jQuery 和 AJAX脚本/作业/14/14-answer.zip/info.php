<?php
$mysqli = new mysqli();
$mysqli->connect("localhost", "root", "123456", "myusers");
$mysqli->set_charset("utf8");
	$sql="select * from news where id=".$_GET['q'];
	$result=$mysqli->query($sql);
	$new=$result->fetch_assoc();
	echo json_encode($new);
?>
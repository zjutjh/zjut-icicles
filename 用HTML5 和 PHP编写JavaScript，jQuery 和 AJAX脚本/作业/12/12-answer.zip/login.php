<?php
	session_start();
	$showform=true;
if(isset($_POST['submit'])){
		$conn=new mysqli();
		$conn->connect('localhost','root','123456');
		$conn->select_db('myusers');
		$conn->set_charset("utf8");
		$sql="select * from user where username='".$_POST["name"]."' and password='".md5($_POST["pass"])."'";
		$result=$conn->query($sql) or die($conn->error);
	if($result->num_rows>0){
			$showform=false;
			$_SESSION['user']=$_POST["name"];
			setcookie(session_name(), session_id(), time() + 1440, "/"); 
			echo "欢迎您，".$_POST["name"];
	}
 	else{
 		$info="用户名或密码错误，请重新输入";
 	}
}else if(isset($_SESSION['user'])){
	$showform=false;
			echo "欢迎您，".$_SESSION['user'];
}
if($showform){
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title> php表单</title>
        <style type="text/css">
        body {
            font-family: "Microsoft Yahei"
        }
		label,input{
		display:block;
		width:300px;
		}
        
        input#submit {
            border: none;
            background-color: #2F79BA;
            color: #fff;
            border-radius: 5px;
            padding: 10px 20px;
						margin-top:10px;
            cursor: pointer;
        }
        form{
            display: flex;
            flex-direction: column;
        }
        div{
           margin:5px auto;
           display: flex;
           flex-flow: inherit;
           width: 300px;
        }
    		input{
        	border:1px solid #888;
		 			padding: 7px;
    		}

        p {
            font-size: .8rem;
            color: #BBBBBB;
						margin:0;
        }
        </style>
    </head>

    <body>
        <form action="" method="post" id="form">

            <div>
                <label for="name">名称</label>
                <input type="text" id="name" name='name' value="<?php if(isset($_POST["name"])) echo $_POST["name"];?>"/>
            </div>
            <div>
                <label for="password">密码</label>
                <input type="password" id="password" name='pass' value="<?php if(isset($_POST["pass"])) echo $_POST["pass"];?>"/>
            </div>
            <div>
            	<?php if(isset($info)){ echo "<p style='color:red'>$info</p>";} ?>
            <input type="submit" id="submit" value="登录" name="submit" />
            </div>
        </form>
    </body>

</html>

<?php
}?>
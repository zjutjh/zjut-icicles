<?php
if(isset($_POST['submit'])){
	$flag=1;
	if($_POST['name']==''){
		$cuname="<p class='red'>用户名不能为空！</p>";
		$flag=0;
	}else if(strlen($_POST['name'])<6||strlen($_POST['name'])>12){
		$cuname="<p class='red'>用户名长度为6-12个字符！</p>";
		$flag=0;
	}
	if($_POST['pass']==''){
		$cupass="<p class='red'>密码不能为空！</p>";
		$flag=0;
	}else if($_POST['pass']!=$_POST['conpass']){
		$cucpass="<p class='red'>两次输入密码不一致！</p>";
		$flag=0;
		}
	if($flag){
		$name=$_POST['name'];
		$pass=$_POST['pass'];
		$conn=new mysqli();
$conn->connect('localhost','root','');
$conn->select_db('myusers');
$conn->query("insert into user (username, password) VALUES ('$name','".md5($pass)."')");
if($conn->errno){
echo $conn->error;
}

		echo "<p>您已注册，具体信息如下:<br/>
					用户名：$name<br/>
					密码：$pass</p>";
		}
	
}
if(!isset($flag)||$flag==0){
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title> php表单</title>
        <style type="text/css">
        body {
            font-family: "Microsoft Yahei"
        }
		label,input{
		display:block;
		width:300px;
		}
        
        input#submit {
            border: none;
            background-color: #2F79BA;
            color: #fff;
            border-radius: 5px;
            padding: 10px 20px;
						margin-top:10px;
            cursor: pointer;
        }
        form{
            display: flex;
            flex-direction: column;
        }
        div{
           margin:5px auto;
           display: flex;
           flex-flow: inherit;
           width: 300px;
        }
    		input{
        	border:1px solid #888;
		 			padding: 7px;
    		}

        p {
            font-size: .8rem;
            color: #BBBBBB;
						margin:0;
        }
        .red{
        	color:red;
        }
        </style>
    </head>

    <body>
        <form action="" method="post" id="form">
            <div>
                <label for="name">名称</label>
                <input type="text" id="name" name='name' value='<?php if(isset($flag)) echo $_POST['name'];?>' />
                <?php if(isset($cuname)) echo $cuname; else echo "<p>必填，长度为4~16个字符</p>";?>
            </div>
            <div>
                <label for="password">密码</label>
                <input type="password" id="password" name='pass' value='<?php if(isset($flag)) echo $_POST['pass'];?>' />
                <?php if(isset($cupass)) echo $cupass; else echo "<p>请输入密码</p>";?>
            </div>
            <div>
                <label for="password_confirm">密码确认</label>
                <input type="password" id="password_confirm" name='conpass' value='<?php if(isset($flag)) echo $_POST['conpass'];?>' />
                <?php if(isset($cucpass)) echo $cucpass; else echo "<p>再次输入相同的密码</p>";?>
            </div>
            <div>
            <input type="submit" id="submit" value="提交" name="submit" />
            </div>
        </form>
    </body>

</html>
<?php } ?>



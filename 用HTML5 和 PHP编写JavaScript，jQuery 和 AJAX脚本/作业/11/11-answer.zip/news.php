<?php
header("Content-Type: text/html; charset=UTF-8");
$mysqli = new mysqli();
$mysqli->connect("localhost", "root", "123456", "myusers");
$mysqli->set_charset("utf8");
	$sql="select * from news where id=".$_GET['id'];
	$result=$mysqli->query($sql);
	$new=$result->fetch_array();
?>
<html>
<head>

</head>

<body>

<center>
<div id="bodydiv">
  <table width="1000" height="100%"  border="0" cellpadding="0" cellspacing="0" class="tdboxline">

  <tr>
    <td height="10">&nbsp;</td>
  </tr>

    <tr>
      <td height="25" colspan="2" valign="top">

              <div class="newstitle" style="padding-left:10px; font-size:20px;"><?php echo $new['title'];?></div>
           
      </td>
    </tr>
    <tr>
      <td height="35" colspan="2" valign="top">
	  <table width="99%" border="0" style="margin:0 auto;">
        <tr>
          <td height="2" bgcolor="#4F98C9"></td>
        </tr>
      </table>
        <br></td>
    </tr>
    <tr>
      <td colspan="2" valign="top" class="black13px"><table width="100%"  border="0" cellspacing="0" cellpadding="10">
        <tr>
          <td valign="top"><table width="98%" border="0" height="28" style="margin:0 auto;">
            <tbody>
              <tr>
                <td valign="top"><div id="jiacu" style="line-height:27px">
                	<img width="500px" src="<?php echo $new['img'];?>"/>
                	<p>价格：<?php echo $new['type'];?></p>
                	
                	<p>商品介绍</p>
                  <p><span style="font-family: 宋体, SimSun;">
                  	<?php echo $new['content'];?>
                  	</span></p>

                </div>
                  <br>
                  <BR>
                  <BR></td>
              </tr>
            </tbody>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</div>
</br></br>
</center>


</div> 
</body>
</html>

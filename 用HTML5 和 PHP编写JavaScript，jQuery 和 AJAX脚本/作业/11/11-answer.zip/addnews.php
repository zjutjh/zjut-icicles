<?php
$title = $_POST['title']; // 获取表单中的信息
$price = $_POST['price'];
$content = $_POST['content'];

$fileInfo = $_FILES["upFile"];
// 获取上传文件的名称
$fileName = $fileInfo["name"];
// 获取上传文件保存的临时路径
$filePath = $fileInfo["tmp_name"];

// 移动文件
move_uploaded_file($filePath, $_SERVER['DOCUMENT_ROOT']."/img/" . $fileName); 

$mysqli = new mysqli();
$mysqli->connect("localhost", "root", "123456", "myusers");
$mysqli->set_charset("utf8");

$sql = "INSERT INTO `news` (`id`, `title`, `price`, `date`, `content`, `img`) VALUES (NULL, '$title','$price', CURRENT_TIMESTAMP, '$content', 'img/$fileName');";
$mysqli->query($sql); // 添加到新闻数据库
header('location:news.php?id='.mysqli_insert_id($mysqli));
mysqli_close($mysqli);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>乘法表</title>
</head>
<body>
    <h1>乘法表</h1>
    <div id="content">
        <?php
            for($i=1;$i<=9;$i++){
                for($j=1;$j<=$i;$j++){
                    echo "<div class='bar'>".$j."×".$i."=".$j*$i."</div>";
                }
                for($k=1;$k<=9-$i;$k++){
                    echo "<div class='blank'></div>";
                }
                echo "<br>";
            }
        ?>
    </div>
</body>
</html>
<style>
    h1{
        text-align: center;
    }

    #content {
        margin: 0 auto;
        text-align: center;
    }

    .bar {
        display: inline-block;
        width: 100px;
        text-align: center;
        border: 1px solid #000;
    }

    .blank {
        display: inline-block;
        width: 100px;
        height: auto;
        text-align: center;
        border: 1px solid #fff;
    }
</style>
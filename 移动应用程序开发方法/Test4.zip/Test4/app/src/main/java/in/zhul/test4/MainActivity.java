package in.zhul.test4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.editTextUsername);
        passwordEditText = findViewById(R.id.editTextPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button registerButton = findViewById(R.id.buttonRegister);
        checkSavedCredentials();
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                login();
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });
    }

    private void login() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        if (username.equals("") || password.equals("")) {
            Toast.makeText(this, "请填写完整", Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences sharedPreferences = getSharedPreferences("in.zhul.test4", MODE_PRIVATE);
        if (sharedPreferences.getAll().size() == 0) {
            Toast.makeText(this, "还未注册", Toast.LENGTH_SHORT).show();
            return;
        }
        String passwordFromSharedPreferences = sharedPreferences.getString("password", "");
        if (passwordFromSharedPreferences.equals("")) {
            Toast.makeText(this, "该用户不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        if (passwordFromSharedPreferences.equals(password)) {
            startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
        } else {
            Toast.makeText(this, "密码错误", Toast.LENGTH_SHORT).show();
        }
    }
    private void checkSavedCredentials() {
        SharedPreferences sharedPreferences = getSharedPreferences("in.zhul.test4", MODE_PRIVATE);
        boolean doRemember = sharedPreferences.getBoolean("doRemember", false);
        if (doRemember) {
            String username = sharedPreferences.getString("username", "");
            String password = sharedPreferences.getString("password", "");
            usernameEditText.setText(username);
            passwordEditText.setText(password);
        }
    }
}
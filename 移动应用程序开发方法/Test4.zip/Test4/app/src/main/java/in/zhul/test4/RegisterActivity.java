package in.zhul.test4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText registerUsernameEditText = findViewById(R.id.editTextRegisterUsername);
        EditText registerPasswordEditText = findViewById(R.id.editTextRegisterPassword);
        RadioGroup radioGroupRemember = findViewById(R.id.radioGroupRemember);
        RadioButton radioButtonDoRemember = findViewById(R.id.doRememberButton);
        RadioButton radioButtonDoNotRemember = findViewById(R.id.dontRememberButton);
        Button buttonSave = findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(v -> {
            String username = registerUsernameEditText.getText().toString();
            String password = registerPasswordEditText.getText().toString();
            if (username.equals("") || password.equals("") || radioGroupRemember.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "请填写完整", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean doRemember = radioButtonDoRemember.isChecked();
            save(username, password, doRemember);
        });
    }

    private void save(String username, String password, boolean doRemember) {
        getSharedPreferences("in.zhul.test4", MODE_PRIVATE)
                .edit()
                .putString("username", username)
                .putString("password", password)
                .putBoolean("doRemember", doRemember)
                .apply();
        startActivity(new Intent(this, MainActivity.class));
    }
}

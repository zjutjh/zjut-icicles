package com.zhul.test3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextPassword;
    private RadioGroup radioGroupGender;
    private CheckBox checkBoxMusic, checkBoxSports, checkBoxTravel, checkBoxInternet;
    private Spinner spinnerLocation;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextPassword = findViewById(R.id.editTextPassword);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        checkBoxMusic = findViewById(R.id.checkBoxMusic);
        checkBoxSports = findViewById(R.id.checkBoxSports);
        checkBoxTravel = findViewById(R.id.checkBoxTravel);
        checkBoxInternet = findViewById(R.id.checkBoxInternet);
        spinnerLocation = findViewById(R.id.spinnerLocation);
        textViewResult = findViewById(R.id.textViewResult);
    }

    public void onSubmitClick(View view) {
        // 获取用户输入
        String name = editTextName.getText().toString();
        String password = editTextPassword.getText().toString();
        String gender = ((RadioButton) findViewById(radioGroupGender.getCheckedRadioButtonId())).getText().toString();
        StringBuilder hobbies = new StringBuilder();
        if (checkBoxMusic.isChecked()) hobbies.append("音乐, ");
        if (checkBoxSports.isChecked()) hobbies.append("体育, ");
        if (checkBoxTravel.isChecked()) hobbies.append("旅游, ");
        if (checkBoxInternet.isChecked()) hobbies.append("上网, ");
        String location = spinnerLocation.getSelectedItem().toString();

        // 显示结果
        String result = "姓名: " + name + "\n密码: " + password + "\n性别: " + gender +
                "\n爱好: " + hobbies.toString().replaceAll(", $", "") + "\n所在地: " + location;
        textViewResult.setText(result);
    }
}

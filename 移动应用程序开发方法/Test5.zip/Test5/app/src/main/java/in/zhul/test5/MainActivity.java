package in.zhul.test5;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private EditText idEditText, nameEditText, majorEditText;
    private TextView resultTextView;
    private Button insertButton, deleteButton, updateButton, queryButton;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idEditText = findViewById(R.id.et_id);
        nameEditText = findViewById(R.id.et_name);
        majorEditText = findViewById(R.id.et_major);
        resultTextView = findViewById(R.id.tv_result);
        insertButton = findViewById(R.id.btn_insert);
        deleteButton = findViewById(R.id.btn_delete);
        updateButton = findViewById(R.id.btn_update);
        queryButton = findViewById(R.id.btn_query);

        db = new MyDBHelper(this).getWritableDatabase();

        insertButton.setOnClickListener(v -> {
            insertData();
        });
        updateButton.setOnClickListener(v -> {
            updateData();
        });
        deleteButton.setOnClickListener(v -> {
            deleteData();
        });
        queryButton.setOnClickListener(v -> {
            queryData();
        });
    }
    private void insertData() {
        String id = idEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String major = majorEditText.getText().toString();

        db.execSQL("INSERT INTO student VALUES (" + id + ", '" + name + "', '" + major + "');");
        Toast.makeText(this, "插入成功", Toast.LENGTH_SHORT).show();
        clearEditTextFields();
    }

    private void updateData() {
        String id = idEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String major = majorEditText.getText().toString();

        db.execSQL("UPDATE student SET name = '" + name + "', major = '" + major + "' WHERE id = " + id + ";");
        Toast.makeText(this, "更新成功", Toast.LENGTH_SHORT).show();
        clearEditTextFields();
    }

    private void deleteData() {
        String id = idEditText.getText().toString();

        db.execSQL("DELETE FROM student WHERE id = " + id + ";");
        Toast.makeText(this, "删除成功", Toast.LENGTH_SHORT).show();
        clearEditTextFields();
    }

    private void queryData() {
        String id = idEditText.getText().toString();

        if (id.isEmpty()) {
            resultTextView.setText("");
            Cursor cursor = db.rawQuery("SELECT * FROM student;", null);
            while (cursor.moveToNext()) {
                String _id = cursor.getString(0);
                String name = cursor.getString(1);
                String major = cursor.getString(2);
                resultTextView.append("学号:"+_id + ", 姓名:" + name + ", 专业:" + major + "\n");
            }
        } else {
            resultTextView.setText("");
            resultTextView.append("-------------------------------\n");
            Cursor cursor = db.rawQuery("SELECT * FROM student WHERE id = " + id + ";", null);
            while (cursor.moveToNext()) {
                String _id = cursor.getString(0);
                String name = cursor.getString(1);
                String major = cursor.getString(2);
                resultTextView.append("学号:"+_id + ", 姓名:" + name + ", 专业:" + major + "\n");
            }
        }
        clearEditTextFields();
    }

    private void clearEditTextFields() {
        idEditText.setText("");
        nameEditText.setText("");
        majorEditText.setText("");
    }
}
package in.zhul.test7;

import android.animation.ValueAnimator;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.ViewTreeObserver;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView mapView;
    private ImageView characterView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapView = findViewById(R.id.mapView);
        characterView = findViewById(R.id.characterView);

        characterView.setImageResource(R.drawable.running);
        AnimationDrawable characterAnimation = (AnimationDrawable) characterView.getDrawable();
        characterAnimation.start();

        HorizontalScrollView mapViewContainer = findViewById(R.id.mapViewContainer);

        mapViewContainer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mapViewContainer.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                final int startScrollX = 0;
                final int endScrollX = 1200;

                long duration = 10000;

                ValueAnimator animator = ValueAnimator.ofInt(startScrollX, endScrollX);
                animator.setDuration(duration);

                animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        int scrollX = (int) animation.getAnimatedValue();
                        mapView.scrollTo(scrollX, 0);
                    }
                });

                animator.start();
            }
        });
    }
}

package in.zhul.test6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private TextView tv1, tv2;
    private EditText et;
    private Button btn_search;
    private Handler handler;
    private static final String BASE_URL = "http://192.168.1.126:5000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.initViews();
        this.searchProduct();
        this.initListeners();
    }

    private void initViews() {
        tv1 = (TextView) findViewById(R.id.tv_product);
        tv2 = (TextView) findViewById(R.id.tv_product_detail);
        et = (EditText) findViewById(R.id.et_product_id);
        btn_search = (Button) findViewById(R.id.btn_search);
        handler = new Handler(Looper.getMainLooper());
    }

    private void searchProduct() {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/list.do";
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Request request = new Request.Builder().url(url).build();
                    Response response = client.newCall(request).execute();
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                tv1.setText(result);
                            }
                        });
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
                }
            }
        }).start();
    }

    private void initListeners() {
        btn_search.setOnClickListener(v -> {
            String id = et.getText().toString();
            OkHttpClient client = new OkHttpClient();
            String url = BASE_URL + "/view.do?id=" + id;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Request request = new Request.Builder().url(url).build();
                        Response response = client.newCall(request).execute();
                        if (response.isSuccessful()) {
                            String result = response.body().string();
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    tv2.setText(result);
                                }
                            });
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
                    }
                }
            }).start();
        });
    }
}
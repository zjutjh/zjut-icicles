package in.zhul.test8;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView ivAirplane;
    private ImageView ivController;
    private ImageView btnShoot;
    private boolean isDrawBullet = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivAirplane = findViewById(R.id.ivAirplane);
        ivController = findViewById(R.id.ivController);
        btnShoot = findViewById(R.id.btnShoot);

        ivController.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                moveAirplane(event);
                return true;
            }
        });

        btnShoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isDrawBullet) {
                    isDrawBullet = true;
                    shootBullet();
                }
            }
        });
    }

    private void moveAirplane(MotionEvent event) {
        float centerX = ivController.getWidth() / 2;
        float centerY = ivController.getHeight() / 2;

        float x = event.getX() - centerX;
        float y = event.getY() - centerY;

        Log.d("zhul", "x: " + x + " y: " + y);

        float airplaneX = ivAirplane.getX();
        float airplaneY = ivAirplane.getY();

        if (Math.abs(x) > Math.abs(y)) {
            if (x > 0) {
                airplaneX += 10;
            } else {
                airplaneX -= 10;
            }
        } else {
            if (y > 0) {
                airplaneY += 10;
            } else {
                airplaneY -= 10;
            }
        }

        if (airplaneX < 0) {
            airplaneX = 0;
        } else if (airplaneX > findViewById(R.id.rlMain).getWidth() - ivAirplane.getWidth()) {
            airplaneX = findViewById(R.id.rlMain).getWidth() - ivAirplane.getWidth();
        }
        if (airplaneY < 0) {
            airplaneY = 0;
        } else if (airplaneY > findViewById(R.id.rlMain).getHeight() - ivAirplane.getHeight()) {
            airplaneY = findViewById(R.id.rlMain).getHeight() - ivAirplane.getHeight();
        }

        ivAirplane.setX(airplaneX);
        ivAirplane.setY(airplaneY);
    }


    private void shootBullet() {
        final ImageView bullet = new ImageView(this);
        bullet.setImageResource(R.drawable.bullet);

        bullet.setX(ivAirplane.getX() + ivAirplane.getWidth() / 2 - bullet.getWidth() / 2);
        bullet.setY(ivAirplane.getY());

        ((RelativeLayout) findViewById(R.id.rlMain)).addView(bullet);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                bullet.setY(bullet.getY() - 10);

                if (bullet.getY() > 0) {
                    handler.postDelayed(this, 20);
                } else {
                    ((RelativeLayout) findViewById(R.id.rlMain)).removeView(bullet);
                    isDrawBullet = false;
                }
            }
        }, 20);
    }
}

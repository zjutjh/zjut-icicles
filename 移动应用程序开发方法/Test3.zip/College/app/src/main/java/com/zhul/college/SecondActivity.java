package com.zhul.college;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        recyclerView = findViewById(R.id.recyclerView);

        String selectedCollege = getIntent().getStringExtra("college");

        List<DataModel> data = new ArrayList<>();

        if ("计算机学院".equals(selectedCollege)) {
            for (int i = 1; i <= 5; i++) {
                data.add(new DataModel(i, getName(i), getGender(i)));
            }
        } else if ("机械学院".equals(selectedCollege)) {
            for (int i = 6; i <= 10; i++) {
                data.add(new DataModel(i, getName(i), getGender(i)));
            }
        }

        CustomAdapter adapter = new CustomAdapter(data);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private String getName(int i) {
        String ret = "";
        switch (i){
            case 1:
                ret = "张三";
                break;
            case 2:
                ret = "VINCENT";
                break;
            case 3:
                ret = "MARRY";
                break;
            case 4:
                ret = "吴六";
                break;
            case 5:
                ret = "陈七";
                break;
            case 6:
                ret = "TOM";
                break;
            case 7:
                ret = "李四";
                break;
            case 8:
                ret = "王五";
                break;
            case 9:
                ret = "JACK";
                break;
            case 10:
                ret = "宋八";
                break;
        }
        return ret;
    }

    private String getGender(int i) {
        String ret = "";
        switch (i){
            case 1:
            case 3:
            case 4:
            case 8:
            case 9:
            case 10:
                ret = "男";
                break;
            case 2:
            case 5:
            case 6:
            case 7:
                ret = "女";
                break;
        }
        return ret;
    }

    private static class CustomAdapter extends RecyclerView.Adapter<CustomViewHolder> {

        private List<DataModel> data;

        public CustomAdapter(List<DataModel> data) {
            this.data = data;
        }

        @NonNull
        @Override
        public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_layout, parent, false);
            return new CustomViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
            DataModel item = data.get(position);
            holder.col1TextView.setText(String.valueOf(item.getNumber()));
            holder.col2TextView.setText(item.getName());
            holder.col3TextView.setText(item.getGender());
        }

        @Override
        public int getItemCount() {
            return data.size();
        }
    }

    private static class CustomViewHolder extends RecyclerView.ViewHolder {

        TextView col1TextView;
        TextView col2TextView;
        TextView col3TextView;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            col1TextView = itemView.findViewById(R.id.col1TextView);
            col2TextView = itemView.findViewById(R.id.col2TextView);
            col3TextView = itemView.findViewById(R.id.col3TextView);
        }
    }

    private static class DataModel {
        private int number;
        private String name;
        private String gender;

        public DataModel(int number, String name, String gender) {
            this.number = number;
            this.name = name;
            this.gender = gender;
        }

        public int getNumber() {
            return number;
        }

        public String getName() {
            return name;
        }

        public String getGender() {
            return gender;
        }
    }
}

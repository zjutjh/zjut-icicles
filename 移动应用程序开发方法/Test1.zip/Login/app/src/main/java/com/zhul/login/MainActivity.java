package com.zhul.login;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private ImageView resultImageView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        resultImageView = findViewById(R.id.resultImageView);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 获取输入的用户名和密码
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // 进行用户名密码验证
                if (username.equals("admin") && password.equals("12345")) {
                    // 登录成功
                    resultImageView.setImageResource(R.drawable.right);
                    resultImageView.setVisibility(View.VISIBLE);
                } else {
                    // 登录失败
                    resultImageView.setImageResource(R.drawable.wrong);
                    resultImageView.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}
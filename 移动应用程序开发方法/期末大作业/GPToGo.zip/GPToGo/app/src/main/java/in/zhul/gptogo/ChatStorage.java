package in.zhul.gptogo;

import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class ChatStorage {
    public ArrayList<sendMessage> chats;

    public ChatStorage() {
        chats = new ArrayList<sendMessage>();
        chats.add(new sendMessage());
    }

    public ChatStorage(String json) {
        Gson gson = new Gson();
        ChatStorage chatStorage = gson.fromJson(json, ChatStorage.class);
        this.chats = chatStorage.chats;
    }

    public int getChatCount() {
        return chats.size();
    }

    public void deleteChat(int index) {
        chats.remove(index);
    }

    public void appendChat(sendMessage message) {
        if (chats == null) {
            chats = new ArrayList<sendMessage>();
        }
        chats.add(message);
    }

    public sendMessage getChatMessage(int index) {
        return chats.get(index);
    }
    public String getJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}

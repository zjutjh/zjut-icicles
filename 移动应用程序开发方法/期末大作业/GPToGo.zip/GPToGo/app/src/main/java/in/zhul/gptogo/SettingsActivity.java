package in.zhul.gptogo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

public class SettingsActivity extends AppCompatActivity {
    private EditText baseUrlEditText;
    private EditText tokenEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        baseUrlEditText = findViewById(R.id.editTextBaseUrl);
        tokenEditText = findViewById(R.id.editTextToken);
        Button saveButton = findViewById(R.id.btnSave);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        baseUrlEditText.setText(preferences.getString("BASE_URL", ""));
        tokenEditText.setText(preferences.getString("TOKEN", ""));

        saveButton.setOnClickListener(v -> onSaveClick());
    }

    public void onSaveClick() {
        String baseUrl = baseUrlEditText.getText().toString();
        String token = tokenEditText.getText().toString();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("BASE_URL", baseUrl);
        editor.putString("TOKEN", token);
        editor.apply();

        finish();
    }
}


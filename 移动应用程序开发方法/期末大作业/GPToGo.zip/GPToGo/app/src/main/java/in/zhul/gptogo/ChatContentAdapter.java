package in.zhul.gptogo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.text.Spanned;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zhpan.indicator.IndicatorView;

import io.noties.markwon.Markwon;

public class ChatContentAdapter extends RecyclerView.Adapter<ChatContentAdapter.ViewHolder> {

    private ChatStorage chatStorage;
    private Markwon markwon;

    public ChatContentAdapter(ChatStorage chatStorage, Markwon markwon) {
        this.chatStorage = chatStorage;
        this.markwon = markwon;
    }


    @NonNull
    @Override
    public ChatContentAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_content, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ChatContentAdapter.ViewHolder holder, int position) {
        sendMessage message = chatStorage.getChatMessage(position);
        String content = message.toMarkdown();
        Spanned spanned = markwon.toMarkdown(content);
        holder.textView.setText(spanned);
    }

    @Override
    public int getItemCount() {
        return chatStorage.getChatCount();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textViewChat);
        }
    }
}

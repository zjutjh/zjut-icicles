package in.zhul.gptogo;

import java.util.List;

public class receivedMessage {
    private String id;
    private String object;
    private long created;
    private String model;
    private List<Choice> choices;
    private Usage usage;
    private String system_fingerprint;

    public List<Choice> getChoices() {
        return choices;
    }

    public static class Choice {
        private int index;
        private Message message;
        private Object logprobs;
        private String finish_reason;

        public Message getMessage() {
            return message;
        }

        public static class Message {
            private String role;
            private String content;

            public String getContent() {
                return content;
            }
        }
    }

    public static class Usage {
        private int prompt_tokens;
        private int completion_tokens;
        private int total_tokens;
    }
}

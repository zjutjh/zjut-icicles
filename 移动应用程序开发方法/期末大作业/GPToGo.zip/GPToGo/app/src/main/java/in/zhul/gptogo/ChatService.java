package in.zhul.gptogo;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ChatService {
    @Headers({
            "Content-Type: application/json",
    })

    @POST("v1/chat/completions")
    Call<receivedMessage> sendMessage(@Header("Authorization") String auth, @Body sendMessage message);
}

package in.zhul.gptogo;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import androidx.viewpager2.widget.ViewPager2;

import com.zhpan.indicator.IndicatorView;
import com.zhpan.indicator.enums.IndicatorSlideMode;
import com.zhpan.indicator.enums.IndicatorStyle;

import io.noties.markwon.Markwon;
import io.noties.markwon.ext.tables.TablePlugin;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private EditText messageEditText;
    private ChatStorage chatStorage;
    private Markwon markwon;
    private ViewPager2 viewPager;
    private IndicatorView indicatorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkToken();

        initResources();

        initListeners();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        if (preferences.contains("ChatStorage")) {
            chatStorage = new ChatStorage(preferences.getString("ChatStorage", ""));
        } else {
            chatStorage = new ChatStorage();
        }

        viewPager.setAdapter(new ChatContentAdapter(chatStorage, markwon));
        init_indicator();

        if (preferences.contains("index")) {
            int currentItem = Integer.parseInt(preferences.getString("index", ""));
            viewPager.setCurrentItem(currentItem);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("messageEditText", messageEditText.getText().toString());
        savedInstanceState.putString("ChatStorage", chatStorage.getJson());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        messageEditText.setText(savedInstanceState.getString("messageEditText"));
        chatStorage = new ChatStorage(savedInstanceState.getString("ChatStorage"));
        viewPager.setAdapter(new ChatContentAdapter(chatStorage, markwon));
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("ChatStorage", chatStorage.getJson());
        editor.putString("index", String.valueOf(viewPager.getCurrentItem()));
        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.add_chat) {
            chatStorage.appendChat(new sendMessage());
            int currentItem = chatStorage.getChatCount() - 1;
            viewPager.getAdapter().notifyItemInserted(currentItem);
            viewPager.setCurrentItem(currentItem);
            indicatorView.setPageSize(viewPager.getAdapter().getItemCount());
            indicatorView.notifyDataChanged();
            return true;
        }

        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.copy_to_clipboard) {
            String text = chatStorage.getChatMessage(viewPager.getCurrentItem()).toMarkdown();
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clipData = ClipData.newPlainText("text", text);
            clipboard.setPrimaryClip(clipData);
            Toast.makeText(this, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show();
            return true;
        }

        if (item.getItemId() == R.id.delete_current_chat) {
            int currentItem = viewPager.getCurrentItem();
            chatStorage.deleteChat(currentItem);
            viewPager.getAdapter().notifyItemRemoved(currentItem);
            indicatorView.setPageSize(viewPager.getAdapter().getItemCount());
            if (chatStorage.getChatCount() == 0) {
                chatStorage.appendChat(new sendMessage());
                viewPager.getAdapter().notifyItemInserted(0);
                indicatorView.setPageSize(viewPager.getAdapter().getItemCount());
            }
            indicatorView.notifyDataChanged();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initListeners() {
        Button sendButton = findViewById(R.id.btnSend);
        sendButton.setOnClickListener(v -> onSendClick());
    }

    public void onSendClick() {
        checkToken();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String baseUrl = preferences.getString("BASE_URL", "https://api.openai.com/");
        String token = preferences.getString("TOKEN", "");
        ChatService chatService = ChatApiClient.getClient(baseUrl).create(ChatService.class);

        String message = messageEditText.getText().toString();
        if (message.isEmpty()) {
            Toast.makeText(this, R.string.please_enter_a_message, Toast.LENGTH_SHORT).show();
            return;
        }

        updateChatView();
        chatStorage.getChatMessage(viewPager.getCurrentItem()).appendMessage("user", message);

        Call<receivedMessage> call = chatService.sendMessage("Bearer "+ token, chatStorage.getChatMessage(viewPager.getCurrentItem()));
        call.enqueue(new Callback<receivedMessage>() {
            @Override
            public void onResponse(Call<receivedMessage> call, Response<receivedMessage> response) {
                String message = response.body().getChoices().get(0).getMessage().getContent();
                updateChatView();
                chatStorage.getChatMessage(viewPager.getCurrentItem()).appendMessage("assistant", message);
            }

            @Override
            public void onFailure(Call<receivedMessage> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        messageEditText.setText("");
    }

    private void updateChatView() {
        viewPager.getAdapter().notifyItemChanged(viewPager.getCurrentItem());
    }

    private void checkToken() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (!preferences.contains("TOKEN")) {
            Toast.makeText(this, R.string.please_enter_a_token, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingsActivity.class));
        }
    }

    private void initResources(){
        messageEditText = findViewById(R.id.editTextMessage);
        viewPager = findViewById(R.id.viewPager);
        indicatorView = findViewById(R.id.indicator_view);
        markwon = Markwon.builder(this).usePlugin(TablePlugin.create(this)).build();
    }

    private void init_indicator(){
        indicatorView.setSliderColor(Color.WHITE, Color.GRAY);
        indicatorView.setSliderWidth(40F);
        indicatorView.setSliderHeight(10f);
        indicatorView.setSlideMode(IndicatorSlideMode.WORM);
        indicatorView.setIndicatorStyle(IndicatorStyle.ROUND_RECT);
        indicatorView.setPageSize(viewPager.getAdapter().getItemCount());
        indicatorView.setupWithViewPager(viewPager);
        indicatorView.notifyDataChanged();
    }
}

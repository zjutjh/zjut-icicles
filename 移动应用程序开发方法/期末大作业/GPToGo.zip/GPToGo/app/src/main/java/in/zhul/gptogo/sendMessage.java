package in.zhul.gptogo;

import java.util.ArrayList;
import com.google.gson.Gson;

public class sendMessage {
    private String model;
    private ArrayList<Message> messages;

    public sendMessage () {
        this.model = "gpt-3.5-turbo";
    }

    public sendMessage (String json) {
        Gson gson = new Gson();
        sendMessage message = gson.fromJson(json, sendMessage.class);
        this.model = message.model;
        this.messages = message.messages;
    }

    public void appendMessage(String role, String content) {
        if (messages == null) {
            messages = new ArrayList<Message>();
        }
        messages.add(new Message(role, content));
    }

    public String toMarkdown() {
        String content = "";
        if (messages == null) {
            return content;
        }
        for (Message msg : messages) {
            if (msg.role.equals("user")) {
                content += "> " + msg.content + "\n\n";
            } else {
                content += msg.content + "\n\n";
            }
        }
        return content;
    }

    public static class Message {
        private String role;
        private String content;

        public Message(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
}
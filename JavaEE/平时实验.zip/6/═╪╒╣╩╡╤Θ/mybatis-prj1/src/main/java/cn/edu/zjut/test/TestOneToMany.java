package cn.edu.zjut.test;

import cn.edu.zjut.po.Customer;
import cn.edu.zjut.po.Order;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class TestOneToMany {

    public static void main(String[] args) {
        try {
            // Load MyBatis configuration
            InputStream config = Resources.getResourceAsStream("mybatis-config.xml");
            SqlSessionFactory ssf = new SqlSessionFactoryBuilder().build(config);
            SqlSession ss = ssf.openSession();

            try {

                int customerId = 1;
                List<Order> orders = ss.selectList("OrderMapper.getOrdersByCustomerId", customerId);

                System.out.println("Orders for Customer " + customerId + ":");
                for (Order order : orders) {
                    System.out.println(order);
                }

            } finally {
                ss.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

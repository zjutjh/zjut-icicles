package cn.edu.zjut.po;

public class IDcard {
    private short id;
    private String code;

    public short getId() {
        return id;
    }
    public void setId(short id) {
        this.id = id;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    @Override
    public String toString() {
        return "IDcard{code='" + code + "'}";
    }
}

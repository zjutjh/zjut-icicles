package cn.edu.zjut.test;

import cn.edu.zjut.dao.UserDao;
import cn.edu.zjut.po.MyUser;
import cn.edu.zjut.pojo.MapUser;
import cn.edu.zjut.pojo.SelectUserParam;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class MyBatisTest {
    public static void main(String[] args) {
        try {
            InputStream config = Resources.getResourceAsStream("mybatis-config.xml");
            SqlSessionFactory ssf = new SqlSessionFactoryBuilder().build(config);
            SqlSession ss = ssf.openSession();

            try {
//                MyUser addmu=new MyUser();
//                addmu.setUname("陈一");
//                addmu.setUsex("男");
//                ss.insert("UserMapper.addUser",addmu);
//
//                Map<String, Object> map=new HashMap<>();
//                map.put("u_name", "陈");
//                map.put("u_sex", "男");
//                List<MyUser> list=ss.selectList("UserMapper.selectAllUser",map);
//                for(MyUser myUser : list){
//                    System.out.println(myUser);
//                }
//                Map<String, Object> map=new HashMap<>();
//                map.put("u_name", "陈");
//                map.put("u_sex", "男");
//                UserDao userDao = ss.getMapper(UserDao.class);
//                List<MyUser> list = userDao.selectAllUser(map);
//                for(MyUser myUser : list){
//                    System.out.println(myUser);
//                }
//                SelectUserParam su = new SelectUserParam();
//                su.setU_name("陈");
//                su.setU_sex("男");
//                List<MyUser> list=ss.selectList("UserMapper.selectAllUser",su);
//                for(MyUser myUser : list){
//                    System.out.println(myUser);
//                }
//                List<Map<String, Object>> lmp=ss.selectList("UserMapper.selectAllUser");
//                for(Map<String, Object> myUser : lmp){
//                    System.out.println(myUser);
//                }
//                List<MapUser> list = ss.selectList("UserMapper.selectResultMap");
//                for(MapUser myUser : list){
//                    System.out.println(myUser);
//                }
                // 1. Test select with resultMap
                List<MapUser> selectList = ss.selectList("UserMapper.selectResultMap");
                System.out.println("Select Result with ResultMap:");
                for (MapUser myUser : selectList) {
                    System.out.println(myUser);
                }

                // 2. Test insert with parameterMap
                MyUser addUser = new MyUser();
                addUser.setUname("NewUser");
                addUser.setUsex("Female");

                int insertResult = ss.insert("UserMapper.addUserWithParamMap", addUser);
                System.out.println("Insert Result: " + insertResult);

                // 3. Test update with parameterMap
                MyUser updateUser = new MyUser();
                updateUser.setUid(1);
                updateUser.setUname("UpdatedName");
                updateUser.setUsex("UpdatedSex");

                int updateResult = ss.update("UserMapper.updateUserWithParamMap", updateUser);
                System.out.println("Update Result: " + updateResult);

                // 4. Test delete with parameterMap
                MyUser deleteUser = new MyUser();
                deleteUser.setUid(6);

                int deleteResult = ss.delete("UserMapper.deleteUserWithParamMap", deleteUser);
                System.out.println("Delete Result: " + deleteResult);

                ss.commit();
            } finally {
                ss.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

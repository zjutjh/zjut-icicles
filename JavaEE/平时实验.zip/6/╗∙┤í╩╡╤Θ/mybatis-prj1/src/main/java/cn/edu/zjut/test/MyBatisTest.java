package cn.edu.zjut.test;

import cn.edu.zjut.po.MyUser;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MyBatisTest {
    public static void main(String[] args) {
        try {
            InputStream config = Resources.getResourceAsStream("mybatis-config.xml");
            SqlSessionFactory ssf = new SqlSessionFactoryBuilder().build(config);
            SqlSession ss = ssf.openSession();

            try {
                // 查询一个用户
                System.out.println("查询一个用户：");
                MyUser mu = ss.selectOne("UserMapper.selectUserById", 1);
                System.out.println(mu);

                // 添加一个用户
                MyUser addmu = new MyUser();
//                addmu.setUid(5);
                addmu.setUname("张三");
                addmu.setUsex("男");
                ss.insert("UserMapper.addUser", addmu);

                // 修改一个用户
                System.out.println("修改一个用户：");
                MyUser updateMu = new MyUser();
                updateMu.setUid(1);
                updateMu.setUname("用户1");
                updateMu.setUsex("女");
                ss.update("UserMapper.updateUser", updateMu);
                MyUser mu1 = ss.selectOne("UserMapper.selectUserById", 1);
                System.out.println(mu1);

                // 删除一个用户
                ss.delete("UserMapper.deleteUser", 1);

                // 查询所有用户
                System.out.println("查询所有用户：");
                List<MyUser> allUsers = ss.selectList("UserMapper.selectAllUser");
                for (MyUser user : allUsers) {
                    System.out.println(user);
                }

                ss.commit();
            } finally {
                ss.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

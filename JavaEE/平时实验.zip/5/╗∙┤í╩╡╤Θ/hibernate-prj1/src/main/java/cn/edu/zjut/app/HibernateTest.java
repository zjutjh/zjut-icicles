package cn.edu.zjut.app;
import cn.edu.zjut.dao.*;
import cn.edu.zjut.po.*;
import cn.edu.zjut.service.*;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;

import java.util.List;

public class HibernateTest {
    public static void main(String[] args) {
       Customer loginUser = new Customer();
       loginUser.setCustomerId(1);
       loginUser.setAccount("zjut");
       loginUser.setPassword("Zjut");
       UserService uService =new UserService();
       if(uService.login(loginUser))
           System.out.println(loginUser.getAccount()+" loginSuccess!");
       else
           System.out.println(loginUser.getAccount()+" loginFail!");

    }
}
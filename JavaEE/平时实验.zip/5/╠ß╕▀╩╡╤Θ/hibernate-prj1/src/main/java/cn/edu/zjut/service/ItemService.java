package cn.edu.zjut.service;
import java.util.List;
import java.util.ArrayList;
import cn.edu.zjut.dao.ItemDAO;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;

public class ItemService {
    public Session getSession() {
//        SessionFactory sf= new Configuration().configure().buildSessionFactory();
//        return sf.openSession();
        return HibernateUtil.getSession();
    }
    private List items = new ArrayList();
    public List getAllItems() {
        Session session=this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);
        List items = dao.findAll();
        HibernateUtil.closeSession();
        return items;
    }
}
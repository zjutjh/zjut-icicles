package cn.edu.zjut.app;
import cn.edu.zjut.dao.*;
import cn.edu.zjut.po.*;
import cn.edu.zjut.service.*;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;

import java.util.List;

public class HibernateTest {
    public static void main(String[] args) {
        // 创建用户对象
        Customer newUser = new Customer();
        newUser.setAccount("newUserAccount");
        newUser.setPassword("password123");
        newUser.setName("New User");
        newUser.setSex(true);

        // 创建联系方式对象
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhone("1234567890");
        contactInfo.setEmail("newuser@example.com");
        contactInfo.setAddress("123 Main St");
        contactInfo.setZipcode("12345");
        contactInfo.setFax("9876543210");

        // 将联系方式对象设置到用户对象中
        newUser.setContactInfo(contactInfo);

        // 注册用户
        UserService userService = new UserService();
        boolean registrationResult = userService.register(newUser);

        // 输出注册结果
        if (registrationResult) {
            System.out.println("User registration successful!");
        } else {
            System.out.println("User registration failed.");
        }
    }
}
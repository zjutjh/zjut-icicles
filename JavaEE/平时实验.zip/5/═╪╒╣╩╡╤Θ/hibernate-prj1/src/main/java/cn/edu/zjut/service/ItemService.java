package cn.edu.zjut.service;
import java.util.List;
import java.util.ArrayList;
import cn.edu.zjut.dao.ItemDAO;
import cn.edu.zjut.po.Item;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;

public class ItemService {
    public Session getSession() {
//        SessionFactory sf= new Configuration().configure().buildSessionFactory();
//        return sf.openSession();
        return HibernateUtil.getSession();
    }
    private List items = new ArrayList();
    public List getAllItems() {
        Session session=this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);
        List items = dao.findAll();
        HibernateUtil.closeSession();
        return items;
    }
    public List findByHql() {
        Session session = this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);

        try {
//            String hql = "from cn.edu.zjut.po.Item";
//            String hql = "from Item";
//            String hql = "from Item as item";
//            List list = dao.findByHql(hql);
//            return list;
//            String hql = "select item.ipk.title from Item as item";
//            List<String> list = dao.findByHql(hql);
            String hql = "select item.ipk.title, item.cost from Item as item";
            List<Object[]>list = dao.findByHql(hql);
            return list;
        } finally {
            HibernateUtil.closeSession();
        }
    }

    public List findItemsWithAggregation() {
        Session session = this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);

        try {
            // 使用聚集函数
            String hql = "select count(*), avg(item.cost), sum(item.cost) from Item as item";
            return dao.findByHql(hql);
        } finally {
            HibernateUtil.closeSession();
        }
    }

    public List findItemsWithWhereClause() {
        Session session = this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);

        try {
            // 使用 WHERE 子句
            String hql = "from Item as item where item.cost > 20.0";
            return dao.findByHql(hql);
        } finally {
            HibernateUtil.closeSession();
        }
    }

    public List findItemsWithOrderBy() {
        Session session = this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);

        try {
            // 使用 ORDER BY 子句
            String hql = "from Item as item order by item.cost desc";
            return dao.findByHql(hql);
        } finally {
            HibernateUtil.closeSession();
        }
    }

    public List findItemsWithSubquery() {
        Session session = this.getSession();
        ItemDAO dao = new ItemDAO();
        dao.setSession(session);

        try {
            // 使用子查询
            String hql = "from Item as item where item.cost > (select avg(cost) from Item)";
            return dao.findByHql(hql);
        } finally {
            HibernateUtil.closeSession();
        }
    }


}
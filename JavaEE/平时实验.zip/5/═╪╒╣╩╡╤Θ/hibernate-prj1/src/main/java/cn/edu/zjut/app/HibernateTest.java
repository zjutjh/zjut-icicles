package cn.edu.zjut.app;
import cn.edu.zjut.dao.*;
import cn.edu.zjut.po.*;
import cn.edu.zjut.service.*;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class HibernateTest {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSession();

        ItemService itemService = new ItemService();
//        List<Item> itemList = itemService.findByHql();
//
//        for (Item item : itemList) {
//            System.out.println("商品ID:" + item.getIpk().getItemID());
//            System.out.println("商品名称:" + item.getIpk().getTitle());
//            System.out.println("商品说明:" + item.getDescription());
//            System.out.println("商品单价:" + item.getCost());
//            System.out.println("------------");
//        }

//        itemService.findByHql().forEach(System.out::println);
//
//        List<Object[]> resultList = itemService.findByHql();
//        for (Object[] result : resultList) {
//            for (Object obj : result) {
//                System.out.print(obj + " ");
//            }
//            System.out.println();
//        }

        System.out.println("Items count, average cost, total cost:");
        itemService.findItemsWithAggregation().forEach(System.out::println);

        System.out.println("\nItems with cost greater than 20.0:");
        itemService.findItemsWithWhereClause().forEach(System.out::println);

        System.out.println("\nItems ordered by cost (descending):");
        itemService.findItemsWithOrderBy().forEach(System.out::println);

        System.out.println("\nItems with cost greater than average cost:");
        itemService.findItemsWithSubquery().forEach(System.out::println);

        HibernateUtil.closeSession();


    }
}
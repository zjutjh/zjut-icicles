package cn.edu.zjut.po;

import java.sql.Blob;

public class Item {
//    private String itemID;
//    private String title;
    private ItemPK ipk;
    private String description;
    private float cost;

    public Item() {}

    @Override
    public String toString() {
        return "Item{" +
                "ipk=" + ipk +
                ", description='" + description + '\'' +
                ", cost=" + cost +
                '}';
    }

//    public Item(String itemID) {this.itemID = itemID; }

//    public Item(String itemID, String title, String description, float cost) {
//        this.itemID = itemID;
//        this.title = title;
//        this.description = description;
//        this.cost = cost;
//    }

    public Item(ItemPK ipk, String description, float cost, Blob image) {
        this.ipk = ipk;
        this.description = description;
        this.cost = cost;
    }

//    public String getItemID() { return itemID;  }
//    public void setItemID(String itemID) { this.itemID = itemID; }
//    public String getTitle() {return title;   }
//    public void setTitle(String title) {this.title = title;}

    public ItemPK getIpk() {return ipk;}
    public void setIpk(ItemPK ipk) {this.ipk = ipk;}
    public String getDescription() {return description;}
    public void setDescription(String description) {this.description = description;}
    public float getCost() {return cost;}
    public void setCost(float cost) {this.cost = cost;}

}

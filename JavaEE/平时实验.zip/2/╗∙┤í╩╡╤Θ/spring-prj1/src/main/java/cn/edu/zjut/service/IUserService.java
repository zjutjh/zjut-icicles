package cn.edu.zjut.service;
import cn.edu.zjut.bean.UserBean;
public interface IUserService {
    public void login(UserBean user);
}
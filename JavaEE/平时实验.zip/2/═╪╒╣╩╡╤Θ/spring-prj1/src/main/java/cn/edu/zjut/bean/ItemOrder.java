package cn.edu.zjut.bean;

public class ItemOrder implements IItemOrder {
    private IItem item;
    private int numItems;


    public IItem getItem() {
        return item;
    }


    public void setItem(IItem item) {
        this.item = item;
    }


    public int getNumItems() {
        return numItems;
    }


    public void setNumItems(int numItems) {
        this.numItems = numItems;
    }
}
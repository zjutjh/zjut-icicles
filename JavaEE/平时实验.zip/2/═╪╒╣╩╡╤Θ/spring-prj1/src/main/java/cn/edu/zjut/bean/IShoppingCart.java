package cn.edu.zjut.bean;

import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.Properties;

public interface IShoppingCart {
    List<ItemOrder> getItemsOrdered();
    void setItemsOrdered(List<ItemOrder> itemsOrdered);

    Set<Item> getSetOfItems();
    void setSetOfItems(Set<Item> setOfItems);

    Map<String, Item> getMapOfItems();
    void setMapOfItems(Map<String, Item> mapOfItems);

    Properties getPropertiesOfItems();
    void setPropertiesOfItems(Properties propertiesOfItems);
}

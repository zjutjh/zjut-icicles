package cn.edu.zjut.app;

import cn.edu.zjut.bean.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class SpringBeanTest1 {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

//        ShoppingCart shoppingCart = (ShoppingCart) ctx.getBean("shoppingcart");

//        List<ItemOrder> itemOrders = shoppingCart.getItemsOrdered();
//
//        for (IItemOrder itemOrder : itemOrders) {
//            System.out.println("书名：" + itemOrder.getItem().getTitle());
//            System.out.println("数量：" + itemOrder.getNumItems());
//        }

//        ShoppingCart shoppingCart = (ShoppingCart) ctx.getBean("shoppingcart1");
//
//        Set<Item> setOfItems = shoppingCart.getSetOfItems();
//        for (Item item : setOfItems) {
//            System.out.println("Set 书名：" + item.getTitle());
//        }
//
//        Map<String, Item> mapOfItems = shoppingCart.getMapOfItems();
//        for (Map.Entry<String, Item> entry : mapOfItems.entrySet()) {
//            System.out.println("Map 书名：" + entry.getValue().getTitle());
//            System.out.println("Map 键：" + entry.getKey());
//            // 打印其他属性
//        }
//
//        Properties propertiesOfItems = shoppingCart.getPropertiesOfItems();
//        System.out.println("Properties item1 value: " + propertiesOfItems.getProperty("item1"));
//        System.out.println("Properties item2 value: " + propertiesOfItems.getProperty("item2"));

        UserBean user = (UserBean) ctx.getBean("userBean");

        ShoppingCart shoppingCart = user.getShoppingCart();
        System.out.println("用户购物车中的商品信息：");

        for (ItemOrder itemOrder : shoppingCart.getItemsOrdered()) {
            Item item = (Item) itemOrder.getItem();
            System.out.println("书名：" + item.getTitle());
            System.out.println("数量：" + itemOrder.getNumItems());
            // 打印其他属性
            System.out.println();
        }

    }
}

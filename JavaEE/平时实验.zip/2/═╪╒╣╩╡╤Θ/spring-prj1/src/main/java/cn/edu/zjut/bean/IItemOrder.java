package cn.edu.zjut.bean;

public interface IItemOrder {
    IItem getItem();

    void setItem(IItem item);
    

    int getNumItems();

    void setNumItems(int numItems);
}

package cn.edu.zjut.bean;

import java.util.*;

public class ShoppingCart implements IShoppingCart {
    private List<ItemOrder> itemsOrdered;
    private Set<Item> setOfItems;
    private Map<String, Item> mapOfItems;
    private Properties propertiesOfItems;

    public List<ItemOrder> getItemsOrdered() {
        return itemsOrdered;
    }

    public void setItemsOrdered(List<ItemOrder> itemsOrdered) {
        this.itemsOrdered = itemsOrdered;
    }

    public Set<Item> getSetOfItems() {
        return setOfItems;
    }

    public void setSetOfItems(Set<Item> setOfItems) {
        this.setOfItems = setOfItems;
    }

    public Map<String, Item> getMapOfItems() {
        return mapOfItems;
    }

    public void setMapOfItems(Map<String, Item> mapOfItems) {
        this.mapOfItems = mapOfItems;
    }

    public Properties getPropertiesOfItems() {
        return propertiesOfItems;
    }

    public void setPropertiesOfItems(Properties propertiesOfItems) {
        this.propertiesOfItems = propertiesOfItems;
    }
}

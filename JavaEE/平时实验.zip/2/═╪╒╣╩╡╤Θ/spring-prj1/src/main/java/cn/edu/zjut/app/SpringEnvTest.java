package cn.edu.zjut.app;
import cn.edu.zjut.bean.*;
import cn.edu.zjut.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringEnvTest {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

        UserService userService = (UserService) ctx.getBean("userService");

//        UserBean user = new UserBean();
//        user.setUsername("username");
//
//        userService.checkShoppingCart(user);

        UserBean user1 = (UserBean) ctx.getBean("userBean");

        userService.checkShoppingCart(user1);
    }
}

package cn.edu.zjut.app;

import cn.edu.zjut.service.IUserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import cn.edu.zjut.service.UserService;
import cn.edu.zjut.bean.UserBean;

public class SpringAOPTest {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

        IUserService userService = (IUserService) ctx.getBean("userService");

        UserBean user = new UserBean();
        user.setUsername("Username");
        user.setPassword("Password");

        userService.login(user);
    }
}

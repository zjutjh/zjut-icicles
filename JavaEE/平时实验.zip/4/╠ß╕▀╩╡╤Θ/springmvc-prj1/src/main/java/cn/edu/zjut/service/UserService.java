package cn.edu.zjut.service;

import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.service.IUserService;
import org.springframework.stereotype.Service;

@Service("userServ")
public class UserService implements IUserService {
    @Override
    public boolean login(UserBean loginUser) {

        if (loginUser.getUsername().equals(loginUser.getPassword())) {
            return true;
        }
        return false;
    }

}

package cn.edu.zjut.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.Controller;
import java.lang.annotation.Annotation;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.mvc.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.zjut.service.IUserService;
import cn.edu.zjut.bean.UserBean;

@Controller
public class UserController {
//    private IUserService userServ;
//    public void setUserServ(IUserService userServ) {this.userServ=userServ; }
//    public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
//        return new ModelAndView("/loginSuccess.jsp");
//    }

//    public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
//        return new ModelAndView("loginSuccess");
//    }
    @Autowired
    @Qualifier("userServ")
    private IUserService userServ;

//    @RequestMapping("/login")
//    public String login(UserBean user, Model model) {
//        if (userServ.login(user)) {
//            model.addAttribute("uname", user.getUsername());
//            return "loginSuccess";
//        }
//        else return "login";
//    }

//    @RequestMapping("/login")//暴露为模型数据
//    public String login( @ModelAttribute("user") UserBean user) {
//        if (userServ.login(user)) {
////            model.addAttribute("user", user);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login( String username, String password, Model model) {
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login(@RequestRaram String username, @RequestRaram String password, Model model) {
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login( HttpServletRequest req, Model model) {
//        String username=req.getParameter("username");
//        String password=req.getParameter("password");
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
    @RequestMapping(value="/login/{username}/{password}", method= RequestMethod.GET)
    public String login(@PathVariable String username, @PathVariable String password, Model model) {
        if (username.equals(password)) {
            model.addAttribute("uname", username);
            return "loginSuccess";
        }
        else return "login";
    }

}
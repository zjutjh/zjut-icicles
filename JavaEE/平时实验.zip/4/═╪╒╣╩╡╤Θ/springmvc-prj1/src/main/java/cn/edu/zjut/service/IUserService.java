package cn.edu.zjut.service;
import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.bean.User;
import  java.util.ArrayList;

public interface IUserService {
    boolean login(UserBean loginUser);
//    boolean register(UserBean loginUser);
    boolean addUser(User u);
    ArrayList<User> getUsers();
}

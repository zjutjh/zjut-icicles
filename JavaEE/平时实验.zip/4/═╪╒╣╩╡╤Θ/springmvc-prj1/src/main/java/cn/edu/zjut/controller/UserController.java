package cn.edu.zjut.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.zjut.bean.User;
import cn.edu.zjut.service.UserService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.Controller;
import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.mvc.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.zjut.service.IUserService;
import cn.edu.zjut.bean.UserBean;

@Controller
@RequestMapping ("/user")
public class UserController {
//    private IUserService userServ;
//    public void setUserServ(IUserService userServ) {this.userServ=userServ; }
//    public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
//        return new ModelAndView("/loginSuccess.jsp");
//    }

//    public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
//        return new ModelAndView("loginSuccess");
//    }
//    @Autowired
//    @Qualifier("userServ")
//    private IUserService userServ;

//    @RequestMapping("/login")
//    public String login(UserBean user, Model model) {
//        if (userServ.login(user)) {
//            model.addAttribute("uname", user.getUsername());
//            return "loginSuccess";
//        }
//        else return "login";
//    }

//    @RequestMapping("/login")//暴露为模型数据
//    public String login( @ModelAttribute("user") UserBean user) {
//        if (userServ.login(user)) {
////            model.addAttribute("user", user);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login( String username, String password, Model model) {
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login(@RequestRaram String username, @RequestRaram String password, Model model) {
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    public String login( HttpServletRequest req, Model model) {
//        String username=req.getParameter("username");
//        String password=req.getParameter("password");
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }
//    @RequestMapping(value="/login/{username}/{password}", method= RequestMethod.GET)
//    public String login(@PathVariable String username, @PathVariable String password, Model model) {
//        if (username.equals(password)) {
//            model.addAttribute("uname", username);
//            return "loginSuccess";
//        }
//        else return "login";
//    }

    private static final Log logger= LogFactory.getLog(UserController.class);
    @Autowired
    private UserService userService;
    @RequestMapping(value="/input")
    public String inputUser(Model model) {
        HashMap<String, String> hobbys = new HashMap<String, String>();
        hobbys.put("篮球", "篮球");
        hobbys.put("乒乓球", "乒乓球");
        hobbys.put("电玩", "电玩");
        hobbys.put("游泳", "游泳");//如果mode1中没有user属性，userAdd.sp会抛出异常，因为表单标签无法找到m.odelAttribute属性指定的form backing object
        model.addAttribute("user", new User());
        model.addAttribute("hobbys", hobbys);
        model.addAttribute("carrers", new String[]{"教师", "学生", "coding搬运工", "IT民工", "其他"});
        model.addAttribute("houseRegisters", new String[]{"北京", "上海", "广州", "深圳", "其他"});
        return "userAdd";
    }
    @RequestMapping (value ="/save")
    public String adduser(@ModelAttribute User user,Model model) {
        if (userService.addUser(user)) {
            logger.info("成功");
            return "redirect:/user/list";
        } else {
            logger.info("失败");
            HashMap<String, String> hobbys = new HashMap<String, String>();
            hobbys.put("篮球", "篮球");
            hobbys.put("乒乓球", "乒乓球");
            hobbys.put("电玩", "电玩");
            hobbys.put("游泳", "游泳");//这里不需要mode1.addAttribute("user",newUser()),因为@ModelAttribute指定form backing object
            model.addAttribute("hobbys", hobbys);
            model.addAttribute("carrers", new String[]{"教师", "学生", "coding搬运工", "IT民工", "其他"});
            model.addAttribute("houseRegisters", new String[]{"北京", "上海", "广州", "深圳", "其他"});
            return "userAdd";
        }
    }

    @RequestMapping(value = "/list")
    public String listUsers(Model model){
        List<User> users = userService.getUsers();
        model.addAttribute("users",users);
        return "userList";
    }


}
package cn.edu.zjut.service;

import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.bean.User;
import cn.edu.zjut.service.IUserService;
import org.springframework.stereotype.Service;
import  java.util.ArrayList;


@Service("userServ")
public class UserService implements IUserService {
    @Override
    public boolean login(UserBean loginUser) {

        if (loginUser.getUsername().equals(loginUser.getPassword())) {
            return true;
        }
        return false;
    }

    private static ArrayList<User> users=new ArrayList<User> ();
    @Override
    public boolean addUser(User u) {
        if (!"IT民工".equals(u.getCarrer())) { //不允许添加 IT 民工
            users.add(u);
            return true;
        }
        return false;
    }
    @Override
    public ArrayList<User> getUsers() {
        return users;
    }

}

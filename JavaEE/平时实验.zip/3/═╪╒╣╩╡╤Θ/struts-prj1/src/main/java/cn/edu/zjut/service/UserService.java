package cn.edu.zjut.service;

import cn.edu.zjut.bean.UserBean;

public class UserService implements IUserService {
    @Override
    public boolean login(UserBean loginUser) {
//        System.out.println("Username: " + loginUser.getUsername());
//        System.out.println("Password: " + loginUser.getPassword());

        if (loginUser.getUsername() != null && !loginUser.getUsername().isEmpty() &&
                loginUser.getPassword() != null && !loginUser.getPassword().isEmpty() &&
                loginUser.getUsername().equals(loginUser.getPassword())) {
            return true;
        }
        return false;

    }
    @Override
    public boolean register(UserBean loginUser){
        if (loginUser.getUsername() != null && !loginUser.getUsername().isEmpty() &&
                loginUser.getPassword() != null && !loginUser.getPassword().isEmpty() &&
                loginUser.getPassword().equals(loginUser.getRepassword())) {
            return true;
        }
        return false;
    }
}

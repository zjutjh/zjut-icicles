package cn.edu.zjut.service;
import cn.edu.zjut.bean.UserBean;

public interface IUserService {
    boolean login(UserBean loginUser);
    boolean register(UserBean loginUser);
}

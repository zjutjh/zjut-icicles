package cn.edu.zjut.action;
import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.service.IUserService;
import cn.edu.zjut.service.UserService;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
    private UserBean loginUser ;
    private IUserService userService ;

    public UserBean getLoginUser() {
        return loginUser;
    }
    public void setLoginUser(UserBean loginUser) {
        this.loginUser = loginUser;
    }
    public void setUserService(IUserService userService) {
        this.userService = userService;
    }
    public IUserService getUserService() {
        return userService;
    }

    public String login() {
        if (userService.login(loginUser)) {
            this.addActionMessage("登录成功！");
            return "success";
        }
        this.addActionError("用户名或密码错误，请重新输入！");
        return "fail";
    }

    public String register() {
        if (userService.register(loginUser)) {
            return "regsuccess";
        }
        return "regfail";
    }

    public void validateLogin() {
        if (loginUser == null) {
            this.addActionError("用户信息不能为空");
            return;
        }

        if (loginUser.getUsername() == null || loginUser.getUsername() .equals("")) {
            this.addFieldError("loginUser.username", "用户名不能为空");
            this.addFieldError("loginUser.username", "请输入您的用户名！");
        }
        if (loginUser.getPassword() == null || loginUser.getPassword().equals("")) {
            this.addFieldError("loginUser.password", "密码不能为空");
            this.addFieldError("loginUser.password", "请输入您的密码！");
        }
    }

    public void validateRegister() {
        if (loginUser == null) {
            this.addActionError("用户信息不能为空");
            return;
        }

        // 验证用户名是否为空
        if (loginUser.getUsername() == null || loginUser.getUsername().isEmpty()) {
            this.addFieldError("loginUser.username", "用户名不能为空");
        }

        // 验证密码是否为空
        if (loginUser.getPassword() == null || loginUser.getPassword().isEmpty()) {
            this.addFieldError("loginUser.password", "密码不能为空");
        }

        // 验证确认密码是否为空
        if (loginUser.getRepassword() == null || loginUser.getRepassword().isEmpty()) {
            this.addFieldError("loginUser.repassword", "确认密码不能为空");
        }

        // 验证两次密码输入是否相同
        if (!loginUser.getPassword().equals(loginUser.getRepassword())) {
            this.addFieldError("loginUser.repassword", "确认密码必须与密码相同");
        }

        // 验证email地址格式是否有效
        if (loginUser.getEmail() != null && !loginUser.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            this.addFieldError("loginUser.email", "请输入有效的电子邮件地址");
        }

    }

}





package cn.edu.zjut.service;

import cn.edu.zjut.dao.AddressDAO;
import org.hibernate.Session;
import org.hibernate.Transaction;

import cn.edu.zjut.dao.CustomerDAO;
import cn.edu.zjut.po.Address;
import cn.edu.zjut.po.Customer;
import cn.edu.zjut.util.HibernateUtil;

public class UserService {

    // public Session getSession() {
    //     // 使用 HibernateUtil 获取 Session
    //     return HibernateUtil.getSession();
    // }

    public boolean login(Customer loginUser) {
        // 在这里实现登录逻辑
        // 代码略
        return false;
    }

    public boolean addAddr(Customer loginUser, Address address) {

        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession();
        c_dao.setSession(session);
//        System.out.println("Before findById - User ID: " + loginUser.getCustomerId());
        loginUser = (Customer) c_dao.findById(loginUser.getCustomerId());
//        System.out.println("After findById - User ID: " + loginUser.getCustomerId());
//        System.out.println("Addresses before adding: " + loginUser.getAddresses().size());
//        address.setCustomer(loginUser);//注释 1
        if (loginUser == null) {
            return false;
        }
        loginUser.getAddresses().add(address);
//        System.out.println("Addresses after adding: " + loginUser.getAddresses().size());
        Transaction tran = null;
        try {
            tran = session.beginTransaction();
            c_dao.update(loginUser);
            tran.commit();
            return true;
        } catch (Exception e) {
            if (tran != null)
                tran.rollback();
//            System.out.println("Transaction rolled back due to exception: " + e.getMessage());
            return false;
        } finally {
            session.close();
        }
    }

    public boolean removeAddr(Customer loginUser, Address address) {
        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession();
        c_dao.setSession(session);

        loginUser = (Customer) c_dao.findById(loginUser.getCustomerId());
        if (loginUser == null) {
            return false;
        }

        Address addressToRemove = session.get(Address.class, address.getAddressId());
        if (addressToRemove == null) {
            return false;
        }

        loginUser.getAddresses().remove(addressToRemove);

        Transaction tran = null;
        try {
            tran = session.beginTransaction();
            c_dao.update(loginUser);
            tran.commit();
            return true;
        } catch (Exception e) {
            if (tran != null)
                tran.rollback();
            return false;
        } finally {
            session.close();
        }
    }

}


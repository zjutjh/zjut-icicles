package cn.edu.zjut.app;

import cn.edu.zjut.dao.CustomerDAO;
import cn.edu.zjut.dao.AddressDAO;
import cn.edu.zjut.po.Customer;
import cn.edu.zjut.po.Address;
import cn.edu.zjut.service.UserService;
import cn.edu.zjut.util.HibernateUtil;
import org.hibernate.Session;

public class HibernateTest {
    public static void main(String[] args) {
        UserService userService = new UserService();

        Customer user1 = new Customer();
        user1.setCustomerId(1);
        user1.setAccount("zjut");
        user1.setPassword("zjut");
        Address address1User1 = new Address();
        address1User1.setAddressId(1);
        address1User1.setDetail("Address 1 Detail for User 1");
        address1User1.setZipcode("123456");
        address1User1.setPhone("1234567890");
        address1User1.setType("Home");
        Address address2User1 = new Address();
        address2User1.setAddressId(2);
        address2User1.setDetail("Address 2 Detail for User 1");
        address2User1.setZipcode("789012");
        address2User1.setPhone("0987654321");
        address2User1.setType("Work");
        userService.addAddr(user1, address1User1);
        userService.addAddr(user1, address2User1);

        displayUserAddresses(user1.getCustomerId());
        System.out.println();
        userService.removeAddr(user1, address1User1);
        displayUserAddresses(user1.getCustomerId());

    }

    private static void displayUserAddresses(int customerId) {
        Session session = null;
        try {
            session = HibernateUtil.getSession();
            CustomerDAO customerDAO = new CustomerDAO();
            customerDAO.setSession(session);
            Customer user = customerDAO.findById(customerId);

            if (user != null) {
                System.out.println("User: " + user.getAccount() + " Addresses:");
                for (Address address : user.getAddresses()) {
                    System.out.println("Address ID: " + address.getAddressId());
                    System.out.println("Detail: " + address.getDetail());
                    System.out.println("Zipcode: " + address.getZipcode());
                    System.out.println("Phone: " + address.getPhone());
                    System.out.println("Type: " + address.getType());
                    System.out.println("-----------------------------");
                }
            } else {
                System.out.println("User not found.");
            }
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }
}

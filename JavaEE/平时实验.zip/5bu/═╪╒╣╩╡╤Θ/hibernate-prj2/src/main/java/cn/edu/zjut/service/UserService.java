package cn.edu.zjut.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import cn.edu.zjut.dao.CustomerDAO;
import cn.edu.zjut.po.Address;
import cn.edu.zjut.po.Customer;
import cn.edu.zjut.util.HibernateUtil;

public class UserService {

    public Customer login(int customerId, String account, String password) {
        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession();
        c_dao.setSession(session);

        Customer loginUser = (Customer) c_dao.findById(customerId);

        if (loginUser != null && loginUser.getAccount().equals(account) && loginUser.getPassword().equals(password)) {
            return loginUser;
        } else {
            return null;
        }
    }

    public boolean addAddr(Customer loginUser, Address address) {
        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession();
        c_dao.setSession(session);

        loginUser = (Customer) c_dao.findById(loginUser.getCustomerId());
        if (loginUser == null) {
            return false;
        }

        address.setCustomer(loginUser);

        loginUser.setAddress(address);

        Transaction tran = null;
        try {
            tran = session.beginTransaction();
            c_dao.update(loginUser);
            tran.commit();
            return true;
        } catch (Exception e) {
            if (tran != null)
                tran.rollback();
            return false;
        } finally {
            session.close();
        }
    }

    public boolean removeAddr(Customer loginUser, Address address) {
        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession();
        c_dao.setSession(session);

        loginUser = (Customer) c_dao.findById(loginUser.getCustomerId());
        if (loginUser == null) {
            return false;
        }

        Address addressToRemove = session.get(Address.class, address.getAddressId());
        if (addressToRemove == null) {
            return false;
        }

        loginUser.setAddress(null); 

        Transaction tran = null;
        try {
            tran = session.beginTransaction();
            c_dao.update(loginUser);
            tran.commit();
            return true;
        } catch (Exception e) {
            if (tran != null)
                tran.rollback();
            return false;
        } finally {
            session.close();
        }
    }

}

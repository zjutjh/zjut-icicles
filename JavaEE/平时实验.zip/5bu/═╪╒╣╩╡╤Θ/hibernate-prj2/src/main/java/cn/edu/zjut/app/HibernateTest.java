package cn.edu.zjut.app;

import cn.edu.zjut.po.Address;
import cn.edu.zjut.po.Customer;
import cn.edu.zjut.service.UserService;
import org.hibernate.Hibernate;
import org.hibernate.Session;

public class HibernateTest {

    public static void main(String[] args) {
        UserService userService = new UserService();
        Customer user1 = userService.login(1,"zjut", "zjut");

        if (user1 != null) {
            Address userAddress = user1.getAddress();
//            System.out.println(userAddress);
            if (userAddress != null) {
                System.out.println("User: " + user1.getAccount() + " Address:");
                System.out.println("Address ID: " + userAddress.getAddressId());
                System.out.println("Detail: " + userAddress.getDetail());
                System.out.println("Zipcode: " + userAddress.getZipcode());
                System.out.println("Phone: " + userAddress.getPhone());
                System.out.println("Type: " + userAddress.getType());
                System.out.println("----------------------------");
            } else {
                Address newAddress = new Address();
                newAddress.setDetail("New Address Detail");
                newAddress.setZipcode("123456");
                newAddress.setPhone("9876543210");
                newAddress.setType("Home");

                boolean addSuccess = userService.addAddr(user1, newAddress);

                if (addSuccess) {
                    System.out.println("New address added successfully!");
                } else {
                    System.out.println("Failed to add new address.");
                }
            }
        }
    }
}

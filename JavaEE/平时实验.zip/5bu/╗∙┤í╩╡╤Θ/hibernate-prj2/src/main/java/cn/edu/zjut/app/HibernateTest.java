package cn.edu.zjut.app;
import cn.edu.zjut.dao.*;
import cn.edu.zjut.po.*;
import cn.edu.zjut.service.*;
public class HibernateTest {
    public static void main(String[] args) {
        Customer loginUser = new Customer();
        loginUser.setCustomerId(1);
        loginUser.setAccount("zjut");
        loginUser.setPassword("Zjut");
        Address addr = new Address();
        addr.setAddressId(1);
        addr.setDetail("zjut");
        addr.setZipcode("310000");
        addr.setPhone("85290000");
        addr.setType("office");
        UserService uService =new UserService();
        if(uService.addAddr(loginUser,addr))
            System.out.println(loginUser.getAccount()+" add address "+addr.getDetail()+" Success!");
        else
            System.out.println(loginUser.getAccount()+" add address "+addr.getDetail()+" Fail!");
    }
}
package cn.edu.zjut.dao;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

import cn.edu.zjut.po.Customer;

public class CustomerDAO {

    private Session session;

    public void setSession(Session session) {
        this.session = session;
    }

    public Customer findById(int customerId) {
        String hql = "FROM Customer WHERE customerId = :id";
        Query<Customer> query = session.createQuery(hql, Customer.class);
        query.setParameter("id", customerId);
        return query.uniqueResult();
    }

    public void update(Customer customer) {
        session.update(customer);
    }
}
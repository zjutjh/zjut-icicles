package cn.edu.zjut.dao;

import org.hibernate.*;

import cn.edu.zjut.po.Address;

public class AddressDAO {
    private Session session;

    public void setSession(Session session) {
        this.session = session;
    }

    public void save(Address address) {
        session.save(address);
    }

}

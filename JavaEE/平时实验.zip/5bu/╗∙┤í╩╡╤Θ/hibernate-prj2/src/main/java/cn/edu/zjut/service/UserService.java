package cn.edu.zjut.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import cn.edu.zjut.dao.CustomerDAO;
import cn.edu.zjut.po.Address;
import cn.edu.zjut.po.Customer;
import cn.edu.zjut.util.HibernateUtil;

public class UserService {
    // 移除不再需要的方法
    // public Session getSession() {
    //     // 使用 HibernateUtil 获取 Session
    //     return HibernateUtil.getSession();
    // }

    public boolean login(Customer loginUser) {
        // 在这里实现登录逻辑
        // 代码略
        return false;
    }

    public boolean addAddr(Customer loginUser, Address address) {
        // 移除不再需要的 ActionContext 相关代码
        // ActionContext ctx = ActionContext.getContext();
        // Map<String, Object> request = (Map<String, Object>) ctx.get("request");

        CustomerDAO c_dao = new CustomerDAO();
        Session session = HibernateUtil.getSession(); // 直接使用 HibernateUtil 获取 Session
        c_dao.setSession(session);
        loginUser = (Customer) c_dao.findById(loginUser.getCustomerId());
//        address.setCustomer(loginUser);//注释 1

        loginUser.getAddresses().add(address);

        Transaction tran = null;
        try {
            tran = session.beginTransaction();
            c_dao.update(loginUser);
            tran.commit();
            return true;
        } catch (Exception e) {
            if (tran != null)
                tran.rollback();
//            System.out.println("Transaction rolled back due to exception: " + e.getMessage());
            return false;
        } finally {
            session.close();
        }
    }

    // Add other methods as needed
}


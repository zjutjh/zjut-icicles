package cn.edu.zjut.bean;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class ItemOrder implements IItemOrder, InitializingBean, DisposableBean {
    private IItem item;
    private int numItems;

    public ItemOrder() {
        System.out.println("Spring 实例化 ItemOrder...");
    }

    public void setItem(IItem item) {
        System.out.println("Spring 注入 item...");
        this.item = item;
    }

    public void setNumItems(int n) {
        System.out.println("Spring 注入 numItems...");
        this.numItems = n;
    }

    public IItem getItem() {
        return item;
    }

    public int getNumItems() {
        return numItems;
    }

    public void afterPropertiesSet() throws Exception {
        System.out.println("正在执行初始化方法 afterPropertiesSet...");
    }

    public void init() {
        System.out.println("正在执行初始化方法 init...");
    }

    public void destroy() throws Exception {
        System.out.println("正在销毁 ItemOrder...");
    }

    public void customDestroyMethod() {
        System.out.println("正在执行自定义销毁方法 customDestroyMethod...");
        // 添加需要在销毁之前执行的代码
    }

}

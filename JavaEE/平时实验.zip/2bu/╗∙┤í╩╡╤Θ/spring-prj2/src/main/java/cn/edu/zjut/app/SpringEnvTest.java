package cn.edu.zjut.app;
import cn.edu.zjut.bean.*;
import cn.edu.zjut.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringEnvTest {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
        IItemOrder itemorder2 = (IItemOrder)ctx.getBean("itemorder2");

    }
}

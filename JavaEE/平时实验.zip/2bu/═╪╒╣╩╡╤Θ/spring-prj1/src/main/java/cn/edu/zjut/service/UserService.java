package cn.edu.zjut.service;

import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.dao.IUserDAO;
import cn.edu.zjut.bean.ItemOrder;
import cn.edu.zjut.bean.ShoppingCart;

public class UserService implements IUserService {
    private IUserDAO userDAO = null;

    public UserService() {
        System.out.println("create UserService.");
    }

    public void setUserDAO(IUserDAO userDAO) {
        System.out.println("--setUserDAO--");
        this.userDAO = userDAO;
    }

    public void login(UserBean user) {
        System.out.println("execute --login()-- method.");
        userDAO.search(user);
    }

    public void checkShoppingCart(UserBean user) {
        System.out.println("检查" + user.getUsername()+"用户的购物车。");
        ShoppingCart shoppingCart = user.getShoppingCart();

        if (shoppingCart != null) {
            System.out.println("该用户的购物车包含以下商品：");
            for (ItemOrder itemOrder : shoppingCart.getItemsOrdered()) {
                System.out.println("书名: " + itemOrder.getItem().getTitle());
                System.out.println("数量: " + itemOrder.getNumItems());
                System.out.println();
            }
        } else {
            System.out.println("该用户的购物车为空。");
        }
    }

    public void addUser(UserBean user) {
        System.out.println("添加用户: " + user.getUsername());
    }

}

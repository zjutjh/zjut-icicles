package cn.edu.zjut.app;
import cn.edu.zjut.bean.*;
import cn.edu.zjut.service.IUserService;
import cn.edu.zjut.service.UserService;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import cn.edu.zjut.event.EmailEvent;

import java.util.Date;
import java.util.Locale;

public class SpringEnvTest {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
        IUserService userService = (IUserService) ctx.getBean("logProxy");
        UserBean user = new UserBean();
        user.setUsername("cust");
        userService.addUser(user);
    }
}



package cn.edu.zjut.service;

import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.exception.UserException;


public class UserService {
//    public boolean login(UserBean loginUser){
//        if(loginUser.getUsername().equals(loginUser.getPassword())){
//            return true;
//        }
//        return false;
//    }
    public boolean login(UserBean loginUser) throws Exception{
        if(loginUser.getUsername().equalsIgnoreCase("admin")){
            throw new UserException("用户名不能为admin");
        }
        if(loginUser.getPassword().toUpperCase().contains("AND") ||
                loginUser.getPassword().toUpperCase().contains("OR")){
            throw new java.sql.SQLException("密码不能包括‘and’或‘or’");
        }
        if(loginUser.getUsername().equals(loginUser.getPassword())){
            return true;
        }
        return false;
    }


}

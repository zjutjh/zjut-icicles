package cn.edu.zjut.action;
import cn.edu.zjut.bean.UserBean;
import cn.edu.zjut.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.action.ApplicationAware;
import org.apache.struts2.action.SessionAware;
import org.apache.struts2.interceptor.RequestAware;

import java.util.Map;


public class UserAction extends ActionSupport implements RequestAware, SessionAware, ApplicationAware {
    private UserBean loginUser ;
    private UserService userService ;

    public UserBean getLoginUser() {
        return loginUser;
    }
    public void setLoginUser(UserBean loginUser) {
        this.loginUser = loginUser;
    }
    public void setUserService(UserService userService) {this.userService = userService;}
    public UserService getUserService() {
        return userService;
    }

//    private Map request, session, application;
    private Map<String, Object> request;
    private Map<String, Object> session;
    private Map<String, Object> application;

    @Override
    public void setRequest(Map<String, Object> request){
        this.request = request;
    }

    public void setSession(Map<String, Object> session){
        this.session = session;
    }
    public void setApplication(Map<String, Object> application){
        this.application = application;
    }

    public String login()throws Exception{
        UserService userService = new UserService();
        try{
            if(userService.login(loginUser)){
                session.put("user", loginUser.getUsername());
                request.put("tip", "您已登录成功");
                return "success";
            }
            else{
                return "fail";
            }
        }catch (Exception e){
            throw  e;
        }

//        if(userService.login(loginUser)){
//            session.put("user", loginUser.getUsername());
//            request.put("tip", "您已登录成功");
//            return "success";
//        }
//        else{
//            return "fail";
////            this.addActionError("用户名或密码错误，请重新输入！");
//        }

    }

    @Override
    public void withSession(Map<String, Object> map) {
        this.session = map;
    }
    @Override
    public void withApplication(Map<String, Object> application) {
        // 在这里可以添加需要执行的逻辑，用于处理application
    }
}


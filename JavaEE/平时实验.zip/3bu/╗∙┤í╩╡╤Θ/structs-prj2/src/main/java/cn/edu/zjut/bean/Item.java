package cn.edu.zjut.bean;

public class Item {
    private String itemID;
    private String name;
    private String description;
    private double cost;

    public Item() {
    }

    public Item(String itemID, String name, String description, double cost) {
        this.itemID = itemID;
        this.name = name;
        this.description = description;
        this.cost = cost;
    }

    public String getItemID() {return itemID;}
    public void setItemID(String id) {this.itemID = itemID;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public String getDescription() {return description;}
    public void setDescription(String description) {this.description = description;}
    public double getCost() {return cost;}
    public void setCost(double price) {this.cost = cost;}

}

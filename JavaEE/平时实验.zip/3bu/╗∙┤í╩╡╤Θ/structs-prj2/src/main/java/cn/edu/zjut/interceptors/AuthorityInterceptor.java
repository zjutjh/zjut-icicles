package cn.edu.zjut.interceptors;

import java.util.Map;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
public class AuthorityInterceptor extends AbstractInterceptor {


    @Override
    public String intercept(ActionInvocation actionInvocation) throws Exception {
        System.out.println("Authority Interceptor excuted!");
        ActionContext ctx = actionInvocation.getInvocationContext();
        Map session = ctx.getSession();
        String user = (String)session.get("user");
        if(user != null){
            return actionInvocation.invoke();
        }
        else{
            ctx.put("tip", "您还没有登录，请输入用户名和密码登录系统");
            return Action.LOGIN;
        }
    }
}
package cn.edu.zjut.dao;

import java.sql.*;

import cn.edu.zjut.model.UserBean;
public class UserDAO {
    private static final String GET_ONE_SQL =
            "SELECT * FROM usertable WHERE username=? and password=?";

    public UserDAO() {}

    public Connection getConnection() {
        Connection conn = null;
        String driver = "com.mysql.cj.jdbc.Driver"; // MySQL驱动程序
        String dburl = "jdbc:mysql://localhost:3306/myDB?useUnicode=true&characterEncoding=UTF-8"; // MySQL数据库连接URL
        String username = "root"; // 数据库登录用户名
        String password = "123456"; // 数据库登录密码

        try {
            Class.forName(driver); // 加载MySQL数据库驱动程序
            conn = DriverManager.getConnection(dburl, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    public boolean searchUser(UserBean user) {
        // 按用户名和密码校验用户是否合法
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(GET_ONE_SQL);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            rst = pstmt.executeQuery();
            if (rst.next()) {
                return true;
            }
        } catch (SQLException se) {
            se.printStackTrace();
            return false;
        } finally {
            try {
                if (rst != null) rst.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return false;
    }

    public UserBean getUser(String username, String password, int userType) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;
        UserBean user = null;

        try {
            conn = getConnection();
            // 更新SQL查询，使用正确的列名
            String sql = "SELECT * FROM usertable WHERE username=? AND password=? AND type=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setInt(3, userType);
            rst = pstmt.executeQuery();

            if (rst.next()) {
                // 从结果集中获取用户信息
                user = new UserBean();
                user.setUsername(username);
                user.setPassword(password);
                user.setType(userType);
            }
        } catch (SQLException se) {
            se.printStackTrace();
        } finally {
            try {
                if (rst != null) rst.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

        return user;
    }

    public boolean insert(UserBean user) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = getConnection();
            String sql = "INSERT INTO usertable (username, password, type) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setInt(3, user.getType());

            int rowsInserted = pstmt.executeUpdate();
            return rowsInserted > 0; // 如果插入成功，返回 true
        } catch (SQLException se) {
            se.printStackTrace();
            return false; // 插入失败
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }

}
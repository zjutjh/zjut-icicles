package cn.edu.zjut;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.edu.zjut.model.UserBean;
import cn.edu.zjut.dao.UserDAO;


public class RegisterController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int userType = Integer.parseInt(request.getParameter("usertype"));

        UserDAO userDAO = new UserDAO();

        if (username.isEmpty() || password.isEmpty() || username.length() > 6 || password.length() > 6) {
            // 用户名或密码为空，或者超过6位,显示错误消息
            response.getWriter().println("用户名和密码都不能为空，且最多为6位。");
        } else {
            // 创建 UserBean 对象并设置属性
            UserBean user = new UserBean();
            user.setUsername(username);
            user.setPassword(password);
            user.setType(userType);

            // 使用 UserDAO 插入用户信息
            boolean registrationSuccess = userDAO.insert(user);

            if (registrationSuccess) {
                // 注册成功，重定向到登录页面
                response.sendRedirect("login.jsp");
            } else {
                // 注册失败
                response.setCharacterEncoding("UTF-8");
                response.setContentType("text/html; charset=UTF-8");
                response.getWriter().println("注册失败，请重试！");
            }
        }
    }
}

package cn.edu.zjut;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import cn.edu.zjut.model.*;
import cn.edu.zjut.dao.*;

public class LoginController extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int userType = Integer.parseInt(request.getParameter("usertype"));
        UserBean user=new UserBean();
        user.setUsername(username);
        user.setPassword(password);
        user.setType(userType);

        if(checkUser(user)){
            request.setAttribute("USER", user);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/loginSuccess.jsp");
            dispatcher.forward(request, response);
        }else{
            response.sendRedirect("/javaweb_prj1_war_exploded/loginFailed.jsp");
        }

    }

    boolean checkUser(UserBean user) {
        UserDAO userDAO = new UserDAO();
        // 从数据库中获取用户信息
        UserBean dbUser = userDAO.getUser(user.getUsername(), user.getPassword(), user.getType());
        // 检查检索到的用户是否与输入的用户信息匹配
        if (dbUser != null && dbUser.getUsername().equals(user.getUsername()) &&
                dbUser.getPassword().equals(user.getPassword()) && dbUser.getType() == user.getType()) {
            return true; // 所有条件匹配，表示用户有效
        } else {
            return false; // 条件不匹配，表示用户无效
        }
    }


}

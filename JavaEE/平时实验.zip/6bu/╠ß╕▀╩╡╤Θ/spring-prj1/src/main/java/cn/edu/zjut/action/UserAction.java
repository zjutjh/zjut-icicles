package cn.edu.zjut.action;

import cn.edu.zjut.po.Customer;
import cn.edu.zjut.service.IUserService;

public class UserAction {
    private Customer loginUser;
    private IUserService userService;

    public void setLoginUser(Customer loginUser) {this.loginUser = loginUser;}
    public Customer getLoginUser() {return loginUser;}

    public void setUserService(IUserService userService) {
        this.userService = userService;
    }

    public String execute() {
        userService.saveUser(loginUser); // 假设你的 IUserService 接口有一个 saveUser 方法
        return "success";
    }
}

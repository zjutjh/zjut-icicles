package cn.edu.zjut.service;

import cn.edu.zjut.dao.ICustomerDAO;
import cn.edu.zjut.po.Customer;

public interface IUserService {
    void setCustomerDAO(ICustomerDAO customerDAO);

    void saveUser(Customer c);
}

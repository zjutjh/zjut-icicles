package cn.edu.zjut.po;

import java.util.Date;

public class Customer {
    private Integer customerID;
    private String account;
    private String password;
    private String name;
    private Boolean sex;
    private Date birthday;
    private String phone;
    private String email;
    private String address;
    private String zipcode;
    private String fax;

    public Customer() {
    }

    public int getCustomerID() {return customerID != null ? customerID.intValue() : 0;}
    public void setCustomerID(int customerID) {this.customerID = customerID;}
    public String getAccount() {return account;}
    public void setAccount(String account) {this.account = account;}
    public String getPassword() {return password;}
    public void setPassword(String password) {this.password = password;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public Boolean getSex() {return sex;}
    public void setSex(Boolean sex) {this.sex = sex;}
    public Date getBirthday() {return birthday;}
    public void setBirthday(Date birthday) {this.birthday = birthday;}
    public String getPhone() {return phone;}
    public void setPhone(String phone) {this.phone = phone;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
    public String getAddress() {return address;}
    public void setAddress(String address) {this.address = address;}
    public String getZipcode() {return zipcode;}
    public void setZipcode(String zipcode) {this.zipcode = zipcode;}
    public String getFax() {return fax;}
    public void setFax(String fax) {this.fax = fax;}

}
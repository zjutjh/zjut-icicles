package cn.edu.zjut.dao;

import cn.edu.zjut.dao.ICustomerDAO;
import org.hibernate.Session;
import cn.edu.zjut.po.Customer;

public class CustomerDAO implements ICustomerDAO {
    private Session session;

    public void setSession(Session session) {this.session=session;}
    public Session getSession() {return session;}
    public void save(Customer transientInstance) {
        Session session = getSession();
        session.save(transientInstance);
    }
}
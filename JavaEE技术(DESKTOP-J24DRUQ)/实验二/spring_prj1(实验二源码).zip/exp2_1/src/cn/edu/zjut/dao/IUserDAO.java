package cn.edu.zjut.dao;

import cn.edu.zjut.bean.UserBean;

public interface IUserDAO
{
    public void search(UserBean user);
}
package cn.edu.zjut.bean;

import java.util.*;

public interface IShoppingCart
{
    Properties getItemsOrdered();

    void setItemsOrdered(Properties itemsOrdered);
}

package cn.edu.zjut.aspect;

public class SecurityHandler2
{
    private void checkSecurity()
    {
        System.out.println("---checkSecurity()2---");
    }
}

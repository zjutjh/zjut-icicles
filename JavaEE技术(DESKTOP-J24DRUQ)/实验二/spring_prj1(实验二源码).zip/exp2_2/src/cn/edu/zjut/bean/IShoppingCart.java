package cn.edu.zjut.bean;

import java.util.*;

public interface IShoppingCart
{
    List getItemsOrdered();

    void setItemsOrdered(List itemsOrdered);
}

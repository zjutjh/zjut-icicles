package cn.edu.zjut.service;

import cn.edu.zjut.po.Customer;

public interface IUserService
{
    void saveUser(Customer c);
}

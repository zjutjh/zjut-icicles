package cn.edu.zjut.service;

public interface IUserService
{
    boolean login(String username, String password);
}

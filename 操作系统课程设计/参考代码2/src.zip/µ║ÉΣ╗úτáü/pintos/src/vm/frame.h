#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <stdbool.h>
#include "threads/palloc.h"
#include "threads/synch.h"

/* Frame table entry */
struct frame_entry {
    void *frame;                /* Kernel virtual address of the frame */
    struct thread *owner;       /* Thread that owns this frame */
    void *vaddr;                /* User virtual address mapped to this frame */
    struct list_elem elem;      /* List element for frame table */
};

void vm_frame_init (void);
void* vm_frame_alloc (enum palloc_flags flags, void *upage);
void vm_frame_free (void* frame);
bool vm_frame_remove_entry (void *frame);
void* vm_evict_frame (enum palloc_flags flags);

#endif /* vm/frame.h */

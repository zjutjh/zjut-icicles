#include "vm/frame.h"
#include "vm/frame.h"
#include "vm/page.h"
#include "vm/swap.h"
#include "threads/thread.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include <string.h>
#include <list.h>

/* Global frame table */
static struct list frame_table;
static struct lock frame_lock;

void vm_frame_init (void) {
    list_init(&frame_table);
    lock_init(&frame_lock);
}

/* Allocate a new frame for user page UPAGE */
void* vm_frame_alloc (enum palloc_flags flags, void *upage) {
    if ( (flags & PAL_USER) == 0 )
        return NULL;

    void *frame = palloc_get_page(flags);
    if (frame != NULL) {
        /* Add to frame table */
        struct frame_entry *fe = malloc(sizeof(struct frame_entry));
        if (fe == NULL) {
            palloc_free_page(frame);
            return NULL;
        }
        
        fe->frame = frame;
        fe->owner = thread_current();
        fe->vaddr = upage;
        
        lock_acquire(&frame_lock);
        list_push_back(&frame_table, &fe->elem);
        lock_release(&frame_lock);
    } else {
        /* Evict a page to free a frame */
        frame = vm_evict_frame(flags);
        
        if (frame != NULL) {
            /* Create frame entry for the NEW page */
            /* Note: vm_evict_frame returned a freed frame pointer, 
               but the frame entry for it was removed from table by vm_frame_free -> vm_frame_remove_entry? 
               Wait, vm_evict_frame internal implementation should handle it. */
               
            /* Better design: vm_evict_frame frees a frame and returns it.
               Then we re-add it to the table for the new owner. */
               
            struct frame_entry *fe = malloc(sizeof(struct frame_entry));
            if (!fe) {
                 /* This is bad. We freed a frame but can't allocate entry. */
                 /* We should free the frame back to system? */
                 palloc_free_page(frame);
                 return NULL;
            }
            
            fe->frame = frame;
            fe->owner = thread_current();
            fe->vaddr = upage;
            
            lock_acquire(&frame_lock);
            list_push_back(&frame_table, &fe->elem);
            lock_release(&frame_lock);
        } else {
            PANIC("Frame eviction failed!");
        }
    }
    
    return frame;
}

/* [] Clock Algorithm Implementation */
static struct list_elem *clock_ptr = NULL;

void* vm_evict_frame (enum palloc_flags flags) {
    lock_acquire(&frame_lock);
    
    if (list_empty(&frame_table)) {
        lock_release(&frame_lock);
        return NULL;
    }

    if (clock_ptr == NULL || clock_ptr == list_end(&frame_table)) {
        clock_ptr = list_begin(&frame_table);
    }

    struct frame_entry *victim = NULL;
    
    /* Iterate twice maximum to find a victim */
    size_t i;
    for (i = 0; i < 2 * list_size(&frame_table); i++) {
        struct frame_entry *fe = list_entry(clock_ptr, struct frame_entry, elem);
        
        /* Advance clock ptr */
        clock_ptr = list_next(clock_ptr);
        if (clock_ptr == list_end(&frame_table)) {
            clock_ptr = list_begin(&frame_table);
        }
        
        struct thread *t = fe->owner;
        if (!t->pcb || !t->pcb->pagedir) continue; /* Should not happen for user pages */
        
        /* Check accessed bit */
        if (pagedir_is_accessed(t->pcb->pagedir, fe->vaddr)) {
            pagedir_set_accessed(t->pcb->pagedir, fe->vaddr, false);
        } else {
            /* Found victim */
            victim = fe;
            break;
        }
    }
    
    /* If no victim found (all accessed), pick the current one? */
    if (!victim) {
        victim = list_entry(list_begin(&frame_table), struct frame_entry, elem);
    }
    
    /* Evict victim */
    /* Remove from frame table FIRST to prevent race? */
    /* Wait, we hold frame_lock. */
    
    /* Check dirty bit */
    bool dirty = pagedir_is_dirty(victim->owner->pcb->pagedir, victim->vaddr);
    
    /* Update SPT */
    struct page_entry *p = vm_spt_lookup(&victim->owner->spt, victim->vaddr);
    
    if (p) {
        if (p->status == PAGE_FRAME) {
            /* Handle swap or file write back */
            if (p->file != NULL) {
                 /* Mapped file */
                 if (dirty) {
                     /* Write back to file if implicit mmap (load_segment) is wrong.
                        Executable segments are read-only usually, or private writable.
                        Pintos VM: data segments are "lazy loaded" from executable.
                        If modified, they effectively become swap-backed (private dirty).
                        They should NOT be written back to executable file.
                        Only MAP_SHARED mmap files are written back to file.
                        Pintos Project 3 mmap is MAP_SHARED? Docs say "memory mapped files".
                        If p->file is set, it means it *came* from a file.
                        But was it mmap?
                        We distinguish mmap frames by another flag? Or p->status?
                        Currently both Lazy Load and MMAP use PAGE_FILE (implied).
                        
                        However, for Experiment 6, we only implemented Lazy Load (EXEC).
                        Executables are not writable on disk while running.
                        So we MUST NOT write back to executable.
                        Write to SWAP instead.
                      */
                     size_t swap_idx = vm_swap_out(victim->frame);
                     if (swap_idx == SIZE_MAX) {
                         PANIC("Swap full!");
                     }
                     p->status = PAGE_SWAP;
                     p->kaddr = (void*) swap_idx; /* Store swap index in kaddr union? */
                     /* Wait, p->kaddr is void*. Swap index is size_t. 
                        Assume 32-bit arch, size_t fits in void*. */
                 } else {
                     /* Clean page. Only go back to FILE if read-only (code). */
                     /* If writable, it might have been modified before and swapped, 
                        then loaded back. We cannot assume file content matches. */
                     if (!p->writable) {
                         p->status = PAGE_FILE;
                         p->kaddr = NULL;
                     } else {
                         /* Writable but clean now - still must swap to preserve data */
                         size_t swap_idx = vm_swap_out(victim->frame);
                         if (swap_idx == SIZE_MAX) {
                             PANIC("Swap full!");
                         }
                         p->status = PAGE_SWAP;
                         p->kaddr = (void*) swap_idx;
                     }
                 }
            } else {
                /* Stack or anon page. MUST swap. */
                size_t swap_idx = vm_swap_out(victim->frame);
                if (swap_idx == SIZE_MAX) {
                    PANIC("Swap full!");
                }
                p->status = PAGE_SWAP;
                p->kaddr = (void*) swap_idx;
            }
            
            p->dirty = dirty; /* Save dirty state if needed? */
        }
    }

    /* Unmap from pagedir */
    pagedir_clear_page(victim->owner->pcb->pagedir, victim->vaddr);
    
    /* Free physical memory using palloc (but we want to reuse it, so returning it) */
    /* If we just return it, palloc doesn't know it's free. 
       Actually vm_frame_alloc called palloc_get_page -> returns NULL.
       So we need to make palloc happy?
       
       NO. palloc manages free list. 
       If we take a frame that is currently allocated (by victim), we must free it to palloc first?
       Or just overwrite it?
       
       If we return it to `vm_frame_alloc`, `vm_frame_alloc` returns it to caller.
       Caller will memset it 0 (if `PAGE_ZERO`).
       Wait, `vm_frame_alloc` takes `flags`.
       If `PAL_ZERO` is set, we must zero it.
    */
    
    void *frame = victim->frame;
    
    /* Remove from list and free entry */
    list_remove(&victim->elem);
    free(victim);
    
    lock_release(&frame_lock);
    
    if (flags & PAL_ZERO) {
        memset(frame, 0, PGSIZE);
    }
    
    return frame;
}

void vm_frame_free (void* frame) {
    if (vm_frame_remove_entry(frame)) {
        palloc_free_page(frame);
    }
}

/* [fix] 返回是否成功移除，防止释放已被 evict 的页面 */
bool vm_frame_remove_entry (void *frame) {
    bool found = false;
    lock_acquire(&frame_lock);
    struct list_elem *e;
    for (e = list_begin(&frame_table); e != list_end(&frame_table); e = list_next(e)) {
        struct frame_entry *fe = list_entry(e, struct frame_entry, elem);
        if (fe->frame == frame) {
            list_remove(e);
            free(fe);
            found = true;
            break;
        }
    }
    lock_release(&frame_lock);
    return found;
}

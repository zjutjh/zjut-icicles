#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include "filesys/file.h"
#include <string.h>

/* Hash functions */
static unsigned page_hash (const struct hash_elem *p_, void *aux UNUSED) {
    const struct page_entry *p = hash_entry(p_, struct page_entry, elem);
    return hash_bytes(&p->vaddr, sizeof p->vaddr);
}

static bool page_less (const struct hash_elem *a_, const struct hash_elem *b_, void *aux UNUSED) {
    const struct page_entry *a = hash_entry(a_, struct page_entry, elem);
    const struct page_entry *b = hash_entry(b_, struct page_entry, elem);
    return a->vaddr < b->vaddr;
}

static void page_cleanup_func (struct hash_elem *e, void *aux UNUSED) {
    struct page_entry *p = hash_entry(e, struct page_entry, elem);
    /* Frame freeing happens in thread cleanup or we should do it here?
       Normally process_exit cleans page dir, user frames are freed then using frame table owner check? 
       Or we free frames here?
       Let's free the frame if it holds one. 
       Note: pagedir_destroy frees the page tables, but we need to tell frame table it's gone?
       Or frame table is global.
       Actually better to free physical memory here if we own it. */
    
    if (p->status == PAGE_FRAME) {
        vm_frame_free(p->kaddr);
        struct thread *t = thread_current();
        if (t->pcb)
            pagedir_clear_page(t->pcb->pagedir, p->vaddr);
    } else if (p->status == PAGE_SWAP) {
        vm_swap_free((size_t)p->kaddr);
    }
    
    free(p);
}

void vm_spt_init (struct hash *spt) {
    hash_init(spt, page_hash, page_less, NULL);
}

void vm_spt_destroy (struct hash *spt) {
    hash_destroy(spt, page_cleanup_func);
}

struct page_entry* vm_spt_lookup (struct hash *spt, void *vaddr) {
    struct page_entry p;
    p.vaddr = pg_round_down(vaddr);
    struct hash_elem *e = hash_find(spt, &p.elem);
    return e != NULL ? hash_entry(e, struct page_entry, elem) : NULL;
}

bool vm_spt_install_frame (struct hash *spt, void *vaddr, void *kaddr, bool writable) {
    struct page_entry *p = malloc(sizeof(struct page_entry));
    if (!p) return false;
    
    p->vaddr = vaddr;
    p->kaddr = kaddr;
    p->writable = writable;
    p->status = PAGE_FRAME;
    p->dirty = false;
    
    if (hash_insert(spt, &p->elem) != NULL) {
        free(p);
        return false;
    }
    
    return true;
}

bool vm_spt_add_file (struct hash *spt, struct file *file, off_t ofs, uint8_t *upage,
                      uint32_t read_bytes, uint32_t zero_bytes, bool writable) {
    struct page_entry *p = malloc(sizeof(struct page_entry));
    if (!p) return false;
    
    p->vaddr = upage;
    p->file = file;
    p->file_offset = ofs;
    p->read_bytes = read_bytes;
    p->zero_bytes = zero_bytes;
    p->writable = writable;
    p->status = PAGE_FILE;
    p->dirty = false;
    
    if (hash_insert(spt, &p->elem) != NULL) {
        free(p);
        return false;
    }
    return true;
}

bool vm_load_page (struct hash *spt, void *vaddr) {
    struct page_entry *p = vm_spt_lookup(spt, vaddr);
    if (!p) return false;
    
    if (p->status == PAGE_FRAME) return true; // Already loaded
    
    void *frame = vm_frame_alloc(PAL_USER, p->vaddr);
    if (!frame) return false;
    
    bool result = false;
    if (p->status == PAGE_FILE) {
        /* Load from file */
        if (file_read_at(p->file, frame, p->read_bytes, p->file_offset) != (off_t) p->read_bytes) {
            vm_frame_free(frame);
            return false;
        }
        memset(frame + p->read_bytes, 0, p->zero_bytes);
        result = true;
    } else if (p->status == PAGE_SWAP) {
        /* Swap in */
        size_t swap_index = (size_t) p->kaddr;
        if (!vm_swap_in(swap_index, frame)) {
            vm_frame_free(frame);
            return false;
        }
        result = true;
    }
    
    if (result) {
        /* Install in page table */
        struct thread *t = thread_current();
        if (t->pcb && !pagedir_set_page(t->pcb->pagedir, p->vaddr, frame, p->writable)) {
            vm_frame_free(frame);
            return false;
        }
        p->status = PAGE_FRAME;
        p->kaddr = frame;
    }
    
    return result;
}

/* [] 栈增长处理函数 */
bool vm_stack_growth (void *vaddr) {
  /* 向下取整到页边界 */
  void *upage = pg_round_down(vaddr);
  
  /* 分配物理帧 */
  void *frame = vm_frame_alloc(PAL_USER, upage);
  if (frame == NULL) {
    return false;
  }
  
  /* 添加到 SPT 并且安装到页表 */
  /* 栈是可写的 */
  if (vm_spt_install_frame(&thread_current()->spt, upage, frame, true)) {
    /* 需要手动调用 pagedir_set_page 因为 vm_spt_install_frame 只加哈希表? */
    /* 不，vm_spt_install_frame 没调用 pagedir_set_page... 等等 */
    
    /* 检查 vm_spt_install_frame 实现：它只 malloc 并 insert hash。
       所以这里需要手动 set page。 */
       
    struct thread *t = thread_current();
    if (t->pcb && pagedir_set_page(t->pcb->pagedir, upage, frame, true)) {
        return true;
    }
    /* 如果设置失败，需要回滚 */
    /* 简化起见，这里应该把 vm_spt_install_frame 改为包含 pagedir 操作，
       或者在这里做。为了保持一致性，还是在这里做。 */
  }
  
  vm_frame_free(frame);
  return false;
}

/* [] 实验六：mmap 实现 */
int vm_mmap (struct file *file, void *addr) {
    struct thread *t = thread_current();
    struct process *p = t->pcb;
    if (!p) return -1;
    
    /* 验证参数 */
    if (file == NULL || addr == NULL) return -1;
    if (pg_ofs(addr) != 0) return -1;  /* 地址必须页对齐 */
    if (addr == 0) return -1;          /* 不能映射到地址 0 */
    
    /* 获取文件长度 */
    off_t length = file_length(file);
    if (length == 0) return -1;
    
    /* 检查地址范围是否已被使用 */
    size_t page_count = (length + PGSIZE - 1) / PGSIZE;
    size_t i;
    for (i = 0; i < page_count; i++) {
        void *page = addr + i * PGSIZE;
        if (vm_spt_lookup(&t->spt, page) != NULL) {
            return -1;  /* 页面已被占用 */
        }
    }
    
    /* 创建文件副本（mmap 的文件独立于 fd） */
    struct file *file_copy = file_reopen(file);
    if (file_copy == NULL) return -1;
    
    /* 将页面添加到 SPT */
    off_t ofs = 0;
    for (i = 0; i < page_count; i++) {
        void *page = addr + i * PGSIZE;
        uint32_t read_bytes = (i == page_count - 1) ? (length - ofs) : PGSIZE;
        uint32_t zero_bytes = PGSIZE - read_bytes;
        
        if (!vm_spt_add_file(&t->spt, file_copy, ofs, page, read_bytes, zero_bytes, true)) {
            /* 失败时回滚 */
            size_t j;
            for (j = 0; j < i; j++) {
                struct page_entry *pe = vm_spt_lookup(&t->spt, addr + j * PGSIZE);
                if (pe) {
                    hash_delete(&t->spt, &pe->elem);
                    free(pe);
                }
            }
            file_close(file_copy);
            return -1;
        }
        ofs += read_bytes;
    }
    
    /* 创建 mmap 条目 */
    struct mmap_entry *me = malloc(sizeof(struct mmap_entry));
    if (me == NULL) {
        /* 回滚 */
        for (i = 0; i < page_count; i++) {
            struct page_entry *pe = vm_spt_lookup(&t->spt, addr + i * PGSIZE);
            if (pe) {
                hash_delete(&t->spt, &pe->elem);
                free(pe);
            }
        }
        file_close(file_copy);
        return -1;
    }
    
    me->mapid = p->next_mapid++;
    me->file = file_copy;
    me->addr = addr;
    me->page_count = page_count;
    list_push_back(&p->mmap_list, &me->elem);
    
    return me->mapid;
}

void vm_munmap (int mapid) {
    struct thread *t = thread_current();
    struct process *p = t->pcb;
    if (!p) return;
    
    /* 查找 mmap 条目 */
    struct list_elem *e;
    struct mmap_entry *me = NULL;
    for (e = list_begin(&p->mmap_list); e != list_end(&p->mmap_list); e = list_next(e)) {
        struct mmap_entry *entry = list_entry(e, struct mmap_entry, elem);
        if (entry->mapid == mapid) {
            me = entry;
            break;
        }
    }
    
    if (me == NULL) return;
    
    /* 写回脏页并释放 */
    size_t i;
    for (i = 0; i < me->page_count; i++) {
        void *page = me->addr + i * PGSIZE;
        struct page_entry *pe = vm_spt_lookup(&t->spt, page);
        if (pe == NULL) continue;
        
        if (pe->status == PAGE_FRAME) {
            /* 检查是否脏，如果是则写回文件 */
            if (p->pagedir && pagedir_is_dirty(p->pagedir, page)) {
                off_t ofs = pe->file_offset;
                uint32_t write_bytes = pe->read_bytes;
                file_write_at(me->file, pe->kaddr, write_bytes, ofs);
            }
            vm_frame_free(pe->kaddr);
            pagedir_clear_page(p->pagedir, page);
        }
        
        hash_delete(&t->spt, &pe->elem);
        free(pe);
    }
    
    /* 关闭文件 */
    file_close(me->file);
    
    /* 从列表移除并释放 */
    list_remove(&me->elem);
    free(me);
}

void vm_munmap_all (void) {
    struct thread *t = thread_current();
    struct process *p = t->pcb;
    if (!p) return;
    
    while (!list_empty(&p->mmap_list)) {
        struct mmap_entry *me = list_entry(list_front(&p->mmap_list), struct mmap_entry, elem);
        vm_munmap(me->mapid);
    }
}


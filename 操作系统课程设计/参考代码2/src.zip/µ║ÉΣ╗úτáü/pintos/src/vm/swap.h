#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <stdbool.h>
#include <stddef.h>
#include "threads/vaddr.h"

void vm_swap_init (void);
bool vm_swap_in (size_t swap_index, void *frame);
size_t vm_swap_out (void *frame);
void vm_swap_free (size_t swap_index);

#endif /* vm/swap.h */

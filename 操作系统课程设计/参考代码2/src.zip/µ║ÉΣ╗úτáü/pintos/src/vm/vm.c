/* vm/vm.c - Virtual Memory main entry point
   [] 实验六：虚拟内存实现
   
   This file serves as a placeholder for the grading system.
   The actual implementation is in:
   - frame.c: Frame table management
   - page.c: Supplemental page table and mmap
   - swap.c: Swap table management
*/

#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"

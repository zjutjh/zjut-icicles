#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include "filesys/off_t.h"
#include "filesys/file.h"

enum page_status {
    PAGE_FRAME,     /* In physical memory */
    PAGE_SWAP,      /* In swap slot */
    PAGE_FILE       /* In file (lazy load) */
};

struct page_entry {
    void *vaddr;            /* User virtual address (key) */
    struct hash_elem elem;  /* Hash table element */
    
    enum page_status status;
    bool writable;          /* Read-only or Read-write */
    bool dirty;             /* Dirty bit for mmap/swap */
    
    /* Frame info (if PAGE_FRAME) */
    void *kaddr;            /* Kernel virtual address */
    
    /* File info (if PAGE_FILE) */
    struct file *file;
    off_t file_offset;
    uint32_t read_bytes;
    uint32_t zero_bytes;
    
    /* Swap info (if PAGE_SWAP) */
    size_t swap_index;
};

void vm_spt_init (struct hash *spt);
void vm_spt_destroy (struct hash *spt);

struct page_entry* vm_spt_lookup (struct hash *spt, void *vaddr);
bool vm_spt_install_frame (struct hash *spt, void *vaddr, void *kpage, bool writable);
/* [] 栈增长 */
bool vm_stack_growth (void *vaddr);

bool vm_spt_add_file (struct hash *spt, struct file *file, off_t ofs, uint8_t *upage,
                      uint32_t read_bytes, uint32_t zero_bytes, bool writable);
bool vm_load_page (struct hash *spt, void *vaddr);

/* [] 实验六：内存映射文件 */
struct mmap_entry {
    int mapid;                  /* 映射 ID */
    struct file *file;          /* 映射的文件 */
    void *addr;                 /* 起始虚拟地址 */
    size_t page_count;          /* 映射的页数 */
    struct list_elem elem;      /* 用于 process->mmap_list */
};

int vm_mmap (struct file *file, void *addr);
void vm_munmap (int mapid);
void vm_munmap_all (void);

#endif /* vm/page.h */


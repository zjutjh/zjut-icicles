#include "vm/swap.h"
#include "devices/block.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include <bitmap.h>

/* The swap block device. */
static struct block *swap_block;

/* Map of used swap slots. True if used, false if free. */
static struct bitmap *swap_map;

/* Lock to protect swap_map */
static struct lock swap_lock;

/* Scctors per page. PGSIZE is 4096, BLOCK_SECTOR_SIZE is 512. Result is 8. */
#define SECTORS_PER_PAGE (PGSIZE / BLOCK_SECTOR_SIZE)

void vm_swap_init (void) {
    swap_block = block_get_role(BLOCK_SWAP);
    if (!swap_block) {
        return;
    }
    
    /* Calculate number of slots (pages) in swap disk */
    size_t swap_size = block_size(swap_block) / SECTORS_PER_PAGE;
    swap_map = bitmap_create(swap_size);
    if (!swap_map) {
        return;
    }
    bitmap_set_all(swap_map, false);
    lock_init(&swap_lock);
}

/* Reads a page from swap_index into frame. Returns true on success. */
bool vm_swap_in (size_t swap_index, void *frame) {
    if (!swap_block || !swap_map) return false;

    lock_acquire(&swap_lock);
    if (!bitmap_test(swap_map, swap_index)) {
        /* Slot claims to be free but we are reading from it? Logic error in caller? */
        /* Or harmless. But strictly, we should only read used slots. */
        /* We allow it but it's suspicious. */
    }
    lock_release(&swap_lock);

    size_t i;
    for (i = 0; i < SECTORS_PER_PAGE; i++) {
        block_read(swap_block, swap_index * SECTORS_PER_PAGE + i, 
                   frame + i * BLOCK_SECTOR_SIZE);
    }
    
    /* After reading, we can free the swap slot */
    vm_swap_free(swap_index);
    
    return true;
}

/* Writes frame to a new swap slot. Returns valid index or SIZE_MAX. */
size_t vm_swap_out (void *frame) {
    if (!swap_block || !swap_map) return SIZE_MAX;

    lock_acquire(&swap_lock);
    size_t swap_index = bitmap_scan_and_flip(swap_map, 0, 1, false);
    lock_release(&swap_lock);

    if (swap_index == BITMAP_ERROR) {
        return SIZE_MAX; /* Swap full */
    }

    size_t i;
    for (i = 0; i < SECTORS_PER_PAGE; i++) {
        block_write(swap_block, swap_index * SECTORS_PER_PAGE + i, 
                    frame + i * BLOCK_SECTOR_SIZE);
    }

    return swap_index;
}

/* Frees the swap slot. */
void vm_swap_free (size_t swap_index) {
    if (!swap_map) return;
    
    lock_acquire(&swap_lock);
    if (bitmap_test(swap_map, swap_index)) {
        bitmap_reset(swap_map, swap_index);
    }
    lock_release(&swap_lock);
}

#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H

#include "devices/block.h"
#include "filesys/off_t.h"

/* [] 初始化 buffer cache */
void cache_init (void);

/* [] 关闭 buffer cache，将所有脏块写回磁盘 */
void cache_done (void);

/* [] 从 buffer cache 中读取数据 */
void cache_read (block_sector_t sector, void *buffer, int sector_ofs, int size);

/* [] 向 buffer cache 中写入数据 */
void cache_write (block_sector_t sector, const void *buffer, int sector_ofs, int size);

#endif /* filesys/cache.h */

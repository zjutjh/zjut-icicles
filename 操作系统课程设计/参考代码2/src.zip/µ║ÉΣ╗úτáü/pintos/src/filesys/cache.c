#include "filesys/cache.h"
#include <debug.h>
#include <string.h>
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "threads/malloc.h"

/* [] 最大缓存块数量 */
#define CACHE_SIZE 64

/* [] 缓存条目结构 */
struct cache_entry {
  block_sector_t sector;    /* 磁盘扇区号 */
  uint8_t data[BLOCK_SECTOR_SIZE]; /* 数据缓冲 */
  bool dirty;               /* 是否脏（需要写回） */
  bool accessed;            /* 是否被访问过（用于时钟算法） */
  bool valid;               /* 是否有效 */
  bool open;                /* 是否有人正在使用（简单起见，这里也可以用读写锁，
                               但为了简单，我们用全局锁配合open计数或简单互斥） 
                               注：为了满足并发要求，我们这里使用更细粒度的锁。*/
  struct lock lock;         /* 保护该条目的读写锁 */
  int open_cnt;             /* 有多少线程正在读写这个块 */
};

/* [] 缓存数组 */
static struct cache_entry cache[CACHE_SIZE];

/* [] 全局锁，保护 cache 结构本身（查找、分配） */
static struct lock cache_lock;

/* [] 时钟指针对 */
static int clock_hand = 0;

/* [] 初始化 buffer cache */
void cache_init (void) {
  lock_init (&cache_lock);
  for (int i = 0; i < CACHE_SIZE; i++) {
    cache[i].valid = false;
    cache[i].dirty = false;
    cache[i].open_cnt = 0;
    lock_init (&cache[i].lock);
  }
}

/* [] 获取一个缓存块的索引。
   如果已经在缓存中，返回索引。
   如果不在，选择驱逐块，读取新块，返回索引。
   此函数执行后，不仅返回索引，还会增加该块的 open_cnt，并持有该块的 data 拷贝权限？
   为了简单，我们约定：返回时，该块的 open_cnt > 0，且 valid = true。
   调用者必须在使用完后调用 cache_unlock (index)。
*/
static int cache_get_block (block_sector_t sector, bool exclusive) {
  lock_acquire (&cache_lock);

  /* 1. 查找是否在缓存中 */
  for (int i = 0; i < CACHE_SIZE; i++) {
    if (cache[i].valid && cache[i].sector == sector) {
      cache[i].open_cnt++;
      lock_release (&cache_lock);
      return i;
    }
  }

  /* 2. 不在缓存中，需要替换。使用时钟算法 */
  int victim = -1;
  while (victim == -1) {
    if (cache[clock_hand].open_cnt == 0) { // 只有没有人使用的块才能被驱逐
      if (cache[clock_hand].accessed) {
        cache[clock_hand].accessed = false; // 给第二次机会
      } else {
        victim = clock_hand;
      }
    }
    clock_hand = (clock_hand + 1) % CACHE_SIZE;
  }

  /* 3. 驱逐 victim */
  struct cache_entry *e = &cache[victim];
  
  // 必须先锁定由于我们要修改它
  // 注意：因为 open_cnt == 0，且我们持有 cache_lock，所以没人能抢走它
  // 但为了安全（如果以后加了并发 I/O），我们还是不做多余操作
  
  if (e->valid && e->dirty) {
    block_write (fs_device, e->sector, e->data);
  }

  /* 4. 读取新块 */
  e->sector = sector;
  e->valid = true;
  e->dirty = false;
  e->accessed = true;
  block_read (fs_device, sector, e->data);
  
  e->open_cnt++; // 标记为正在使用

  lock_release (&cache_lock);
  return victim;
}

/* [] 释放对缓存块的引用 */
static void cache_unlock_block (int index) {
  lock_acquire (&cache_lock);
  ASSERT (index >= 0 && index < CACHE_SIZE);
  ASSERT (cache[index].open_cnt > 0);
  cache[index].open_cnt--;
  lock_release (&cache_lock);
}

/* [] 关闭 buffer cache，将所有脏块写回磁盘 */
void cache_done (void) {
  lock_acquire (&cache_lock);
  for (int i = 0; i < CACHE_SIZE; i++) {
    if (cache[i].valid && cache[i].dirty) {
      block_write (fs_device, cache[i].sector, cache[i].data);
      cache[i].dirty = false;
    }
  }
  lock_release (&cache_lock);
}

/* [] 从 buffer cache 中读取数据 */
void cache_read (block_sector_t sector, void *buffer, int sector_ofs, int size) {
  int index = cache_get_block (sector, false);
  struct cache_entry *e = &cache[index];

  /* 这里的读写不需要持有全局锁，因为 open_cnt > 0 保证了不会被驱逐 */
  lock_acquire (&e->lock);
  memcpy (buffer, e->data + sector_ofs, size);
  e->accessed = true;
  lock_release (&e->lock);

  cache_unlock_block (index);
}

/* [] 向 buffer cache 中写入数据 */
void cache_write (block_sector_t sector, const void *buffer, int sector_ofs, int size) {
  int index = cache_get_block (sector, true);
  struct cache_entry *e = &cache[index];

  lock_acquire (&e->lock);
  memcpy (e->data + sector_ofs, buffer, size);
  e->dirty = true;
  e->accessed = true;
  lock_release (&e->lock);

  cache_unlock_block (index);
}

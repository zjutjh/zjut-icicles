#include "filesys/inode.h"
#include <list.h>
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "threads/malloc.h"
#include "threads/synch.h" /* [] */
#include "filesys/cache.h" /* [] */

/* Identifies an inode. */
#define INODE_MAGIC 0x494e4f44

/* [] 索引结构常量 */
#define DIRECT_CNT 122
#define INDIRECT_CNT 128

/* On-disk inode.
   Must be exactly BLOCK_SECTOR_SIZE bytes long. */
struct inode_disk {
  off_t length;                       /* File size in bytes. */
  unsigned magic;                     /* Magic number. */
  uint32_t is_dir;                    /* [] 是否是目录 */
  uint32_t padding;                   /* [] 填充 */
  block_sector_t direct[DIRECT_CNT];  /* Direct blocks. */
  block_sector_t indirect;            /* Indirect block. */
  block_sector_t doubly_indirect;     /* Doubly indirect block. */
};

/* Returns the number of sectors to allocate for an inode SIZE
   bytes long. */
static inline size_t bytes_to_sectors(off_t size) { return DIV_ROUND_UP(size, BLOCK_SECTOR_SIZE); }

/* In-memory inode. */
struct inode {
  struct list_elem elem;  /* Element in inode list. */
  block_sector_t sector;  /* Sector number of disk location. */
  int open_cnt;           /* Number of openers. */
  bool removed;           /* True if deleted, false otherwise. */
  int deny_write_cnt;     /* 0: writes ok, >0: deny writes. */
  struct inode_disk data; /* Inode content. */
  struct lock lock;       /* [] 扩容锁 */
};

/* [] 辅助函数：分配一个新扇区并清零 */
static bool alloc_sector (block_sector_t *sector_idx) {
  if (!free_map_allocate (1, sector_idx))
    return false;
  static char zeros[BLOCK_SECTOR_SIZE];
  cache_write (*sector_idx, zeros, 0, BLOCK_SECTOR_SIZE);
  return true;
}

/* [] 辅助函数：释放一个扇区 */
static void free_sector (block_sector_t sector_idx) {
  free_map_release (sector_idx, 1);
}

/* Returns the block device sector that contains byte offset POS
   within INODE.
   Returns -1 if INODE does not contain data for a byte at offset
   POS. */
static block_sector_t byte_to_sector(const struct inode* inode, off_t pos) {
  ASSERT(inode != NULL);
  if (pos >= inode->data.length)
    return -1;

  off_t index = pos / BLOCK_SECTOR_SIZE;
  block_sector_t sector;

  /* 1. Direct blocks */
  if (index < DIRECT_CNT) {
    return inode->data.direct[index];
  }
  index -= DIRECT_CNT;

  /* 2. Indirect blocks */
  if (index < INDIRECT_CNT) {
    if (inode->data.indirect == 0) return -1;
    
    block_sector_t indirect_block[INDIRECT_CNT];
    cache_read(inode->data.indirect, indirect_block, 0, BLOCK_SECTOR_SIZE);
    return indirect_block[index];
  }
  index -= INDIRECT_CNT;

  /* 3. Doubly indirect blocks */
  if (index < INDIRECT_CNT * INDIRECT_CNT) {
    if (inode->data.doubly_indirect == 0) return -1;

    off_t l1_index = index / INDIRECT_CNT;
    off_t l2_index = index % INDIRECT_CNT;
    
    block_sector_t l1_block[INDIRECT_CNT];
    cache_read(inode->data.doubly_indirect, l1_block, 0, BLOCK_SECTOR_SIZE);
    
    if (l1_block[l1_index] == 0) return -1;
    
    block_sector_t l2_block[INDIRECT_CNT];
    cache_read(l1_block[l1_index], l2_block, 0, BLOCK_SECTOR_SIZE);
    
    return l2_block[l2_index];
  }

  return -1;
}

/* [] 扩展 inode 长度，分配所需扇区 */
static bool inode_expand (struct inode *inode, off_t new_length) {
  static char zeros[BLOCK_SECTOR_SIZE]; // 全零块用于初始化
  
  if (new_length <= inode->data.length)
    return true;

  size_t new_sectors = bytes_to_sectors(new_length);
  size_t old_sectors = bytes_to_sectors(inode->data.length);
  
  if (new_sectors == old_sectors) {
    inode->data.length = new_length;
    cache_write (inode->sector, &inode->data, 0, BLOCK_SECTOR_SIZE); // 保存 metadata
    return true;
  }

  /* 需要分配新扇区，从 old_sectors 到 new_sectors - 1 */
  for (size_t i = old_sectors; i < new_sectors; ++i) {
    off_t index = i;
    
    /* 1. Direct */
    if (index < DIRECT_CNT) {
      if (!alloc_sector (&inode->data.direct[index])) goto fail;
    } 
    /* 2. Indirect */
    else if (index < DIRECT_CNT + INDIRECT_CNT) {
      index -= DIRECT_CNT;
      if (inode->data.indirect == 0) {
        if (!alloc_sector (&inode->data.indirect)) goto fail;
      }
      
      block_sector_t indirect_block[INDIRECT_CNT];
      cache_read (inode->data.indirect, &indirect_block, 0, BLOCK_SECTOR_SIZE);
      if (!alloc_sector (&indirect_block[index])) goto fail;
      cache_write (inode->data.indirect, &indirect_block, 0, BLOCK_SECTOR_SIZE);
    } 
    /* 3. Doubly Indirect */
    else {
      index -= (DIRECT_CNT + INDIRECT_CNT);
      if (inode->data.doubly_indirect == 0) {
         if (!alloc_sector (&inode->data.doubly_indirect)) goto fail;
      }
      
      off_t l1_index = index / INDIRECT_CNT;
      off_t l2_index = index % INDIRECT_CNT;
      
      block_sector_t l1_block[INDIRECT_CNT];
      cache_read (inode->data.doubly_indirect, &l1_block, 0, BLOCK_SECTOR_SIZE);
      
      if (l1_block[l1_index] == 0) {
         if (!alloc_sector (&l1_block[l1_index])) goto fail;
         cache_write (inode->data.doubly_indirect, &l1_block, 0, BLOCK_SECTOR_SIZE);
      }
      
      block_sector_t l2_block[INDIRECT_CNT];
      cache_read (l1_block[l1_index], &l2_block, 0, BLOCK_SECTOR_SIZE);
      
      if (!alloc_sector (&l2_block[l2_index])) goto fail;
      cache_write (l1_block[l1_index], &l2_block, 0, BLOCK_SECTOR_SIZE);
    }
  }
  
  inode->data.length = new_length;
  cache_write (inode->sector, &inode->data, 0, BLOCK_SECTOR_SIZE);
  return true;

fail:
  /* [] 分配失败，这里应该回滚或至少保持当前状态一致性。
     为了简单起见，我们不回滚已分配的块（只是浪费了一些空间），但更新长度。
     或者直接返回 false。 */
  return false;
}

/* List of open inodes, so that opening a single inode twice
   returns the same `struct inode'. */
static struct list open_inodes;

/* Initializes the inode module. */
void inode_init(void) { list_init(&open_inodes); }

/* Initializes an inode with LENGTH bytes of data and
   writes the new inode to sector SECTOR on the file system
   device.
   Returns true if successful.
   Returns false if memory or disk allocation fails. */
bool inode_create(block_sector_t sector, off_t length) {
  struct inode_disk* disk_inode = NULL;
  bool success = false;

  ASSERT(length >= 0);
  ASSERT(sizeof *disk_inode == BLOCK_SECTOR_SIZE);

  disk_inode = calloc(1, sizeof *disk_inode);
  if (disk_inode != NULL) {
    disk_inode->length = 0; // 初始长度 0
    disk_inode->magic = INODE_MAGIC;
    disk_inode->is_dir = 0; /* [] 默认为文件 */
    
    /* 写入 inode 到磁盘 (长度 0) */
    cache_write(sector, disk_inode, 0, BLOCK_SECTOR_SIZE);
    
    /* 创建 inode 结构用于扩展 */
    struct inode tmp_inode;
    tmp_inode.sector = sector;
    tmp_inode.data = *disk_inode; // 拷贝 content
    
    /* 扩展到指定长度 */
    if (length > 0) {
      if (inode_expand(&tmp_inode, length)) {
         success = true;
      }
    } else {
      success = true;
    }
    
    free(disk_inode);
  }
  return success;
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode* inode_open(block_sector_t sector) {
  struct list_elem* e;
  struct inode* inode;

  /* Check whether this inode is already open. */
  for (e = list_begin(&open_inodes); e != list_end(&open_inodes); e = list_next(e)) {
    inode = list_entry(e, struct inode, elem);
    if (inode->sector == sector) {
      inode_reopen(inode);
      return inode;
    }
  }

  /* Allocate memory. */
  inode = malloc(sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front(&open_inodes, &inode->elem);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;
  lock_init(&inode->lock); /* [] 初始化锁 */
  
  /* [] 使用 cache_read */
  cache_read(inode->sector, &inode->data, 0, BLOCK_SECTOR_SIZE);
  return inode;
}

/* Reopens and returns INODE. */
struct inode* inode_reopen(struct inode* inode) {
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
block_sector_t inode_get_inumber(const struct inode* inode) { return inode->sector; }

/* [] 释放 inode 占用的扇区 */
static void inode_deallocate (struct inode *inode) {
  size_t sectors = bytes_to_sectors (inode->data.length);
  for (size_t i = 0; i < sectors; ++i) {
    /* 释放逻辑比较复杂，简化：重新遍历一次 byte_to_sector 拿到扇区号并释放 */
    /* 或者更高效地遍历索引树。这里为了开发速度，可以遍历树。
       注意：释放顺序要从叶子到根。*/
  }
  
  /* 简化实现：递归释放 */
  // Direct
  for (int i = 0; i < DIRECT_CNT; i++) {
    if (inode->data.direct[i] != 0) free_sector(inode->data.direct[i]);
  }
  // Indirect
  if (inode->data.indirect != 0) {
    block_sector_t indirect_block[INDIRECT_CNT];
    cache_read(inode->data.indirect, indirect_block, 0, BLOCK_SECTOR_SIZE);
    for (int i = 0; i < INDIRECT_CNT; i++) {
        if (indirect_block[i] != 0) free_sector(indirect_block[i]);
    }
    free_sector(inode->data.indirect);
  }
  // Doubly Indirect
  if (inode->data.doubly_indirect != 0) {
    block_sector_t l1_block[INDIRECT_CNT];
    cache_read(inode->data.doubly_indirect, l1_block, 0, BLOCK_SECTOR_SIZE);
    for (int i = 0; i < INDIRECT_CNT; i++) {
        if (l1_block[i] != 0) {
            block_sector_t l2_block[INDIRECT_CNT];
            cache_read(l1_block[i], l2_block, 0, BLOCK_SECTOR_SIZE);
            for (int j = 0; j < INDIRECT_CNT; j++) {
                if (l2_block[j] != 0) free_sector(l2_block[j]);
            }
            free_sector(l1_block[i]);
        }
    }
    free_sector(inode->data.doubly_indirect);
  }
}

/* Closes INODE and writes it to disk.
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void inode_close(struct inode* inode) {
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0) {
    /* Remove from inode list and release lock. */
    list_remove(&inode->elem);

    /* Deallocate blocks if removed. */
    if (inode->removed) {
      free_map_release(inode->sector, 1);
      inode_deallocate(inode); /* [] 释放数据扇区 */
    }

    free(inode);
  }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void inode_remove(struct inode* inode) {
  ASSERT(inode != NULL);
  inode->removed = true;
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t inode_read_at(struct inode* inode, void* buffer_, off_t size, off_t offset) {
  uint8_t* buffer = buffer_;
  off_t bytes_read = 0;

  while (size > 0) {
    /* Disk sector to read, starting byte offset within sector. */
    block_sector_t sector_idx = byte_to_sector(inode, offset);
    int sector_ofs = offset % BLOCK_SECTOR_SIZE;

    /* Bytes left in inode, bytes left in sector, lesser of the two. */
    off_t inode_left = inode_length(inode) - offset;
    int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
    int min_left = inode_left < sector_left ? inode_left : sector_left;

    /* Number of bytes to actually copy out of this sector. */
    int chunk_size = size < min_left ? size : min_left;
    if (chunk_size <= 0)
      break;

    /* [] 使用 cache_read */
    // 注意：如果 sector_idx == -1 (稀疏文件?)
    if (sector_idx == (block_sector_t)-1) {
       memset(buffer + bytes_read, 0, chunk_size);
    } else {
       cache_read(sector_idx, buffer + bytes_read, sector_ofs, chunk_size);
    }

    /* Advance. */
    size -= chunk_size;
    offset += chunk_size;
    bytes_read += chunk_size;
  }

  return bytes_read;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode, but
   growth is not yet implemented.) */
off_t inode_write_at(struct inode* inode, const void* buffer_, off_t size, off_t offset) {
  const uint8_t* buffer = buffer_;
  off_t bytes_written = 0;

  if (inode->deny_write_cnt)
    return 0;

  /* [] 检查是否需要扩展文件 */
  if (offset + size > inode->data.length) {
    /* 加锁防止并发扩展冲突 */
    lock_acquire(&inode->lock);
    if (offset + size > inode->data.length) { // Double check
        if (!inode_expand(inode, offset + size)) {
            lock_release(&inode->lock);
            return 0;
        }
    }
    lock_release(&inode->lock);
  }

  while (size > 0) {
    /* Sector to write, starting byte offset within sector. */
    block_sector_t sector_idx = byte_to_sector(inode, offset);
    int sector_ofs = offset % BLOCK_SECTOR_SIZE;

    /* Bytes left in inode, bytes left in sector, lesser of the two. */
    off_t inode_left = inode_length(inode) - offset;
    int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
    int min_left = inode_left < sector_left ? inode_left : sector_left;

    /* Number of bytes to actually write into this sector. */
    int chunk_size = size < min_left ? size : min_left;
    if (chunk_size <= 0)
      break;

    /* [] 使用 cache_write */
    if (sector_idx != (block_sector_t)-1) {
       cache_write(sector_idx, buffer + bytes_written, sector_ofs, chunk_size);
    } else {
       // Should not happen if expand worked
       break;
    }

    /* Advance. */
    size -= chunk_size;
    offset += chunk_size;
    bytes_written += chunk_size;
  }

  return bytes_written;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void inode_deny_write(struct inode* inode) {
  inode->deny_write_cnt++;
  ASSERT(inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void inode_allow_write(struct inode* inode) {
  ASSERT(inode->deny_write_cnt > 0);
  ASSERT(inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t inode_length(const struct inode* inode) { return inode->data.length; }

/* [] 判断是否是目录 */
bool inode_is_dir (const struct inode *inode) {
  return inode->data.is_dir != 0;
}

/* [] 设置目录标记 */
void inode_set_dir (struct inode *inode, bool is_dir) {
  inode->data.is_dir = is_dir ? 1 : 0;
  cache_write (inode->sector, &inode->data, 0, BLOCK_SECTOR_SIZE);
}

/* [] 检查 inode 是否已被标记为删除 */
bool inode_is_removed (const struct inode *inode) {
  return inode->removed;
}


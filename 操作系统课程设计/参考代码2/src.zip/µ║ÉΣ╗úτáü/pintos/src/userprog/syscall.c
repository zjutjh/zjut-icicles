/* [] 实验四：系统调用实现 */

#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <syscall-nr.h>
#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "filesys/directory.h"
#include "filesys/inode.h"
#include "threads/interrupt.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#ifdef VM
#include "vm/page.h"
#endif

static void syscall_handler(struct intr_frame*);

/* 文件系统锁 */
struct lock filesys_lock;

/* 验证用户地址是否有效 */
static bool is_valid_uaddr(const void* addr) {
  if (addr == NULL) return false;
  if (!is_user_vaddr(addr)) return false;
  
  if (thread_current()->pcb == NULL) return false;
  
#ifdef VM
  /* VM 模式下：不允许内核直接崩溃。
     如果地址在 SPT 中，则有效。
     如果是栈增长区域，也可能有效（这里我们简单地认为所有用户地址都有可能有效，
     如果无效，由 Page Fault Handler 捕获并终止进程）。
     
     但是，如果我们返回 true，然后解引用发生了 Page Fault，如果 Page Fault 处理失败，
     会调用 kill -> process_exit。符合要求。
     
     所以只要是不是 NULL 且是 USER 空间，我们暂时返回 true (不做 pagedir 检查)。
     
     但是，为了防止访问未映射的内核地址（虽然 is_user_vaddr 挡住了），
     或者完全非法的地址（例如未映射的堆区），
     如果有 SPT，最好查一下 SPT。如果 SPT 也没有，且不是栈增长范围，就应该返回 false。
  */
  
  /* 优化：只做基本检查，把困难交给 Page Fault。
     注意：Syscall handler 运行在内核，访问用户内存触发 PF 是安全的吗？
     exception.c 中的 page_fault 处理了 user=false (kernel) 但 addr 是 user 的情况。
     只要 f->cs 是内核段，但 fault_addr 是用户段。我们修改了 exception.c 来处理这个。
  */
  return true; 
#else
  if (thread_current()->pcb->pagedir == NULL) return false;
  return pagedir_get_page(thread_current()->pcb->pagedir, addr) != NULL;
#endif
}

/* [] 验证 4 字节读取是否安全（防止跨页边界） */
static bool is_valid_uaddr_4bytes(const void* addr) {
  return is_valid_uaddr(addr) && is_valid_uaddr((const char*)addr + 3);
}

/* 从用户空间读取一个 word */
static bool get_user_word(const uint32_t* addr, uint32_t* result) {
  if (!is_valid_uaddr(addr))
    return false;
  *result = *addr;
  return true;
}

/* 验证用户字符串 */
static bool is_valid_string(const char* str) {
  while (is_valid_uaddr(str)) {
    if (*str == '\0')
      return true;
    str++;
  }
  return false;
}

/* 验证用户缓冲区 */
static bool is_valid_buffer(const void* buf, unsigned size) {
  if (size == 0)
    return true;
  
  /* 检查每一页的有效性 */
  const char* p = (const char*)buf;
  unsigned i;
  for (i = 0; i < size; i += PGSIZE) {
    if (!is_valid_uaddr(p + i))
      return false;
  }
  /* 检查最后一个字节 */
  if (!is_valid_uaddr(p + size - 1))
    return false;
    
  return true;
}

/* 获取文件描述符对应的文件 */
static struct file* get_file(int fd) {
  struct thread* t = thread_current();
  if (fd < 2 || fd >= 128)
    return NULL;
  return t->pcb->open_files[fd];
}

void syscall_init(void) {
  intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&filesys_lock);
}

/* 退出进程 */
static void sys_exit(int status) {
  struct thread* t = thread_current();
  if (t->pcb != NULL) {
    t->pcb->exit_status = status;
    printf("%s: exit(%d)\n", t->pcb->process_name, status);
  }
  process_exit();
}

static void syscall_handler(struct intr_frame* f) {
#ifdef VM
  thread_current()->user_esp = f->esp;
#endif
  uint32_t* esp = (uint32_t*)f->esp;
  

  
  /* 验证栈指针及 syscall number 内存 */
  if (!is_valid_buffer(esp, sizeof(uint32_t))) {

    sys_exit(-1);
    return;
  }

  int syscall_num = esp[0];

  switch (syscall_num) {
    case SYS_HALT:
      shutdown_power_off();
      break;

    case SYS_EXIT:
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      sys_exit((int)esp[1]);
      break;

    case SYS_PRACTICE:
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      f->eax = esp[1] + 1;
      break;

    case SYS_EXEC: {
      /* [] 使用 4 字节验证，防止参数跨页边界 */
      if (!is_valid_uaddr_4bytes(esp + 1)) { sys_exit(-1); return; }
      const char* cmd = (const char*)esp[1];
      if (!is_valid_string(cmd)) { sys_exit(-1); return; }
      /* [] 不在这里加锁，process_execute 内部的 load 会加锁 */
      f->eax = process_execute(cmd);
      break;
    }

    case SYS_WAIT:
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      f->eax = process_wait((pid_t)esp[1]);
      break;

    case SYS_CREATE: {
      if (!is_valid_uaddr(esp + 2)) { sys_exit(-1); return; }
      const char* file = (const char*)esp[1];
      unsigned size = esp[2];
      if (!is_valid_string(file)) { sys_exit(-1); return; }
      lock_acquire(&filesys_lock);
      f->eax = filesys_create(file, size);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_REMOVE: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      const char* file = (const char*)esp[1];
      if (!is_valid_string(file)) { sys_exit(-1); return; }
      lock_acquire(&filesys_lock);
      f->eax = filesys_remove(file);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_OPEN: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      const char* file = (const char*)esp[1];
      if (!is_valid_string(file)) { sys_exit(-1); return; }
      
      lock_acquire(&filesys_lock);
      struct file* opened = filesys_open(file);
      lock_release(&filesys_lock);
      
      if (opened == NULL) {
        f->eax = -1;
        break;
      }
      
      /* 寻找空闲 fd */
      struct thread* t = thread_current();
      int fd;
      for (fd = 2; fd < 128; fd++) {
        if (t->pcb->open_files[fd] == NULL) {
          t->pcb->open_files[fd] = opened;
          f->eax = fd;
          break;
        }
      }
      if (fd == 128) {
        file_close(opened);
        f->eax = -1;
      }
      break;
    }

    case SYS_FILESIZE: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      struct file* file = get_file(fd);
      if (file == NULL) {
        f->eax = -1;
        break;
      }
      lock_acquire(&filesys_lock);
      f->eax = file_length(file);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_READ: {
      if (!is_valid_uaddr(esp + 3)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      void* buffer = (void*)esp[2];
      unsigned size = esp[3];
      
      if (!is_valid_buffer(buffer, size)) { sys_exit(-1); return; }
      
      if (fd == 0) {  /* STDIN */
        uint8_t* buf = buffer;
        unsigned i;
        for (i = 0; i < size; i++)
          buf[i] = input_getc();
        f->eax = size;
      } else {
        struct file* file = get_file(fd);
        if (file == NULL) {
          f->eax = -1;
          break;
        }
        lock_acquire(&filesys_lock);
        /* [] 目录不能使用 read 读取，必须用 readdir */
        if (inode_is_dir(file_get_inode(file))) {
            lock_release(&filesys_lock);
            f->eax = -1;
            break;
        }
        f->eax = file_read(file, buffer, size);
        lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_WRITE: {
      if (!is_valid_uaddr(esp + 3)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      const void* buffer = (const void*)esp[2];
      unsigned size = esp[3];
      
      if (!is_valid_buffer(buffer, size)) { sys_exit(-1); return; }
      
      if (fd == 1) {  /* STDOUT */
        putbuf(buffer, size);
        f->eax = size;
      } else {
        struct file* file = get_file(fd);
        if (file == NULL) {
          f->eax = -1;
          break;
        }
        lock_acquire(&filesys_lock);
        /* [] 目录不能使用 write 写入 */
        if (inode_is_dir(file_get_inode(file))) {
            lock_release(&filesys_lock);
            f->eax = -1;
            break;
        }
        f->eax = file_write(file, buffer, size);
        lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_SEEK: {
      if (!is_valid_uaddr(esp + 2)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      unsigned pos = esp[2];
      struct file* file = get_file(fd);
      if (file != NULL) {
        lock_acquire(&filesys_lock);
        file_seek(file, pos);
        lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_TELL: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      struct file* file = get_file(fd);
      if (file == NULL) {
        f->eax = 0;
        break;
      }
      lock_acquire(&filesys_lock);
      f->eax = file_tell(file);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_CLOSE: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      struct file* file = get_file(fd);
      if (file != NULL) {
        lock_acquire(&filesys_lock);
        file_close(file);
        lock_release(&filesys_lock);
        thread_current()->pcb->open_files[fd] = NULL;
      }
      break;
    }

    /* [] 浮点计算 e 的系统调用
       全局 FPU 保存/恢复已处理用户 FPU 状态 */
    case SYS_COMPUTE_E: {
      if (!is_valid_uaddr(esp + 1)) { 
        sys_exit(-1); 
        return; 
      }
      int n = (int)esp[1];
      f->eax = sys_sum_to_e(n);
      break;
    }

      break;

    /* [] 实验五：目录相关系统调用 */
    case SYS_CHDIR: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      const char* path = (const char*)esp[1];
      if (!is_valid_string(path)) { sys_exit(-1); return; }
      
      lock_acquire(&filesys_lock);
      /* 使用 filesys_open 解析路径 */
      /* 注意：filesys_open 返回 file*，我们需要检查是否是目录并更新 cwd */
      /* 如果 path 是 "/"，filesys_open 返回 root */
      /* 如果 path 是 ".", filesys_open 返回当前目录副本 */
      struct file *opened_file = filesys_open(path);
      if (opened_file != NULL) {
          struct inode *inode = file_get_inode(opened_file);
          if (inode_is_dir(inode)) {
              struct dir *old_cwd = thread_current()->cwd;
              thread_current()->cwd = dir_open(inode_reopen(inode));
              if (old_cwd) dir_close(old_cwd); // old_cwd might be NULL? No, initialized in init.c
              file_close(opened_file);
              f->eax = true;
          } else {
              file_close(opened_file);
              f->eax = false;
          }
      } else {
          f->eax = false;
      }
      lock_release(&filesys_lock);
      break;
    }

    case SYS_MKDIR: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      const char* path = (const char*)esp[1];
      if (!is_valid_string(path)) { sys_exit(-1); return; }
      
      lock_acquire(&filesys_lock);
      f->eax = filesys_create_dir(path);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_READDIR: {
      if (!is_valid_uaddr(esp + 2)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      char* name = (char*)esp[2];
      if (!is_valid_uaddr(name)) { sys_exit(-1); return; }
      
      struct file* file = get_file(fd);
      if (file == NULL) {
          f->eax = false;
      } else {
          lock_acquire(&filesys_lock);
          struct inode *inode = file_get_inode(file);
          if (!inode_is_dir(inode)) {
              f->eax = false;
          } else {
              /* 临时打开目录读取一项 */
              struct dir *d = dir_open(inode_reopen(inode));
              dir_seek(d, file_tell(file));
              if (dir_readdir(d, name)) {
                  file_seek(file, dir_tell(d));
                  f->eax = true;
              } else {
                  f->eax = false;
              }
              dir_close(d);
          }
          lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_ISDIR: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      struct file* file = get_file(fd);
      if (file == NULL) {
          f->eax = false;
      } else {
          lock_acquire(&filesys_lock);
          f->eax = inode_is_dir(file_get_inode(file));
          lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_INUMBER: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      struct file* file = get_file(fd);
      if (file == NULL) {
          f->eax = -1;
      } else {
          lock_acquire(&filesys_lock);
          f->eax = inode_get_inumber(file_get_inode(file));
          lock_release(&filesys_lock);
      }
      break;
    }

    /* [] 实验六：mmap 和 munmap 系统调用 */
#ifdef VM
    case SYS_MMAP: {
      if (!is_valid_uaddr(esp + 2)) { sys_exit(-1); return; }
      int fd = (int)esp[1];
      void *addr = (void*)esp[2];
      
      struct file* file = get_file(fd);
      if (file == NULL || fd == 0 || fd == 1) {
          f->eax = -1;  /* 不能映射 stdin/stdout 或无效 fd */
      } else {
          lock_acquire(&filesys_lock);
          f->eax = vm_mmap(file, addr);
          lock_release(&filesys_lock);
      }
      break;
    }

    case SYS_MUNMAP: {
      if (!is_valid_uaddr(esp + 1)) { sys_exit(-1); return; }
      int mapid = (int)esp[1];
      
      lock_acquire(&filesys_lock);
      vm_munmap(mapid);
      lock_release(&filesys_lock);
      break;
    }
#endif

    default:
      sys_exit(-1);
      break;
  }
  
}

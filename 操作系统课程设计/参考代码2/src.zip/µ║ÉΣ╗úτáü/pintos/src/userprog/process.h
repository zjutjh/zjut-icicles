#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"
#include "threads/synch.h"
#include "lib/kernel/list.h"
#include <stdint.h>

// At most 8MB can be allocated to the stack
// These defines will be used in Project 2: Multithreading
#define MAX_STACK_PAGES (1 << 11)
#define MAX_THREADS 127

/* PIDs and TIDs are the same type. PID should be
   the TID of the main thread of the process */
typedef tid_t pid_t;

/* Thread functions (Project 2: Multithreading) */
typedef void (*pthread_fun)(void*);
typedef void (*stub_fun)(pthread_fun, void*);

/* The process control block for a given process. Since
   there can be multiple threads per process, we need a separate
   PCB from the TCB. All TCBs in a process will have a pointer
   to the PCB, and the PCB will have a pointer to the main thread
   of the process, which is `special`. */
struct process {
  /* Owned by process.c. */
  uint32_t* pagedir;          /* Page directory. */
  char process_name[16];      /* Name of the main thread */
  struct thread* main_thread; /* Pointer to main thread */
  
  /* [] 文件描述符管理：使用固定数组 */
  struct file* open_files[128];  /* 打开的文件，0=stdin, 1=stdout */
  
  /* [] 父子进程管理 */
  pid_t pid;                        /* 进程 ID */
  struct process* parent;           /* 父进程 */
  struct list children;             /* 子进程列表 */
  struct list_elem child_elem;      /* 用于父进程的 children 列表 */
  struct semaphore wait_sema;       /* 等待子进程退出的信号量 */
  int exit_status;                  /* 退出状态 */
  bool exited;                      /* 是否已退出 */
  bool waited;                      /* 父进程是否已 wait */
  struct semaphore load_sema;       /* 等待加载完成 */
  bool load_success;                /* 加载是否成功 */
  struct file* executable_file;     /* 当前运行的可执行文件（用于 ROX） */
  
  /* [] 实验六：内存映射文件 */
  struct list mmap_list;            /* mmap 映射列表 */
  int next_mapid;                   /* 下一个 mapid */
};

void userprog_init(void);

pid_t process_execute(const char* file_name);
int process_wait(pid_t);
void process_exit(void);
void process_activate(void);

bool is_main_thread(struct thread*, struct process*);
pid_t get_pid(struct process*);

#endif /* userprog/process.h */

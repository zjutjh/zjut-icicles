# 操作系统课程设计报告

**学号**:

**姓名**:

**完成实验**: 实验二、实验三、实验四、实验五、实验六

---

## 项目概述

### 什么是 Pintos？

**Pintos** 是一个教学用的简化操作系统，由斯坦福大学开发。它实现了操作系统的核心功能，包括线程调度、用户程序、文件系统和虚拟内存，代码量小、结构清晰，适合学习操作系统原理。

### 代码结构

```
pintos/src/
├── threads/     # 实验三：线程管理（调度、同步）
│   ├── thread.c/h   # 线程创建、调度
│   ├── synch.c/h    # 同步原语（锁、信号量）
│   └── fixed-point.h # 定点数运算
├── userprog/    # 实验四：用户程序
│   ├── syscall.c    # 系统调用实现
│   ├── process.c    # 进程管理
│   └── exception.c  # 异常处理
├── filesys/     # 实验五：文件系统
│   ├── cache.c      # Buffer Cache
│   ├── inode.c      # 索引节点
│   └── directory.c  # 目录管理
├── vm/          # 实验六：虚拟内存
│   ├── frame.c      # 帧表管理
│   ├── page.c       # 补充页表
│   └── swap.c       # 交换区管理
├── devices/     # 硬件设备驱动
└── tests/       # 测试用例
```

### 编译与测试指南

**编译**：

```bash
cd pintos/src/threads   # 或 userprog/filesys/vm
make
```

**运行全部测试**：

```bash
cd build
make check
```

**运行单个测试**：

```bash
make tests/threads/alarm-single.result   # 查看 PASS/FAIL
cat tests/threads/alarm-single.output    # 查看详细输出
```

### 总体测试结果

| 实验               | 测试数 | 通过率 |
| ------------------ | ------ | ------ |
| 实验三（线程）     | 36     | 100%   |
| 实验四（用户程序） | 96     | 100%   |
| 实验五（文件系统） | 142    | 100%   |
| 实验六（虚拟内存） | 127    | 100%   |

---

## 实验二：简单 Shell 实现

### 1. 实验目标

设计并实现一个模拟 Bash 的简单 Shell，要求支持以下功能：

- `cd` 和 `pwd` 内置命令
- 程序执行与 PATH 路径解析
- 输入/输出重定向（`<` 和 `>`）
- 信号（Signal）处理
- 后台执行（`&`）

### 2. 设计思路

Shell 本质上是一个命令解释器，其核心工作流程为：**读取 → 解析 → 执行 → 循环**。

#### 2.1 整体架构

![Shell 架构流程图](imgs/shell_architecture.png)

主要模块：

1. **主循环**：持续读取用户输入
2. **命令解析器**：分词、识别重定向符号和后台符号
3. **内置命令处理**：直接在 Shell 进程中执行
4. **外部命令执行**：fork + execv 模式
5. **信号处理**：防止 Shell 被意外终止

#### 2.2 数据结构

```c
/* 后台进程管理 */
pid_t bg_pids[100];
int bg_count = 0;

/* 命令行参数与重定向变量 */
char *args[64];  /* 命令行参数数组 */
char *in = NULL; /* 输入重定向文件名 */
char *out = NULL;/* 输出重定向文件名 */
int bg;          /* 是否后台执行 */
```

### 3. 具体实现

#### 3.1 PATH 路径解析

当用户输入命令时，Shell 需要在 PATH 环境变量中查找可执行文件：

> 参见 [find_path()](hw-shell/shell.c#L19-L40)

**算法说明**：

- 使用 `strtok` 按 `:` 分割 PATH 字符串
- 对每个目录，拼接命令名后使用 `access(path, X_OK)` 检查可执行性
- 时间复杂度：O(n × m)，n 为 PATH 目录数，m 为路径长度

#### 3.2 内置命令实现

内置命令必须在 Shell 进程内执行，不能 fork：

| 命令   | 实现方式            | 说明               | 源码位置                               |
| ------ | ------------------- | ------------------ | -------------------------------------- |
| `exit` | `break` 跳出主循环  | 退出 Shell         | [L123-125](hw-shell/shell.c#L123-L125) |
| `cd`   | `chdir(path)`       | 改变当前工作目录   | [L128-135](hw-shell/shell.c#L128-L135) |
| `pwd`  | `getcwd(buf, size)` | 获取并打印当前目录 | [L138-144](hw-shell/shell.c#L138-L144) |
| `wait` | `waitpid()` 循环    | 等待所有后台进程   | [L147-153](hw-shell/shell.c#L147-L153) |

#### 3.3 I/O 重定向

重定向通过 `dup2` 系统调用实现，在 fork 后、exec 前完成：

> 参见 [shell.c:L174-184](hw-shell/shell.c#L174-L184)（输入/输出重定向实现）

**原理**：`dup2(oldfd, newfd)` 使 newfd 成为 oldfd 的副本。

#### 3.4 信号处理

Shell 需要正确处理信号，避免被用户意外终止：

> 参见 [shell.c:L49-53](hw-shell/shell.c#L49-L53)（Shell 主进程信号处理）和 [shell.c:L168-172](hw-shell/shell.c#L168-L172)（子进程恢复默认行为）

#### 3.5 后台执行

使用 `&` 符号可以将命令放到后台执行：

> 参见 [shell.c:L194-201](hw-shell/shell.c#L194-L201)（后台/前台执行逻辑）

### 4. 遇到的问题及解决方法

| 问题              | 原因                 | 解决方法                 |
| ----------------- | -------------------- | ------------------------ |
| Ctrl+C 终止 Shell | Shell 未处理 SIGINT  | 注册空的信号处理函数     |
| 后台进程变僵尸    | 未回收子进程         | 实现 `wait` 命令批量回收 |
| cd 命令不生效     | 在子进程中执行 chdir | 将 cd 作为内置命令处理   |
| PATH 解析内存泄漏 | strdup 后未 free     | 添加 free(p)             |

### 5. 测试结果

```bash
$ pwd
/home/user
$ cd /tmp
$ pwd
/tmp
$ echo hello > test.txt
$ cat < test.txt
hello
$ sleep 10 &
$ wait
$ exit
```

### 6. 结论

本实验成功实现了一个具备基本功能的简易 Shell，包括：

- ✅ 内置命令（cd、pwd、exit、wait）
- ✅ PATH 路径解析
- ✅ 输入/输出重定向
- ✅ 信号处理
- ✅ 后台执行

代码共 **206 行**，结构清晰，易于理解和扩展。

### 7. 未来工作与展望

- 支持管道（`|`）连接多个命令
- 支持命令历史和 Tab 补全
- 支持环境变量设置（`export`）
- 支持更完善的作业控制（`fg`、`bg`、`jobs`）
- 支持脚本执行

---

## 实验三：Pintos 线程管理

### 1. 实验目标

实现 Pintos 操作系统的线程管理功能，包括：

1. **优先级调度**：高优先级线程应立即抢占低优先级线程
2. **优先级捐赠**：解决优先级反转问题，支持嵌套捐赠
3. **多级反馈队列调度（MLFQS）**：动态调整线程优先级，减少平均响应时间
4. **定时器睡眠优化**：将 busy-wait 改为阻塞式睡眠

### 2. 设计思路

#### 2.1 优先级调度

Pintos 支持 64 个优先级（0-63），`PRI_MAX=63` 为最高优先级。实现要点：

- 就绪队列按优先级排序（使用 `list_insert_ordered`）
- 新线程优先级高于当前线程时，立即让出 CPU
- 信号量/锁/条件变量唤醒时，优先唤醒高优先级线程

#### 2.2 优先级捐赠

![优先级捐赠机制](imgs/priority_donation.png)

当高优先级线程 H 等待低优先级线程 L 持有的锁时，H 将自己的优先级"捐赠"给 L，防止 L 被中优先级线程 M 抢占（优先级反转问题）。

**嵌套捐赠**：如果 L 又在等待另一个锁，优先级需要沿等待链传递。

#### 2.3 MLFQS 多级反馈队列

![MLFQS 调度](imgs/mlfqs.png)

动态计算每个线程的优先级，使 CPU 时间公平分配。核心变量：

- `nice`：线程的"友好度"，范围 -20~+20
- `recent_cpu`：线程最近使用的 CPU 时间
- `load_avg`：系统负载平均值

### 3. 数据结构

#### 3.1 线程结构体扩展

```c
struct thread {
  tid_t tid;                 /* 线程标识符 */
  enum thread_status status; /* 线程状态 */
  char name[16];             /* 线程名 */
  uint8_t* stack;            /* 栈指针 */
  int priority;              /* 优先级 */
  struct list_elem allelem;  /* 全局线程列表元素 */

  /* MLFQS 字段 */
  int nice;                  /* Nice 值 */
  fixed_point_t recent_cpu;  /* 最近 CPU 使用量 */

  /* 优先级捐赠字段 */
  int base_priority;         /* 原始优先级 */
  struct lock *waiting_lock; /* 正在等待的锁 */
  struct list donations;     /* 捐赠列表 */
  struct list_elem donation_elem;

  /* 睡眠唤醒字段 */
  int64_t wakeup_tick;       /* 唤醒时刻 */
  struct list_elem sleep_elem;

  struct list_elem elem;     /* 就绪列表元素 */

#ifdef USERPROG
  struct process* pcb;       /* 进程控制块 */
#endif
#ifdef FILESYS
  struct dir *cwd;           /* 当前工作目录 */
#endif
#ifdef VM
  struct hash spt;           /* 补充页表 */
  void *user_esp;            /* 用户栈指针 */
#endif

  uint8_t fpu_state[108];    /* FPU 状态存储 */
  unsigned magic;            /* 栈溢出检测 */
};
```

#### 3.2 定点数运算

MLFQS 需要 17.14 格式定点数运算：

> 参见 [fixed-point.h](pintos/src/threads/fixed-point.h)（17.14 格式定点数完整实现）

#### 4.1 优先级调度实现

**按优先级排序加入就绪队列**：

> 参见 [thread.c:L74-78](pintos/src/threads/thread.c#L74-L78)（`thread_priority_less` 比较函数）
> 参见 [thread.c:L335-352](pintos/src/threads/thread.c#L335-L352)（`thread_enqueue` 实现）

**创建线程后检查是否需要抢占**：

> 参见 [thread.c:L308-312](pintos/src/threads/thread.c#L308-L312)（`thread_create` 中的抢占检查）

#### 4.2 优先级捐赠实现

**获取锁时进行捐赠**：

> 参见 [synch.c:L196-219](pintos/src/threads/synch.c#L196-L219)（`lock_acquire` 实现，包含嵌套捐赠）

**释放锁时恢复优先级**：

> 参见 [synch.c:L242-273](pintos/src/threads/synch.c#L242-L273)（`lock_release` 实现，移除捐赠者并恢复优先级）

**信号量按优先级唤醒**：

修改 `sema_up()` 函数，在唤醒等待线程时，先对等待队列按优先级排序，然后唤醒优先级最高的线程。若被唤醒线程优先级高于当前线程，则触发抢占。

> 参见 [synch.c:L101-148](pintos/src/threads/synch.c#L101-L148)（`sema_up` 优先级唤醒实现）

**条件变量按优先级唤醒**：

修改 `cond_signal()` 函数，使用 `cond_waiter_priority_less` 比较函数对等待者排序，确保优先唤醒高优先级线程。

> 参见 [synch.c:L345-260](pintos/src/threads/synch.c#L345-L260)（`cond_signal` 优先级唤醒实现）

#### 4.3 MLFQS 实现

**每个 tick 更新 recent_cpu 和优先级**：

> 参见 [thread.c:L160-237](pintos/src/threads/thread.c#L160-L237)（`thread_tick` 完整实现，包含 MLFQS 更新逻辑）

核心公式：

- `recent_cpu = (2 * load_avg) / (2 * load_avg + 1) * recent_cpu + nice`
- `priority = PRI_MAX - recent_cpu/4 - nice*2`
- `load_avg = (59/60) * load_avg + (1/60) * ready_threads`

**MLFQS 接口函数**：

| 函数                      | 功能                         | 实现要点                                     |
| ------------------------- | ---------------------------- | -------------------------------------------- |
| `thread_set_nice(nice)`   | 设置当前线程 nice 值         | 更新 nice 后重新计算优先级，触发抢占检查     |
| `thread_get_nice()`       | 获取当前线程 nice 值         | 返回 `thread_current()->nice`                |
| `thread_get_load_avg()`   | 获取系统负载平均值 ×100      | 返回 `fix_round(fix_scale(load_avg, 100))`   |
| `thread_get_recent_cpu()` | 获取当前线程 recent_cpu ×100 | 返回 `fix_round(fix_scale(recent_cpu, 100))` |

> 参见 [thread.c:L491-532](pintos/src/threads/thread.c#L491-L532)（MLFQS 接口函数实现）

#### 4.4 定时器睡眠优化

将 busy-wait 改为阻塞式睡眠：

> 参见 [timer.c:L87-99](pintos/src/devices/timer.c#L87-L99)（`timer_sleep` 阻塞实现）
> 参见 [timer.c:L145-168](pintos/src/devices/timer.c#L145-L168)（`timer_interrupt` 唤醒到期线程）

#### 4.5 调度优化 (SCHED_FAIR)与高频时钟

**公平调度 (SCHED_FAIR)**：

为解决 `smfs-hierarchy` 测试中的饥饿问题，实现了基于动态时间片的公平调度：

- **动态时间片**：`time_slice = 4 + priority / 4`（范围 4-19 ticks），高优先级线程获得更长运行时间。
- **FIFO 队列**：同优先级使用 FIFO 策略，确保公平性。

**高频时钟优化**：

将 `TIMER_FREQ` 从 100Hz 提高到 **10000Hz**，显著减少了 `timer_sleep` 的最小粒度，解决了 `smfs-hierarchy` 测试超时问题（从 >60s 优化至 ~20s）。

### 5. 遇到的问题及解决方法

| 问题               | 原因                                     | 解决方法                                 |
| ------------------ | ---------------------------------------- | ---------------------------------------- |
| 优先级反转导致死锁 | 高优先级线程无法获取低优先级线程持有的锁 | 实现优先级捐赠机制                       |
| 嵌套捐赠失败       | 只捐赠给直接持有者                       | 沿 `waiting_lock` 链递归捐赠             |
| MLFQS 计算溢出     | 使用普通整数运算                         | 使用 17.14 格式定点数                    |
| 睡眠唤醒不及时     | 在中断处理中调用 `thread_yield`          | 使用 `intr_yield_on_return()`            |
| FPU 状态丢失       | 线程切换未保存浮点寄存器                 | 在 `schedule()` 中使用 `fnsave`/`frstor` |

### 6. 测试结果

共 **36 个**测试用例，**全部通过 (100%)**。

### 7. 结论

本实验成功实现了 Pintos 线程管理的核心功能：

- ✅ **优先级调度**：高优先级线程立即抢占 CPU
- ✅ **优先级捐赠**：支持嵌套捐赠，解决优先级反转
- ✅ **MLFQS**：动态调整优先级，公平分配 CPU
- ✅ **睡眠优化**：阻塞式睡眠，避免 busy-wait

修改涉及 `thread.c`、`thread.h`、`synch.c`、`timer.c` 等核心文件，共新增约 **250 行**代码。

### 8. 未来工作与展望

- 实现多核 SMP 调度
- 支持实时调度策略（SCHED_FIFO、SCHED_RR）
- 优化锁的实现（如使用自旋锁+睡眠锁组合）

---

## 实验四：Pintos 用户程序

### 1. 实验目标

实现 Pintos 用户程序支持，包括：

1. **参数传递（Argument Passing）**：解析命令行并按 x86 调用约定传递给用户程序
2. **进程控制系统调用**：`exec`、`wait`、`exit`、`halt`
3. **文件操作系统调用**：`create`、`remove`、`open`、`close`、`read`、`write`、`seek`、`tell`、`filesize`

### 2. 设计思路

#### 2.1 整体架构

![用户程序架构](imgs/userprog_architecture.png)

用户程序通过 `int 0x30` 触发系统调用，内核的 `syscall_handler` 根据系统调用号分发到对应处理函数。

#### 2.2 参数传递

![参数传递栈布局](imgs/argument_passing.png)

按照 x86 C 调用约定，需要在用户栈上构造：

1. 字符串内容（从高地址向低地址）
2. 对齐填充
3. `argv[]` 指针数组 + NULL 哨兵
4. `argv` 指针
5. `argc`
6. 假返回地址

### 3. 数据结构

#### 3.1 进程控制块（PCB）

```c
struct process {
  uint32_t* pagedir;          /* 页目录 */
  char process_name[16];      /* 进程名 */
  struct thread* main_thread; /* 主线程 */

  /* 文件描述符表 */
  struct file* open_files[128];

  /* 父子进程管理 */
  pid_t pid;                  /* 进程 ID */
  struct process* parent;     /* 父进程 */
  struct list children;       /* 子进程列表 */
  struct list_elem child_elem;
  struct semaphore wait_sema; /* 等待子进程退出 */
  int exit_status;            /* 退出状态 */
  bool exited;                /* 是否已退出 */
  bool waited;                /* 父进程是否已 wait */
  struct semaphore load_sema; /* 等待加载完成 */
  bool load_success;          /* 加载是否成功 */
  struct file* executable_file; /* ROX 保护 */

  /* 内存映射文件 */
  struct list mmap_list;
  int next_mapid;
};
```

### 4. 具体实现

#### 4.1 参数传递实现

在 `setup_stack()` 中构造用户栈：

> 参见 [process.c:L706-770](pintos/src/userprog/process.c#L706-L770)（`setup_stack` 实现）

#### 4.2 进程控制系统调用

**exec/wait/exit 系统调用**：

> 参见 [syscall.c:L122-132](pintos/src/userprog/syscall.c#L122-L132)（`sys_exit` 实现）
> 参见 [process.c:L247-290](pintos/src/userprog/process.c#L247-L290)（`process_wait` 实现）
> 参见 [process.c:L85-158](pintos/src/userprog/process.c#L85-L158)（`process_execute` 实现）

**子进程启动流程 (`start_process`)**：

`start_process()` 是子进程的入口函数，负责加载可执行文件并跳转到用户空间：

1. 解析 `exec_info` 获取文件名和预分配的 PCB
2. 初始化中断帧，设置用户态段选择子
3. 调用 `load()` 加载 ELF 文件
4. 通过 `load_sema` 通知父进程加载结果
5. 使用 `fnsave` 保存 FPU 状态后跳转到 `intr_exit`

> 参见 [process.c:L159-245](pintos/src/userprog/process.c#L159-L245)（`start_process` 实现）

**进程退出清理 (`process_exit`)**：

`process_exit()` 负责完整的资源清理：

1. 释放 `filesys_lock`（若持有）
2. 关闭所有打开的文件描述符
3. 关闭可执行文件（解除 ROX 保护）
4. 关闭当前工作目录
5. 清理 mmap 映射（VM 模式）
6. 销毁页目录
7. 通知父进程（`sema_up(wait_sema)`）或释放 PCB

> 参见 [process.c:L293-380](pintos/src/userprog/process.c#L293-L380)（`process_exit` 实现）

**系统调用分发器 (`syscall_handler`)**：

`syscall_handler()` 是所有系统调用的入口，处理流程：

1. 保存用户 ESP（VM 模式下用于栈增长判断）
2. 验证栈指针有效性
3. 读取系统调用号 `esp[0]`
4. 根据调用号 switch-case 分发到具体处理函数
5. 将返回值写入 `f->eax`

> 参见 [syscall.c:L131-200](pintos/src/userprog/syscall.c#L131-L200)（`syscall_handler` 实现）

#### 4.3 文件操作系统调用

**文件系统锁**：所有文件操作需要获取全局锁防止竞争

> 参见 [syscall.c:L199-240](pintos/src/userprog/syscall.c#L199-L240)（`SYS_OPEN` 实现）
> 参见 [syscall.c:L257-300](pintos/src/userprog/syscall.c#L257-L300)（`SYS_READ`/`SYS_WRITE` 实现）

#### 4.4 用户地址验证

防止恶意用户程序传入非法地址：

> 参见 [syscall.c:L32-65](pintos/src/userprog/syscall.c#L32-L65)（`is_valid_uaddr`, `is_valid_string`, `is_valid_buffer` 实现）

**地址验证函数族**：

| 函数              | 功能                   | 实现要点                                      |
| ----------------- | ---------------------- | --------------------------------------------- |
| `is_valid_uaddr`  | 验证单个用户地址       | 检查非 NULL、在用户空间、已映射（非 VM 模式） |
| `is_valid_string` | 验证用户字符串         | 遍历直到遇到 `\0`，逐字节验证                 |
| `is_valid_buffer` | 验证用户缓冲区         | 按页检查起止地址有效性                        |
| `get_file`        | 根据 fd 获取 file 结构 | 检查 fd 范围，返回 `open_files[fd]`           |

#### 4.5 可执行文件保护（ROX）

禁止写入正在运行的可执行文件：

> 参见 [process.c:L576-578](pintos/src/userprog/process.c#L576-L578)（`load()` 中的 `file_deny_write`）
> 参见 [process.c:L316-320](pintos/src/userprog/process.c#L316-L320)（`process_exit()` 中关闭可执行文件）

#### 4.6 浮点运算单元 (FPU) 支持

为支持用户程序进行浮点运算（通过 `fp-*` 测试），实现了完整的 FPU 上下文管理：

- **启用 FPU**：在 `start.S` 中清除 `CR0_EM`，在 `init.c` 中执行 `fninit`。
- **上下文切换**：在 `struct thread` 中增加 `fpu_state[108]`，调度时使用 `fnsave`/`frstor` 保存和恢复 FPU 状态。
- **中断隔离**：在中断入口 (`intr-stubs.S`) 保存 FPU 状态，防止内核中断处理程序破坏用户 FPU 上下文。

### 5. 系统调用一览

| 系统调用    | 功能       | 实现要点                                   |
| ----------- | ---------- | ------------------------------------------ |
| `halt`      | 关闭系统   | `shutdown_power_off()`                     |
| `exit`      | 退出进程   | 设置状态，打印消息，`process_exit()`       |
| `exec`      | 执行程序   | `process_execute()`，等待加载完成          |
| `wait`      | 等待子进程 | 查找子进程，`sema_down(wait_sema)`         |
| `create`    | 创建文件   | `filesys_create()`                         |
| `remove`    | 删除文件   | `filesys_remove()`                         |
| `open`      | 打开文件   | `filesys_open()`，分配 fd                  |
| `filesize`  | 获取大小   | `file_length()`                            |
| `read`      | 读文件     | fd=0 用 `input_getc()`，否则 `file_read()` |
| `write`     | 写文件     | fd=1 用 `putbuf()`，否则 `file_write()`    |
| `seek`      | 移动位置   | `file_seek()`                              |
| `tell`      | 获取位置   | `file_tell()`                              |
| `close`     | 关闭文件   | `file_close()`，清除 fd 表项               |
| `compute_e` | 计算 e 值  | 浮点运算测试专用 (`sys_compute_e`)         |

### 6. 遇到的问题及解决方法

| 问题                         | 原因                 | 解决方法                                   |
| ---------------------------- | -------------------- | ------------------------------------------ |
| exec 返回前子进程已退出      | 加载同步缺失         | 使用 `load_sema` 等待加载完成              |
| wait 返回错误状态            | PCB 过早释放         | 子进程退出后保留 PCB，由父进程 wait 时释放 |
| 文件操作并发崩溃             | 文件系统非线程安全   | 所有文件操作加 `filesys_lock`              |
| 用户传入非法地址导致内核崩溃 | 未验证用户指针       | 实现 `is_valid_uaddr()` 系列函数           |
| 运行中程序被修改             | 未保护可执行文件     | 加载后 `file_deny_write()`                 |
| 栈对齐错误                   | ESP 未按 16 字节对齐 | 计算填充使 ESP % 16 == 12                  |

### 7. 测试结果

共 **96 个**测试用例，**全部通过 (100%)**。

### 8. 结论

本实验成功实现了 Pintos 用户程序支持：

- ✅ **参数传递**：正确构造用户栈，符合 x86 调用约定
- ✅ **进程控制**：exec/wait/exit 实现完整的进程生命周期管理
- ✅ **文件操作**：支持 13 种系统调用，使用全局锁保护
- ✅ **地址验证**：防止恶意用户程序攻击内核
- ✅ **ROX 保护**：禁止修改运行中的可执行文件

修改涉及 `process.c`、`syscall.c`、`exception.c` 等文件，共新增约 **500 行**代码。

### 9. 未来工作与展望

- 实现信号机制（kill、signal）
- 支持 pipe 管道通信
- 实现 fork 系统调用
- 优化文件系统锁粒度（每个文件一个锁）

---

## 实验五：Pintos 文件系统

### 1. 实验目标

扩展 Pintos 文件系统，实现：

1. **Buffer Cache**：缓存磁盘块减少 I/O 操作
2. **可扩展文件（Indexed and Extensible Files）**：支持文件动态增长
3. **子目录（Subdirectories）**：支持层次化目录结构

### 2. 设计思路

#### 2.1 整体架构

![文件系统架构](imgs/filesys_architecture.png)

文件系统采用分层设计：

- **系统调用层**：处理用户请求
- **文件系统层**：路径解析、文件/目录操作
- **Inode 层**：索引块管理、文件扩展
- **Buffer Cache 层**：磁盘块缓存
- **块设备层**：底层磁盘 I/O

#### 2.2 索引结构

![Inode 索引结构](imgs/inode_structure.png)

采用多级索引结构支持大文件：

- **直接块**：122 个，最大 62 KB
- **一级间接块**：1 个，索引 128 块，64 KB
- **二级间接块**：1 个，索引 128×128 块，8 MB
- **最大文件大小**：约 8.1 MB

### 3. 数据结构

#### 3.1 缓存条目结构

```c
struct cache_entry {
  block_sector_t sector;    /* 磁盘扇区号 */
  uint8_t data[BLOCK_SECTOR_SIZE]; /* 数据缓冲（512字节） */
  bool dirty;               /* 脏标记（需写回） */
  bool accessed;            /* 访问标记（时钟算法） */
  bool valid;               /* 有效标记 */
  struct lock lock;         /* 条目锁 */
  int open_cnt;             /* 引用计数 */
};

#define CACHE_SIZE 64  /* 最多缓存 64 个扇区 */
static struct cache_entry cache[CACHE_SIZE];
```

#### 3.2 磁盘 Inode 结构

```c
struct inode_disk {
  off_t length;                       /* 文件大小 */
  unsigned magic;                     /* 魔数验证 */
  uint32_t is_dir;                    /* 是否为目录 */
  block_sector_t direct[122];         /* 直接块索引 */
  block_sector_t indirect;            /* 一级间接块 */
  block_sector_t doubly_indirect;     /* 二级间接块 */
};
```

索引范围：

- 直接块：0~121（62 KB）
- 一级间接：122~249（64 KB）
- 二级间接：250~16633（~8 MB）

### 4. 具体实现

#### 4.1 Buffer Cache 实现

**初始化和读写操作**：

> 参见 [cache.c:L35-43](pintos/src/filesys/cache.c#L35-L43)（`cache_init` 实现）
> 参见 [cache.c:L123-148](pintos/src/filesys/cache.c#L123-L148)（`cache_read`/`cache_write` 实现）

**时钟驱逐算法**：

> 参见 [cache.c:L52-99](pintos/src/filesys/cache.c#L52-L99)（`cache_get_block` 实现，包含时钟算法选择牺牲块）

**关闭缓存（写回所有脏块）**：

> 参见 [cache.c:L111-120](pintos/src/filesys/cache.c#L111-L120)（`cache_done` 实现）

#### 4.2 可扩展文件实现

**扇区定位**（多级索引）：

> 参见 [inode.c:L64-107](pintos/src/filesys/inode.c#L64-L107)（`byte_to_sector` 实现）

**文件扩展**：

> 参见 [inode.c:L110-180](pintos/src/filesys/inode.c#L110-L180)（`inode_expand` 实现，动态分配直接/间接/二级间接块）

**Inode 辅助函数**：

| 函数               | 功能                    | 实现要点                                 |
| ------------------ | ----------------------- | ---------------------------------------- |
| `alloc_sector`     | 分配并清零一个扇区      | `free_map_allocate` + `cache_write` 清零 |
| `inode_deallocate` | 释放 inode 所有数据扇区 | 递归遍历直接/间接/二级间接块并释放       |
| `inode_is_dir`     | 判断是否为目录          | 返回 `inode->data.is_dir != 0`           |
| `inode_set_dir`    | 设置目录标记            | 修改 `is_dir` 后写回磁盘                 |
| `inode_is_removed` | 检查 inode 是否已删除   | 返回 `inode->removed`                    |

> 参见 [inode.c:L40-62](pintos/src/filesys/inode.c#L40-L62)（扇区辅助函数）
> 参见 [inode.c:L269-330](pintos/src/filesys/inode.c#L269-L330)（`inode_deallocate` 实现）

#### 4.3 子目录实现

**路径解析**：

> 参见 [filesys.c:L45-100](pintos/src/filesys/filesys.c#L45-L100)（`parse_path` 实现）

**创建目录**：

> 参见 [filesys.c:L155-185](pintos/src/filesys/filesys.c#L155-L185)（`filesys_create_dir` 实现，包括 `.` 和 `..` 条目创建）

**目录删除检查**：

> 参见 [directory.c:L166-185](pintos/src/filesys/directory.c#L166-L185)（`dir_is_empty` 实现）

**目录操作辅助函数**：

| 函数          | 功能             | 实现要点                         |
| ------------- | ---------------- | -------------------------------- |
| `dir_tell`    | 获取目录读取位置 | 返回 `dir->pos`                  |
| `dir_seek`    | 设置目录读取位置 | 设置 `dir->pos = pos`            |
| `dir_readdir` | 读取下一个目录项 | 跳过 `.` 和 `..`，返回文件名     |
| `dir_lookup`  | 在目录中查找文件 | 检查目录是否已删除后再查找       |
| `dir_add`     | 向目录添加条目   | 检查目录未删除、名称合法、无重复 |
| `dir_remove`  | 从目录删除条目   | 目录需为空才能删除               |

> 参见 [directory.c:L229-298](pintos/src/filesys/directory.c#L229-L298)（目录辅助函数实现）

### 5. 系统调用一览

| 系统调用  | 功能          | 实现要点                                 |
| --------- | ------------- | ---------------------------------------- |
| `mkdir`   | 创建目录      | `filesys_create_dir()`，添加 `.` 和 `..` |
| `chdir`   | 切换目录      | 更新 `thread->cwd`                       |
| `readdir` | 读取目录项    | `dir_readdir()`，跳过 `.` 和 `..`        |
| `isdir`   | 判断是否目录  | `inode_is_dir()`                         |
| `inumber` | 获取 inode 号 | `inode_get_inumber()`                    |

### 6. 遇到的问题及解决方法

| 问题               | 原因                 | 解决方法                             |
| ------------------ | -------------------- | ------------------------------------ |
| 缓存块被意外驱逐   | 驱逐时未检查引用计数 | 只驱逐 `open_cnt == 0` 的块          |
| 文件扩展后数据丢失 | 未及时写回 inode     | 扩展后立即 `cache_write` inode       |
| 删除非空目录       | 未检查目录内容       | 添加 `dir_is_empty()` 检查           |
| 路径解析错误       | 未处理 `.` 和 `..`   | 在目录创建时添加这两个条目           |
| 并发扩展冲突       | 多线程同时扩展文件   | 为每个 inode 添加 `lock`             |
| 关机数据丢失       | 脏块未写回           | `filesys_done()` 调用 `cache_done()` |

### 7. 测试结果

共 **142 个**测试用例，**全部通过 (100%)**。

### 8. 结论

本实验成功实现了 Pintos 文件系统扩展：

- ✅ **Buffer Cache**：64 块缓存，时钟驱逐算法
- ✅ **可扩展文件**：122 直接 + 1 间接 + 1 二级间接，最大 8 MB
- ✅ **子目录**：支持绝对/相对路径，`.`/`..` 导航
- ✅ **目录系统调用**：mkdir/chdir/readdir/isdir/inumber

修改涉及 `cache.c`（新增）、`inode.c`、`directory.c`、`filesys.c` 等文件，共新增约 **600 行**代码。

### 9. 未来工作与展望

- 实现文件系统日志（Journaling）保证崩溃一致性
- 支持符号链接和硬链接
- 实现预读（Read-ahead）和写回线程
- 优化大文件的顺序读写性能

---

## 实验六：Pintos 虚拟存储

### 1. 实验目标

实现 Pintos 虚拟内存系统，包括：

1. **补充页表（Supplemental Page Table, SPT）**：记录每个虚拟页的元数据
2. **帧表（Frame Table）**：管理物理帧分配和驱逐
3. **交换表（Swap Table）**：管理交换分区的槽位
4. **懒加载（Lazy Loading）**：按需从可执行文件加载代码/数据
5. **栈增长（Stack Growth）**：自动扩展用户栈
6. **内存映射文件（mmap/munmap）**：文件到内存的映射

### 2. 设计思路

#### 2.1 整体架构

![虚拟内存架构](imgs/vm_architecture.png)

核心组件：

- **SPT**：每个进程一个哈希表，记录页状态（内存/交换/文件）
- **帧表**：全局链表，使用时钟算法选择驱逐页
- **交换表**：位图管理交换槽位

#### 2.2 Page Fault 处理流程

1. 查询 SPT 确定页类型
2. 分配物理帧（可能触发驱逐）
3. 从文件或交换区加载数据
4. 更新页表映射

### 3. 数据结构

#### 3.1 页表项（SPT Entry）

```c
enum page_status {
  PAGE_FRAME,  /* 在物理内存中 */
  PAGE_SWAP,   /* 在交换区中 */
  PAGE_FILE    /* 在文件中（懒加载） */
};

struct page_entry {
  void *vaddr;            /* 虚拟地址（键） */
  struct hash_elem elem;  /* 哈希表元素 */

  enum page_status status;
  bool writable;          /* 可写标志 */
  bool dirty;             /* 脏标志 */

  /* 帧信息（PAGE_FRAME） */
  void *kaddr;            /* 内核虚拟地址 */

  /* 文件信息（PAGE_FILE） */
  struct file *file;
  off_t file_offset;
  uint32_t read_bytes;
  uint32_t zero_bytes;

  /* 交换信息（PAGE_SWAP） */
  size_t swap_index;
};
```

#### 3.2 帧表项

```c
struct frame_entry {
  void *frame;           /* 帧的内核虚拟地址 */
  struct thread *owner;  /* 所属线程 */
  void *vaddr;           /* 对应的用户虚拟地址 */
  struct list_elem elem; /* 帧表链表元素 */
};
```

#### 3.3 mmap 映射条目

```c
struct mmap_entry {
  int mapid;               /* 映射 ID */
  struct file *file;       /* 映射的文件 */
  void *addr;              /* 起始虚拟地址 */
  size_t page_count;       /* 映射的页数 */
  struct list_elem elem;   /* 用于 process->mmap_list */
};
```

### 4. 具体实现

#### 4.1 补充页表（SPT）实现

**初始化和查找**：

> 参见 [page.c:L46-60](pintos/src/vm/page.c#L46-L60)（`vm_spt_init`, `vm_spt_lookup` 实现）

**添加文件页（懒加载）**：

> 参见 [page.c:L79-98](pintos/src/vm/page.c#L79-L98)（`vm_spt_add_file` 实现）

**SPT 辅助函数**：

| 函数                   | 功能                      | 实现要点                                    |
| ---------------------- | ------------------------- | ------------------------------------------- |
| `vm_spt_init`          | 初始化 SPT 哈希表         | `hash_init` 配合 `page_hash`/`page_less`    |
| `vm_spt_destroy`       | 销毁 SPT 并释放资源       | 遍历释放帧/交换槽，调用 `page_cleanup_func` |
| `vm_spt_lookup`        | 查找虚拟页对应的 SPT 条目 | `pg_round_down` + `hash_find`               |
| `vm_spt_install_frame` | 在 SPT 中注册已安装的帧   | 创建 `PAGE_FRAME` 状态条目并插入哈希表      |

> 参见 [page.c:L20-45](pintos/src/vm/page.c#L20-L45)（哈希辅助函数 `page_hash`/`page_less`）
> 参见 [page.c:L61-78](pintos/src/vm/page.c#L61-L78)（`vm_spt_install_frame` 实现）

#### 4.2 帧表实现（时钟驱逐算法）

**帧分配**：

> 参见 [frame.c:L24-79](pintos/src/vm/frame.c#L24-L79)（`vm_frame_alloc` 实现）

**时钟驱逐算法**：

> 参见 [frame.c:L84-230](pintos/src/vm/frame.c#L84-L230)（`vm_evict_frame` 实现，包含时钟算法选择及换出逻辑）

**帧表辅助函数**：

| 函数                    | 功能               | 实现要点                                     |
| ----------------------- | ------------------ | -------------------------------------------- |
| `vm_frame_init`         | 初始化帧表         | `list_init` + `lock_init`                    |
| `vm_frame_alloc`        | 分配物理帧         | `palloc_get_page`，失败时调用 `vm_evict`     |
| `vm_frame_free`         | 释放帧并从帧表移除 | `vm_frame_remove_entry` + `palloc_free_page` |
| `vm_frame_remove_entry` | 仅从帧表移除条目   | 查找并移除链表条目，返回是否找到             |
| `vm_evict_frame`        | 驱逐一页并返回帧   | 时钟算法选择牺牲页，换出到 swap 或 file      |

> 参见 [frame.c:L36-40](pintos/src/vm/frame.c#L36-L40)（`vm_frame_init` 实现）
> 参见 [frame.c:L249-271](pintos/src/vm/frame.c#L249-L271)（`vm_frame_free/remove_entry` 实现）

#### 4.3 交换表实现

> 参见 [swap.c:L10-80](pintos/src/vm/swap.c#L10-L80)（`vm_swap_init`, `vm_swap_out`, `vm_swap_in`, `vm_swap_free` 实现）

#### 4.4 页加载（Page Fault 处理）

> 参见 [page.c:L100-140](pintos/src/vm/page.c#L100-L140)（`vm_load_page` 实现）

#### 4.5 栈增长

> 参见 [page.c:L143-173](pintos/src/vm/page.c#L143-L173)（`vm_stack_growth` 实现）
> 参见 [exception.c:L120-150](pintos/src/userprog/exception.c#L120-L150)（Page Fault 处理器中的栈增长的检测）

#### 4.6 内存映射文件（mmap/munmap）

**mmap/munmap 实现**：

> 参见 [page.c:L176-249](pintos/src/vm/page.c#L176-L249)（`vm_mmap` 实现）
> 参见 [page.c:L251-297](pintos/src/vm/page.c#L251-L297)（`vm_munmap`/`vm_munmap_all` 实现）

**mmap 辅助函数**：

| 函数            | 功能                   | 实现要点                                  |
| --------------- | ---------------------- | ----------------------------------------- |
| `vm_mmap`       | 映射文件到用户地址空间 | 验证对齐，创建 SPT 条目，记录到 mmap_list |
| `vm_munmap`     | 解除单个映射           | 写回脏页到文件，释放帧，清理 SPT 条目     |
| `vm_munmap_all` | 解除所有映射           | 进程退出时批量调用 `vm_munmap`            |

### 5. 系统调用一览

| 系统调用 | 功能           | 实现要点                              |
| -------- | -------------- | ------------------------------------- |
| `mmap`   | 映射文件到内存 | 验证地址对齐，添加 SPT 条目（懒加载） |
| `munmap` | 解除映射       | 写回脏页，释放帧，清理 SPT            |

### 6. 遇到的问题及解决方法

| 问题               | 原因               | 解决方法                               |
| ------------------ | ------------------ | -------------------------------------- |
| 驱逐活跃页导致崩溃 | 未正确实现时钟算法 | 检查访问位，给第二次机会               |
| 栈增长误判         | 未保存用户 ESP     | 系统调用入口保存 `user_esp`            |
| mmap 写回错误      | 写回了所有页       | 仅在 `dirty` 时写回                    |
| 换入换出竞争       | 帧表无锁保护       | 添加 `frame_lock` 全局锁               |
| 交换槽位泄漏       | 换入后未释放槽位   | `vm_swap_in` 后调用 `vm_swap_free`     |
| 进程退出内存泄漏   | SPT 销毁不完整     | `vm_spt_destroy` 释放帧和交换槽        |
| Swap 初始化崩溃    | 初始化顺序错误     | 调整 `init.c`（在块设备后初始化 Swap） |
| 内核态访问用户页   | 坏指针触发缺页     | `page_fault` 识别内核态并修复 `eip`    |

### 7. 测试结果

共 **127 个**测试用例，**全部通过 (100%)**。

### 8. 结论

本实验成功实现了 Pintos 虚拟内存系统：

- ✅ **SPT**：哈希表记录每页状态（FRAME/SWAP/FILE）
- ✅ **帧表**：时钟算法驱逐，支持 8MB 以上物理内存需求
- ✅ **交换表**：位图管理，每页 8 扇区
- ✅ **懒加载**：按需从可执行文件加载
- ✅ **栈增长**：自动扩展到 8MB
- ✅ **mmap/munmap**：文件映射和写回

修改涉及 `frame.c`、`page.c`、`swap.c`（新增）、`exception.c`、`process.c` 等文件，共新增约 **700 行**代码。

### 9. 未来工作与展望

- 实现共享内存（Shared Memory）
- 实现写时复制（Copy-on-Write, COW）
- 优化 TLB 失效处理
- 支持大页（Huge Pages）减少页表开销

---

## AI 工具使用声明

本课程设计中使用 AI 工具辅助以下工作：

- 代码调试和问题排查
- 文档格式整理
- 代码格式规范化整理

---

## 课程设计心得与自我评估

1.  **对专业知识的深入理解**
    通过本次 Pintos 实验，死锁、虚拟内存、文件索引等抽象概念不再仅停留在理论层面。我深刻理解了操作系统作为软硬件中间层，如何对 CPU 周期和内存字节进行精细化调度与管理，实现了从理论到实践的认知跨越。

2.  **系统建模与分析能力**
    在解决 Kernel Panic 的过程中，需要从中断上下文到线程切换堆栈进行系统状态复现。这一过程锻炼了我将复杂工程问题抽象为动态运行模型的能力，使我能够更严谨地推演系统运行状态，从而高效地定位并发错误和资源竞争问题。

3.  **解决复杂问题的工程思维**
    面对工程问题，往往存在多种解决方案。例如在实现页面置换算法时，经过对性能开销与实现复杂度的权衡，最终选择了近似 LRU 的时钟算法。这让我认识到工程实践不仅仅是代码实现，更是在既定约束条件下，寻求利用基础原理解决问题的最优解的过程。

4.  **实验方案设计能力**
    摒弃了盲目编码的习惯，转而采用“先设计后实现”的策略。针对 Swap 机制特别设计了高内存压力的边界测试用例，这种以验证为导向的设计思路显著减少了后期的返工成本，增强了实验方案设计的严谨性和完备性。

5.  **技术沟通与表达**
    撰写本文档是对系统设计思路的系统性梳理。我致力于清晰、准确地传达设计意图与问题解决过程，特别是针对复杂的调试逻辑。能够将晦涩的底层技术细节转化为逻辑清晰的工程文档，是本次课程设计带来的重要能力提升。

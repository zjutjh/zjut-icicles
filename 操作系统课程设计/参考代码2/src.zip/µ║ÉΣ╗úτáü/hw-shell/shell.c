/*
 * shell.c - 简单shell实现
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

pid_t bg_pids[100];
int bg_count = 0;

void sigint_handler(int sig) {
    (void)sig;
}

char* find_path(char *cmd) {
    static char path[1024];
    
    if (strchr(cmd, '/')) {
        return cmd;
    }
    
    char *p = strdup(getenv("PATH"));
    char *dir = strtok(p, ":");
    
    while (dir != NULL) {
        snprintf(path, 1024, "%s/%s", dir, cmd);
        if (access(path, X_OK) == 0) {
            free(p);
            return path;
        }
        dir = strtok(NULL, ":");
    }
    
    free(p);
    return NULL;
}

int main() {
    char line[1024];
    char *args[64];
    char *in = NULL;
    char *out = NULL;
    int bg;
    
    signal(SIGINT, sigint_handler);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
    
    while (1) {
        printf("$ ");
        fflush(stdout);
        
        if (fgets(line, 1024, stdin) == NULL) {
            printf("\n");
            break;
        }
        
        // 去换行
        int len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r')) {
            line[len-1] = '\0';
            len--;
        }
        
        // 跳过空白和反斜杠
        char *p = line;
        while (*p == ' ' || *p == '\t' || *p == '\\') {
            p++;
        }
        if (*p == '\0' || *p == '?') {
            continue;
        }
        
        // 解析
        int argc = 0;
        in = NULL;
        out = NULL;
        bg = 0;
        
        char *t = strtok(p, " \t");
        while (t != NULL) {
            while (*t == '\\') {
                t++;
            }
            if (*t == '\0') {
                t = strtok(NULL, " \t");
                continue;
            }
            
            if (strcmp(t, "<") == 0) {
                t = strtok(NULL, " \t");
                if (t != NULL) {
                    while (*t == '\\') t++;
                    in = t;
                }
            } else if (strcmp(t, ">") == 0) {
                t = strtok(NULL, " \t");
                if (t != NULL) {
                    while (*t == '\\') t++;
                    out = t;
                }
            } else if (strcmp(t, "&") == 0) {
                bg = 1;
            } else {
                args[argc] = t;
                argc++;
            }
            t = strtok(NULL, " \t");
        }
        args[argc] = NULL;
        
        if (argc == 0) {
            continue;
        }
        
        // 内置命令: exit
        if (strcmp(args[0], "exit") == 0) {
            break;
        }
        
        // 内置命令: cd
        if (strcmp(args[0], "cd") == 0) {
            if (args[1] != NULL) {
                chdir(args[1]);
            } else {
                chdir(getenv("HOME"));
            }
            continue;
        }
        
        // 内置命令: pwd
        if (strcmp(args[0], "pwd") == 0) {
            char cwd[1024];
            if (getcwd(cwd, 1024) != NULL) {
                printf("%s\n", cwd);
            }
            continue;
        }
        
        // 内置命令: wait
        if (strcmp(args[0], "wait") == 0) {
            for (int i = 0; i < bg_count; i++) {
                waitpid(bg_pids[i], NULL, 0);
            }
            bg_count = 0;
            continue;
        }
        
        // 执行外部命令
        char *path = find_path(args[0]);
        if (path == NULL) {
            printf("%s: command not found\n", args[0]);
            continue;
        }
        
        pid_t pid = fork();
        
        if (pid == 0) {
            // 子进程
            setpgid(0, 0);
            
            signal(SIGINT, SIG_DFL);
            signal(SIGQUIT, SIG_DFL);
            signal(SIGTSTP, SIG_DFL);
            signal(SIGTTIN, SIG_DFL);
            signal(SIGTTOU, SIG_DFL);
            
            if (in != NULL) {
                int fd = open(in, O_RDONLY);
                dup2(fd, 0);
                close(fd);
            }
            
            if (out != NULL) {
                int fd = open(out, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                dup2(fd, 1);
                close(fd);
            }
            
            execv(path, args);
            perror(args[0]);
            exit(1);
        }
        
        // 父进程
        setpgid(pid, pid);
        
        if (bg) {
            bg_pids[bg_count] = pid;
            bg_count++;
        } else {
            tcsetpgrp(0, pid);
            waitpid(pid, NULL, 0);
            tcsetpgrp(0, getpgrp());
        }
    }
    
    return 0;
}

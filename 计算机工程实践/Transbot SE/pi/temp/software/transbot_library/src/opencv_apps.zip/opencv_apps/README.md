# opencv_apps
Travis CI [![Build Status](https://travis-ci.org/ros-perception/opencv_apps.svg?branch=indigo)](https://travis-ci.org/ros-perception/opencv_apps)

Indigo Trusty [![Build Status](http://build.ros.org/job/Ibin_uT64__opencv_apps__ubuntu_trusty_amd64__binary/badge/icon)](http://build.ros.org/job/Ibin_uT64__opencv_apps__ubuntu_trusty_amd64__binary/)

Kinetic Xenial [![Build Status](http://build.ros.org/job/Kbin_uX64__opencv_apps__ubuntu_xenial_amd64__binary/badge/icon)](http://build.ros.org/job/Kbin_uX64__opencv_apps__ubuntu_xenial_amd64__binary/)

Melodic Bionic [![Build Status](http://build.ros.org/job/Mbin_uB64__opencv_apps__ubuntu_bionic_amd64__binary/badge/icon)](http://build.ros.org/job/Mbin_uB64__opencv_apps__ubuntu_bionic_amd64__binary/)

Documentation http://wiki.ros.org/opencv_apps

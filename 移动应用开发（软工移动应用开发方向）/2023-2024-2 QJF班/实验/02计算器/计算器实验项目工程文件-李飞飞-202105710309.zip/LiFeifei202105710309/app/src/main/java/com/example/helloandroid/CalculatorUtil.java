//package com.example.helloandroid;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Looper;
//import android.os.ResultReceiver;
//import android.util.Log;
//import android.widget.Toast;
//
//import com.example.helloandroid.service.AddService;
//
//import java.math.BigDecimal;
//import java.util.List;
//import java.util.concurrent.CountDownLatch;
//
///**
// * @Author: Cassifa
// * @CreateTime: 2024-05-19  18:13
// * @Description:
// */
//public class CalculatorUtil {
//    public List<InputItem> mInputList;
//    public doCalculate(){
//        findHighOperator(0);
//        if (mLastInputStatus != ERROR) {
//            findLowOperator(0);
//        }
//    }
//    public int findHighOperator(int index) {
//        if (mInputList.size() > 1 && index >= 0 && index < mInputList.size())
//            for (int i = index; i < mInputList.size(); i++) {
//                InputItem item = mInputList.get(i);
//                if (getResources().getString(R.string.divide).equals(item.getInput())
//                        || getResources().getString(R.string.multply).equals(item.getInput())) {
//                    int a, b;
//                    double c, d;
//                    if (mInputList.get(i - 1).getType() == InputItem.InputType.INT_TYPE) {
//                        a = Integer.parseInt(mInputList.get(i - 1).getInput());
//                        if (mInputList.get(i + 1).getType() == InputItem.InputType.INT_TYPE) {
//                            b = Integer.parseInt(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.multply).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a * b), InputItem.InputType.INT_TYPE));
//                            } else {
//                                if (b == 0) {
//                                    mLastInputStatus = ERROR;
//                                    if (a == 0) {
//                                        clearScreen(new InputItem(nan, InputItem.InputType.ERROR));
//                                    } else {
//                                        clearScreen(new InputItem(infinite, InputItem.InputType.ERROR));
//                                    }
//                                    return -1;
//                                } else if (a % b != 0) {
//                                    mInputList.set(i - 1, new InputItem(String.valueOf((double) a / b), InputItem.InputType.DOUBLE_TYPE));
//                                } else {
//                                    mInputList.set(i - 1, new InputItem(String.valueOf((Integer) a / b), InputItem.InputType.INT_TYPE));
//                                }
//                            }
//                        } else {
//                            d = Double.parseDouble(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.multply).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a * d), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                if (d == 0) {
//                                    mLastInputStatus = ERROR;
//                                    if (a == 0) {
//                                        clearScreen(new InputItem(nan, InputItem.InputType.ERROR));
//                                    } else {
//                                        clearScreen(new InputItem(infinite, InputItem.InputType.ERROR));
//                                    }
//                                    return -1;
//                                }
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a / d), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        }
//                    } else {
//                        c = Double.parseDouble(mInputList.get(i - 1).getInput());
//                        if (mInputList.get(i + 1).getType() == InputItem.InputType.INT_TYPE) {
//                            b = Integer.parseInt(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.multply).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(c * b), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                if (b == 0) {
//                                    mLastInputStatus = ERROR;
//                                    if (c == 0) {
//                                        clearScreen(new InputItem(nan, InputItem.InputType.ERROR));
//                                    } else {
//                                        clearScreen(new InputItem(infinite, InputItem.InputType.ERROR));
//                                    }
//                                    return -1;
//                                }
//                                mInputList.set(i - 1, new InputItem(String.valueOf(c / b), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        } else {
//                            d = Double.parseDouble(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.multply).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(mul(c, d)), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                if (d == 0) {
//                                    mLastInputStatus = ERROR;
//                                    if (c == 0) {
//                                        clearScreen(new InputItem(nan, InputItem.InputType.ERROR));
//                                    } else {
//                                        clearScreen(new InputItem(infinite, InputItem.InputType.ERROR));
//                                    }
//                                    return -1;
//                                }
//                                mInputList.set(i - 1, new InputItem(String.valueOf(div(c, d)), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        }
//                    }
//                    mInputList.remove(i + 1);
//                    mInputList.remove(i);
//                    return findHighOperator(i);
//                }
//            }
//        return -1;
//
//    }
//
//    public int findLowOperator(int index) {
//        if (mInputList.size() > 1 && index >= 0 && index < mInputList.size())
//            for (int i = index; i < mInputList.size(); i++) {
//                InputItem item = mInputList.get(i);
//                if (getResources().getString(R.string.sub).equals(item.getInput())
//                        || getResources().getString(R.string.add).equals(item.getInput())) {
//                    int a, b;
//                    double c, d;
//                    if (mInputList.get(i - 1).getType() == InputItem.InputType.INT_TYPE) {
//                        a = Integer.parseInt(mInputList.get(i - 1).getInput());
//                        if (mInputList.get(i + 1).getType() == InputItem.InputType.INT_TYPE) {
//                            b = Integer.parseInt(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.add).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf((a + b)), InputItem.InputType.INT_TYPE));
//                            } else {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a - b), InputItem.InputType.INT_TYPE));
//                            }
//                        } else {
//                            d = Double.parseDouble(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.add).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a + d), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(a - d), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        }
//                    } else {
//                        c = Double.parseDouble(mInputList.get(i - 1).getInput());
//                        if (mInputList.get(i + 1).getType() == InputItem.InputType.INT_TYPE) {
//                            b = Integer.parseInt(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.add).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(c + b), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(c - b), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        } else {
//                            d = Double.parseDouble(mInputList.get(i + 1).getInput());
//                            if (getResources().getString(R.string.add).equals(item.getInput())) {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(add(c, d)), InputItem.InputType.DOUBLE_TYPE));
//                            } else {
//                                mInputList.set(i - 1, new InputItem(String.valueOf(sub(c, d)), InputItem.InputType.DOUBLE_TYPE));
//                            }
//                        }
//                    }
//                    mInputList.remove(i + 1);
//                    mInputList.remove(i);
//                    return findLowOperator(i);
//                }
//            }
//        return -1;
//
//    }
//
//    public static Double div(Double v1, Double v2) {
//        BigDecimal b1 = new BigDecimal(v1.toString());
//        BigDecimal b2 = new BigDecimal(v2.toString());
//        return b1.divide(b2, 10, BigDecimal.ROUND_HALF_UP).doubleValue();
//    }
//
//    public static Double sub(Double v1, Double v2) {
//        BigDecimal b1 = new BigDecimal(v1.toString());
//        BigDecimal b2 = new BigDecimal(v2.toString());
//        return b1.subtract(b2).doubleValue();
//    }
//
//    public Double add(Double v1, Double v2) {
//        BigDecimal b1 = new BigDecimal(v1.toString());
//        BigDecimal b2 = new BigDecimal(v2.toString());
//        return b1.add(b2).doubleValue();
//    }
//
//    public static Double mul(Double v1, Double v2) {
//        BigDecimal b1 = new BigDecimal(v1.toString());
//        BigDecimal b2 = new BigDecimal(v2.toString());
//        return b1.multiply(b2).doubleValue();
//    }
//}

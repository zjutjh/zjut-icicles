package com.example.helloandroid.service;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ResultReceiver;
import android.widget.Toast;

import java.math.BigDecimal;

public class DivService extends Service {

    public static final String EXTRA_A = "com.example.calculator.service.EXTRA_A";
    public static final String EXTRA_B = "com.example.calculator.service.EXTRA_B";
    public static final String EXTRA_RESULT_RECEIVER = "com.example.calculator.service.EXTRA_RESULT_RECEIVER";
    private Handler handler;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        double a = intent.getDoubleExtra(EXTRA_A, 0);
        double b = intent.getDoubleExtra(EXTRA_B, 0);
        ResultReceiver receiver = intent.getParcelableExtra(EXTRA_RESULT_RECEIVER);

        new Thread(() -> {
            double result = divBigNumbers(a, b);
            int tid = android.os.Process.myTid();
            int pid = android.os.Process.myPid();

            if (receiver != null) {
                Bundle bundle = new Bundle();
                bundle.putDouble("result", result);
                bundle.putInt("TID", tid);
                bundle.putInt("PID", pid);
                showToast("结果 " + result + ", TID: " + tid + ", PID: " + pid);
                receiver.send(0, bundle);
            }

            stopSelf(startId);
        }).start();

        return START_NOT_STICKY;
    }
    private void showToast(final String message) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
    private double divBigNumbers(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.divide(b2).doubleValue();
    }
}